# 🎨 Design Preview - InsightMind

## Visual Structure

### 1️⃣ Home Page
```
┌─────────────────────────────────────┐
│  Selamat datang kembali!       ❤️  │
│  Pantau kesehatan mental Anda        │
├─────────────────────────────────────┤
│  ╔═══════════════════════════════╗ │
│  ║  Status Kesehatan Mental      ║ │
│  ║        Baik ✓                 ║ │
│  ║  Hari Baik  | Stress Level    ║ │
│  ║   23/30    │   Rendah         ║ │
│  ╚═══════════════════════════════╝ │
├─────────────────────────────────────┤
│  Aksi Cepat                         │
│  ┌──────────────┐  ┌──────────────┐│
│  │ 📋 Screening │  │ 📋 Riwayat   ││
│  └──────────────┘  └──────────────┘│
├─────────────────────────────────────┤
│  Fitur Unggulan                     │
│  ┌──────────────┐  ┌──────────────┐│
│  │ 😊 Mood      │  │ 📊 Analitik  ││
│  │ Tracker      │  │ Lihat        ││
│  │ Catat mood   │  │ progress Anda││
│  └──────────────┘  └──────────────┘│
│  ┌──────────────┐  ┌──────────────┐│
│  │ 💡 Tips      │  │ 👤 Profil    ││
│  │ Dapatkan     │  │ Kelola akun  ││
│  │ saran        │  │ Anda         ││
│  └──────────────┘  └──────────────┘│
└─────────────────────────────────────┘
```

---

### 2️⃣ Screening Page
```
┌─────────────────────────────────────┐
│ ⬅️  Screening Kesehatan Mental    │
│     Jawab pertanyaan-pertanyaan     │
│     berikut dengan jujur            │
├─────────────────────────────────────┤
│  ╔═══════════════════════════════╗ │
│  ║ Progress Screening       1/10 ║ │
│  ║ ████░░░░░░░░░░░░░░░░░░░░░░░░║ │
│  ╚═══════════════════════════════╝ │
├─────────────────────────────────────┤
│  ┌───────────────────────────────┐ │
│  │ ① Bagaimana mood Anda hari    │ │
│  │    ini?                       │ │
│  │                               │ │
│  │ ⭕ Sangat Baik  ⭕ Baik       │ │
│  │ ⭕ Sedang       ⭕ Buruk      │ │
│  │ ⭕ Sangat Buruk               │ │
│  └───────────────────────────────┘ │
├─────────────────────────────────────┤
│  ┌───────────────────────────────┐ │
│  │ ② Apakah Anda merasa stress   │ │
│  │    belakangan ini?            │ │
│  │                               │ │
│  │ ✓ Ya                          │ │
│  │ ⭕ Kadang-kadang  ⭕ Tidak     │ │
│  └───────────────────────────────┘ │
├─────────────────────────────────────┤
│  [✓ Lihat Hasil]                    │
│  [  Reset Jawaban  ]                │
└─────────────────────────────────────┘
```

---

### 3️⃣ Result Page
```
┌─────────────────────────────────────┐
│ ⬅️  Hasil Screening               │
├─────────────────────────────────────┤
│  ╔═══════════════════════════════╗ │
│  ║                               ║ │
│  ║           ✓  (Green)          ║ │
│  ║        Skor Anda              ║ │
│  ║            32                 ║ │
│  ║    Tingkat Risiko: Baik       ║ │
│  ║                               ║ │
│  ╚═══════════════════════════════╝ │
├─────────────────────────────────────┤
│  Rekomendasi untuk Anda             │
│  ┌───────────────────────────────┐ │
│  │ 💡 Pertahankan kebiasaan      │ │
│  │    baik. Jaga tidur, makan,   │ │
│  │    dan olahraga.              │ │
│  └───────────────────────────────┘ │
├─────────────────────────────────────┤
│  Tips Perawatan Diri                │
│  ┌───────────────────────────────┐ │
│  │ 🌙 Tidur Cukup                │ │
│  │    Pastikan tidur 7-8 jam     │ │
│  ├───────────────────────────────┤ │
│  │ 🏃 Olahraga Teratur           │ │
│  │    30 menit per hari          │ │
│  ├───────────────────────────────┤ │
│  │ 🍎 Makan Sehat                │ │
│  │    Nutrisi seimbang           │ │
│  ├───────────────────────────────┤ │
│  │ 👥 Interaksi Sosial           │ │
│  │    Jaga hubungan baik         │ │
│  └───────────────────────────────┘ │
├─────────────────────────────────────┤
│  [✓ Selesai]                        │
│  [  Bagikan Hasil  ]                │
└─────────────────────────────────────┘
```

---

### 4️⃣ History Page
```
┌─────────────────────────────────────┐
│ ⬅️  Riwayat Screening              │
├─────────────────────────────────────┤
│  ╔═══════════════════════════════╗ │
│  ║ ✓ Total Screening    35.8 📈 ║ │
│  ║     4            Rata-rata Skor ║
│  ╚═══════════════════════════════╝ │
├─────────────────────────────────────┤
│  Hasil Screening                    │
│  ┌───────────────────────────────┐ │
│  │ 📋 Senin, 14 Januari 2024  32 │ │
│  │    Status: Baik            pts │ │
│  ├───────────────────────────────┤ │
│  │ 📋 Minggu, 13 Januari 2024 28 │ │
│  │    Status: Baik            pts │ │
│  ├───────────────────────────────┤ │
│  │ 📋 Sabtu, 12 Januari 2024  45 │ │
│  │    Status: Sedang          pts │ │
│  ├───────────────────────────────┤ │
│  │ 📋 Jumat, 11 Januari 2024  38 │ │
│  │    Status: Baik            pts │ │
│  └───────────────────────────────┘ │
└─────────────────────────────────────┘
```

---

### 5️⃣ Profile Page
```
┌─────────────────────────────────────┐
│ ⬅️  Profil Saya                    │
├─────────────────────────────────────┤
│            👤                       │
│   Pengguna InsightMind              │
│   user@insightmind.com              │
├─────────────────────────────────────┤
│  Informasi Pribadi                  │
│  ┌───────────────────────────────┐ │
│  │ Nama Lengkap: Pengguna        │ │
│  ├───────────────────────────────┤ │
│  │ Email: user@insightmind.com   │ │
│  ├───────────────────────────────┤ │
│  │ Tanggal Lahir: 1 Januari 2000 │ │
│  ├───────────────────────────────┤ │
│  │ Gender: Laki-laki             │ │
│  └───────────────────────────────┘ │
├─────────────────────────────────────┤
│  Informasi Kesehatan                │
│  ┌───────────────────────────────┐ │
│  │ Tinggi Badan: 170 cm          │ │
│  ├───────────────────────────────┤ │
│  │ Berat Badan: 70 kg            │ │
│  ├───────────────────────────────┤ │
│  │ Status Kesehatan: Baik        │ │
│  └───────────────────────────────┘ │
├─────────────────────────────────────┤
│  Pengaturan                         │
│  ┌───────────────────────────────┐ │
│  │ 🔔 Notifikasi            [ON] │ │
│  ├───────────────────────────────┤ │
│  │ 🌙 Mode Gelap           [OFF] │ │
│  ├───────────────────────────────┤ │
│  │ 🌐 Bahasa              ➜      │ │
│  └───────────────────────────────┘ │
├─────────────────────────────────────┤
│  [  Keluar Akun  ]                  │
└─────────────────────────────────────┘
```

---

## 🎨 Color Scheme

### Primary Colors
- **Indigo 600** `#3F51B5` - Main brand color
- **Indigo 400** `#5E7DD3` - Light variant
- **Indigo 700** `#303F9F` - Dark variant
- **Indigo 100** `#E8EAF6` - Very light (background)
- **Indigo 50** `#F3F5FD` - Lighter background

### Secondary Colors
- **Teal** `#009688` - For secondary actions
- **Green** `#4CAF50` - For positive/good status
- **Orange** `#FF9800` - For warning/caution status
- **Red** `#F44336` - For danger/high risk status

### Neutral Colors
- **White** `#FFFFFF` - Cards, backgrounds
- **Grey 50** `#FAFAFA` - Light backgrounds
- **Grey 200** `#EEEEEE` - Dividers, borders
- **Grey 600** `#757575` - Secondary text
- **Grey 800** `#424242` - Primary text

---

## 📐 Responsive Breakpoints

- **Mobile**: <= 600dp (all screens)
- **Column spacing**: 16dp or 12dp
- **Card padding**: 12dp - 20dp
- **Border radius**: 8dp - 16dp

---

## ✨ Key Design Features

1. **Gradient Backgrounds**
   - Health Dashboard: Indigo gradient
   - Results: Dynamic color based on risk level
   - Teal gradient for secondary sections

2. **Interactive Elements**
   - Smooth transitions on button press
   - Visual feedback on selection
   - Dynamic color changes based on state

3. **Typography Hierarchy**
   - Large titles for main sections
   - Medium text for subsections
   - Small text for supporting information

4. **Spacing Consistency**
   - 8dp, 12dp, 16dp, 20dp, 24dp grid
   - Consistent padding on containers
   - Equal gaps between sections

5. **Icons & Illustrations**
   - Material Design icons throughout
   - Color-coded for different sections
   - 20-32 size for primary actions
   - 16-20 size for secondary actions

---

**InsightMind Design System v1.0** 🎨
