# 🚀 Developer Cheatsheet - InsightMind

## Quick Reference Guide

### 📂 File Locations
```
lib/
├── main.dart                                    # Entry point
├── src/app.dart                                # App config & theme
└── features/insightmind/presentation/
    ├── pages/
    │   ├── home_page.dart                     ✅ Done
    │   ├── screening_page.dart                ✅ Done
    │   ├── result_page.dart                   ✅ Done
    │   ├── history_page.dart                  ✅ Done
    │   └── profile_page.dart                  ✅ Done
    ├── widgets/
    │   ├── health_dashboard.dart              ✅ Done
    │   ├── statistics_widget.dart             ✅ Done
    │   ├── health_tips_widget.dart            ✅ Done
    │   └── onboarding_widget.dart             ✅ Done
    └── providers/
        └── [existing providers]
```

---

## 🎨 Theme Colors (Copy-Paste)

### Primary Indigo
```dart
Colors.indigo[50]   // #F3F5FD
Colors.indigo[100]  // #E8EAF6
Colors.indigo[400]  // #5E7DD3
Colors.indigo[600]  // #3F51B5
Colors.indigo[700]  // #303F9F
```

### Status Colors
```dart
Colors.green        // ✓ Good status
Colors.orange       // ⚠️ Medium status
Colors.red          // ⚠️ High risk
Colors.teal         // Secondary actions
```

### Gradients (Ready to Use)
```dart
// Indigo Gradient
LinearGradient(
  colors: [Colors.indigo[600]!, Colors.indigo[400]!],
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
)

// Teal Gradient
LinearGradient(
  colors: [Colors.teal[600]!, Colors.teal[400]!],
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
)
```

---

## 🔤 Typography (Copy-Paste)

### Styles
```dart
// Page Title (24pt, Bold)
style: Theme.of(context).textTheme.titleLarge?.copyWith(
  fontSize: 24,
  fontWeight: FontWeight.bold,
)

// Section Title (18pt, SemiBold)
style: Theme.of(context).textTheme.titleLarge?.copyWith(
  fontSize: 18,
  fontWeight: FontWeight.w600,
)

// Body Text (14pt, Regular)
style: Theme.of(context).textTheme.bodyMedium

// Supporting Text (11-13pt)
style: Theme.of(context).textTheme.bodyMedium?.copyWith(
  fontSize: 12,
  color: Colors.grey[600],
)
```

---

## 📐 Common Spacing (Copy-Paste)

```dart
// Small gap
const SizedBox(height: 8)

// Medium gap
const SizedBox(height: 12)

// Standard gap
const SizedBox(height: 16)

// Large gap
const SizedBox(height: 20)

// Extra large gap
const SizedBox(height: 24)

// Horizontal spacing
const SizedBox(width: 12)

// Standard padding
padding: const EdgeInsets.all(16)

// Large padding
padding: const EdgeInsets.all(20)
```

---

## 🎯 Common Components (Copy-Paste)

### Card Container
```dart
Container(
  decoration: BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(12),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.05),
        blurRadius: 8,
        offset: const Offset(0, 2),
      ),
    ],
  ),
  padding: const EdgeInsets.all(16),
  child: // your content
)
```

### Gradient Card
```dart
Container(
  decoration: BoxDecoration(
    gradient: LinearGradient(
      colors: [Colors.indigo[600]!, Colors.indigo[400]!],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ),
    borderRadius: BorderRadius.circular(16),
  ),
  padding: const EdgeInsets.all(20),
  child: // your content
)
```

### Icon Container
```dart
Container(
  decoration: BoxDecoration(
    color: Colors.indigo[50],
    shape: BoxShape.circle,
  ),
  padding: const EdgeInsets.all(12),
  child: Icon(
    Icons.favorite,
    color: Colors.indigo[700],
    size: 24,
  ),
)
```

### Back Button Header
```dart
Row(
  mainAxisAlignment: MainAxisAlignment.spaceBetween,
  children: [
    GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey[200],
          shape: BoxShape.circle,
        ),
        padding: const EdgeInsets.all(8),
        child: const Icon(Icons.arrow_back, size: 20),
      ),
    ),
    Text(
      'Title',
      style: Theme.of(context).textTheme.titleLarge?.copyWith(
        fontSize: 20,
        fontWeight: FontWeight.bold,
      ),
    ),
    const SizedBox(width: 40),
  ],
)
```

### Filled Button
```dart
FilledButton.icon(
  icon: const Icon(Icons.check_circle),
  label: const Text('Button Text'),
  onPressed: () {
    // Action here
  },
)
```

### Outlined Button
```dart
OutlinedButton.icon(
  icon: const Icon(Icons.share),
  label: const Text('Share'),
  onPressed: () {
    // Action here
  },
)
```

### Info Container
```dart
Container(
  decoration: BoxDecoration(
    color: riskColor.withOpacity(0.1),
    borderRadius: BorderRadius.circular(12),
    border: Border.all(
      color: riskColor.withOpacity(0.3),
      width: 1,
    ),
  ),
  padding: const EdgeInsets.all(16),
  child: Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Icon(Icons.lightbulb_outline, color: riskColor),
      const SizedBox(width: 12),
      Expanded(
        child: Text(recommendation),
      ),
    ],
  ),
)
```

---

## 🔄 Navigation

### Push Page
```dart
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => const NextPage(),
  ),
)
```

### Pop Page
```dart
Navigator.pop(context)
```

### Replace Page
```dart
Navigator.pushReplacement(
  context,
  MaterialPageRoute(builder: (_) => const HomePage()),
)
```

---

## 🔔 Snackbars

### Success
```dart
ScaffoldMessenger.of(context).showSnackBar(
  const SnackBar(
    content: Text('Success message'),
    backgroundColor: Colors.green,
  ),
)
```

### Error
```dart
ScaffoldMessenger.of(context).showSnackBar(
  const SnackBar(
    content: Text('Error message'),
    backgroundColor: Colors.red,
  ),
)
```

### Info
```dart
ScaffoldMessenger.of(context).showSnackBar(
  const SnackBar(
    content: Text('Info message'),
    backgroundColor: Colors.blue,
  ),
)
```

---

## 🎬 Dialog

### Confirmation Dialog
```dart
showDialog(
  context: context,
  builder: (context) => AlertDialog(
    title: const Text('Konfirmasi'),
    content: const Text('Anda yakin?'),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('Batal'),
      ),
      TextButton(
        onPressed: () {
          Navigator.pop(context);
          // Do action
        },
        child: const Text('Lanjut'),
      ),
    ],
  ),
)
```

---

## 📊 Common Patterns

### ListView with Padding
```dart
ListView(
  padding: const EdgeInsets.all(16),
  children: [
    // Items here
  ],
)
```

### SingleChildScrollView
```dart
SingleChildScrollView(
  child: Padding(
    padding: const EdgeInsets.all(16),
    child: Column(
      children: [
        // Content here
      ],
    ),
  ),
)
```

### GridView
```dart
GridView.builder(
  shrinkWrap: true,
  physics: const NeverScrollableScrollPhysics(),
  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
    crossAxisCount: 2,
    crossAxisSpacing: 12,
    mainAxisSpacing: 12,
    childAspectRatio: 1,
  ),
  itemCount: items.length,
  itemBuilder: (context, index) {
    return // Item widget
  },
)
```

### Horizontal Scroll
```dart
SingleChildScrollView(
  scrollDirection: Axis.horizontal,
  child: Row(
    children: [
      for (int i = 0; i < items.length; i++) ...[
        ItemWidget(),
        if (i < items.length - 1) const SizedBox(width: 12),
      ],
    ],
  ),
)
```

---

## 🛠️ Debug Tips

### Check Widget Tree
```dart
// Add this in build method temporarily
debugPrintBeginFrame('MyWidget');
```

### Print State
```dart
print('Debug: $variable');
```

### Hot Reload Shortcut
```
Flutter: Hot Reload (Ctrl+Shift+,)
Flutter: Hot Restart (Ctrl+Shift+.)
```

---

## 🎯 Riverpod Quick Ref

### Watch Provider
```dart
final data = ref.watch(myProvider);
```

### Read Provider
```dart
final data = ref.read(myProvider);
```

### Modify Provider
```dart
ref.read(myProvider.notifier).updateValue(newValue);
```

### Consumer Widget
```dart
class MyWidget extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final data = ref.watch(myProvider);
    return // Widget
  }
}
```

---

## ✅ Pre-Flight Checklist

- [ ] `flutter pub get` berjalan tanpa error
- [ ] Semua imports sudah benar
- [ ] Tidak ada unused variables
- [ ] Semua widget tersentralisasi di folder yang tepat
- [ ] Tidak ada hardcoded strings (lebih baik di constants)
- [ ] Responsive untuk berbagai ukuran layar
- [ ] Error handling sudah implemented
- [ ] All providers sudah setup dengan benar

---

## 🚀 Build Commands

```bash
# Debug build
flutter run

# Release build APK
flutter build apk --release

# Release build iOS
flutter build ios --release

# Web build
flutter build web --release

# Clean build
flutter clean && flutter pub get && flutter run
```

---

## 📝 Naming Conventions

```dart
// Pages
class HomePage extends StatelessWidget {}
class ScreeningPage extends ConsumerWidget {}

// Widgets
class HealthDashboard extends StatelessWidget {}
class _QuestionCard extends StatelessWidget {}

// Providers
final answersProvider = StateProvider<List<int>>((ref) => []);
final resultProvider = StateNotifierProvider<ResultNotifier, Result>((ref) => ResultNotifier());

// Functions/Methods
void _buildHeader(BuildContext context) {}
Widget _buildFeatureCard(...) {}

// Variables
final screenWidth = MediaQuery.of(context).size.width;
```

---

## 🎓 Useful Resources

- **Flutter Docs**: https://flutter.dev/docs
- **Dart Docs**: https://dart.dev/guides
- **Material 3**: https://m3.material.io
- **Riverpod**: https://riverpod.dev
- **Flutter Gems**: https://pub.dev

---

## 💡 Pro Tips

1. **Use const where possible** - Better performance
   ```dart
   const SizedBox(height: 16)
   ```

2. **Extract large widgets** - Better readability
   ```dart
   Widget _buildHeaderSection() => // widget
   ```

3. **Use theme for colors** - Consistent design
   ```dart
   Colors.indigo[600] // instead of hardcoding
   ```

4. **Add comments for complex logic**
   ```dart
   // This calculates the average score
   final avg = scores.fold(0, (a, b) => a + b) / scores.length;
   ```

5. **Test on multiple devices** - Different screen sizes matter

---

**Last Updated:** January 14, 2026
**Version:** 1.0
**Status:** ✅ Ready to Use
