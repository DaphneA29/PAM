import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('App basic smoke test', (WidgetTester tester) async {
    // Basic test - just verify no errors
    expect(true, true);
  });
}