# 🚀 Quick Start Guide - Phase 2 Features

## 📦 Installation

### 1. Update Dependencies
```bash
cd insightmind
flutter pub get
```

This will install the new PDF packages:
- `pdf: ^3.10.0`
- `printing: ^5.11.0`
- `syncfusion_flutter_pdf: ^23.1.36`

### 2. Run on Your Device

**Mobile:**
```bash
flutter run
```

**Chrome (Web/Desktop View):**
```bash
flutter run -d chrome
```

**Windows Desktop:**
```bash
flutter run -d windows
```

**macOS Desktop:**
```bash
flutter run -d macos
```

---

## 📱 Testing Responsive Layouts

### Option 1: Chrome DevTools
1. Run: `flutter run -d chrome`
2. Press `Ctrl+Shift+I` (or `Cmd+Option+I` on Mac)
3. Click device toggle (top-left)
4. Select different devices or drag to resize
5. Watch layout adapt in real-time

### Option 2: Resize Browser Window
1. Run: `flutter run -d chrome`
2. Drag window edges to resize
3. Watch breakpoints activate:
   - < 600px → Mobile layout
   - 600-1200px → Tablet layout  
   - ≥ 1200px → Desktop layout

### Option 3: Emulator
1. Open Android emulator or iOS simulator
2. Run: `flutter run`
3. Works on any screen size

---

## 📄 How to Use PDF Reports

### Generate a Report

1. **From Home Page:**
   - Click the new "Laporan" (Report) button
   - Opens Report Page

2. **From Result Page:**
   - After screening, click "Download PDF" button
   - Opens Report Page

3. **In Report Page:**
   - View statistics summary
   - See screening history
   - Read recommendations
   - Click "Download PDF" to save
   - Click "Cetak" to print

### PDF Contents
The generated PDF includes:
- Header with title and date/time
- Summary statistics (total screenings, average score, counts)
- Screening history table
- Personalized recommendations
- Footer with disclaimer

### Download/Save PDF
- Click "Download PDF" button
- Choose download location (on desktop)
- Open with any PDF reader
- Share with healthcare provider

---

## 🎨 Responsive Features Demo

### Home Page Quick Actions
**Mobile View** - 4 buttons in 2×2 grid:
```
┌─────────────────┐
│ Screening │History│
│ Report   │Profile│
└─────────────────┘
```

**Desktop View** - 4 buttons in 1×4 row:
```
┌────────────────────────────────┐
│Screening│History│Report│Profile│
└────────────────────────────────┘
```

### Features Grid
**Mobile** - 4 features in 2×2:
```
┌──────────┐ ┌──────────┐
│  Mood    │ │Analytics │
└──────────┘ └──────────┘
┌──────────┐ ┌──────────┐
│  Tips    │ │ Profile  │
└──────────┘ └──────────┘
```

**Desktop** - 4 features in 1×4:
```
┌────────┐ ┌──────────┐ ┌──────┐ ┌────────┐
│ Mood   │ │Analytics │ │Tips  │ │Profile │
└────────┘ └──────────┘ └──────┘ └────────┘
```

### History Summary Card
**Mobile** - Stacked vertically:
```
Total Screening: 4
───────────────
Rata-rata Skor: 35.8
```

**Desktop** - Side by side:
```
Total Screening: 4  │  Rata-rata Skor: 35.8
```

### Result Buttons
**Mobile** - Stacked:
```
├─ Download PDF
├─ Bagikan
└─ Selesai
```

**Desktop** - Side by side:
```
Download PDF │ Bagikan │ Selesai
```

---

## ⚙️ Configuration

### Breakpoints (in `app_constants.dart`)
```dart
static const double mobileMaxWidth = 600;      // Mobile threshold
static const double tabletMaxWidth = 1200;     // Tablet threshold
static const double desktopMinWidth = 1200;    // Desktop threshold
```

### Padding Values (in `app_constants.dart`)
```dart
static const double paddingMobile = 16.0;      // Small screens
static const double paddingDesktop = 24.0;     // Large screens
```

### Change Breakpoints
Edit `lib/core/constants/app_constants.dart`:
```dart
// Example: Make mobile max 700px instead of 600px
static const double mobileMaxWidth = 700;
```

---

## 🔧 Common Customizations

### Change Button Width (Result Page)
File: `lib/features/insightmind/presentation/pages/result_page.dart`
```dart
// Line ~270: Change 150 to your desired width
width: 150,  // Change this value
```

### Change Grid Columns
File: `lib/features/insightmind/presentation/pages/home_page.dart`
```dart
// Line ~70: Quick actions grid
crossAxisCount: isMobile ? 2 : (isTablet ? 3 : 4),  // Adjust these numbers

// Line ~120: Features grid
crossAxisCount: isMobile ? 2 : 4,  // Adjust these numbers
```

### Change Padding Values
File: `lib/core/constants/app_constants.dart`
```dart
static const double paddingMobile = 16.0;      // Adjust mobile padding
static const double paddingDesktop = 24.0;     // Adjust desktop padding
```

### Customize PDF Layout
File: `lib/features/insightmind/presentation/pages/report_page.dart`
```dart
// Edit _generatePdf() method to customize:
// - Colors
// - Fonts
// - Spacing
// - Sections
```

---

## 📊 File Reference

### Key Files to Understand

1. **Report Page** - PDF generation
   - Location: `lib/features/insightmind/presentation/pages/report_page.dart`
   - Size: 500+ lines
   - Key method: `_generatePdf()`

2. **Home Page** - Quick actions & features
   - Location: `lib/features/insightmind/presentation/pages/home_page.dart`
   - Updated methods: `_buildQuickActions()`, `_buildFeaturesSection()`

3. **Result Page** - Action buttons
   - Location: `lib/features/insightmind/presentation/pages/result_page.dart`
   - New method: `_buildActionButtonsSection()`

4. **Constants** - Responsive configuration
   - Location: `lib/core/constants/app_constants.dart`
   - Breakpoints and padding values

---

## 🧪 Testing Checklist

### Functionality Tests
- [ ] Navigate to each page successfully
- [ ] Report button visible on home page
- [ ] Can click "Download PDF" and see dialog
- [ ] PDF generates without errors
- [ ] History summary shows correctly

### Responsive Tests
- [ ] Mobile: 2-column layouts work
- [ ] Tablet: 3-column layouts work
- [ ] Desktop: 4-column layouts work
- [ ] Padding scales appropriately
- [ ] Buttons resize correctly
- [ ] Text remains readable

### Browser Tests
- [ ] Chrome: Works on desktop
- [ ] Chrome: Works on mobile view
- [ ] Firefox: No issues
- [ ] Safari: No issues
- [ ] Resize window: Smooth transitions

### PDF Tests
- [ ] PDF generates successfully
- [ ] All sections visible
- [ ] Statistics calculated correctly
- [ ] Table formats properly
- [ ] Text is readable
- [ ] Can save file
- [ ] Can print file

---

## 🆘 Troubleshooting

### Problem: PDF button not showing
**Solution**: Make sure `report_page.dart` is imported in the current page
```dart
import 'report_page.dart';
```

### Problem: Layout not changing on resize
**Solution**: Make sure you're using `MediaQuery.of(context).size.width`
```dart
final isMobile = MediaQuery.of(context).size.width < 600;
```

### Problem: PDF won't download
**Solution**: Check that `printing` package is in pubspec.yaml
```bash
flutter pub get
```

### Problem: Buttons overlap on mobile
**Solution**: Change button layout to column:
```dart
child: isMobile 
  ? Column(...)  // Stacked vertically
  : Wrap(...)    // Wrapped horizontally
```

### Problem: Too much/too little padding
**Solution**: Adjust padding constants in `app_constants.dart`:
```dart
static const double paddingMobile = 16.0;    // Increase/decrease
static const double paddingDesktop = 24.0;   // Increase/decrease
```

---

## 📚 Documentation Files

| File | Purpose |
|------|---------|
| RESPONSIVE_DESKTOP_GUIDE.md | Detailed responsive implementation guide |
| PHASE_2_IMPLEMENTATION_SUMMARY.md | What's new in Phase 2 |
| VISUAL_CHANGES_GUIDE.md | Before/after layout comparisons |
| DOCUMENTATION_INDEX.md | Complete documentation index |
| app_constants.dart | Responsive configuration |

---

## 🎯 Next Steps After Setup

1. **Test on different devices**
   - Mobile emulator
   - Chrome with DevTools
   - Desktop version

2. **Customize for your needs**
   - Change colors/themes
   - Adjust breakpoints
   - Modify PDF layout

3. **Connect real data**
   - Firebase/Supabase
   - Local database
   - User authentication

4. **Add features**
   - Email reports
   - Data export
   - Advanced analytics

---

## 🤝 Support

**Having issues?**
1. Check the troubleshooting section above
2. Review RESPONSIVE_DESKTOP_GUIDE.md for details
3. Check example code in report_page.dart
4. Look at app_constants.dart for configuration

**Want to customize?**
1. Identify which file to edit (see File Reference)
2. Follow the customization examples above
3. Test on different screen sizes
4. Verify PDF output if applicable

---

## 📱 Quick Reference Commands

```bash
# Install dependencies
flutter pub get

# Run on mobile
flutter run

# Run on Chrome
flutter run -d chrome

# Run on Windows desktop
flutter run -d windows

# Run on macOS desktop
flutter run -d macos

# Run tests
flutter test

# Build for release
flutter build apk      # Android
flutter build ios      # iOS
flutter build windows  # Windows
```

---

## ✅ Success Indicators

You'll know everything is working when:
- ✅ All 6 pages load without errors
- ✅ Report button visible on home page
- ✅ Can navigate to report page
- ✅ PDF downloads successfully
- ✅ Layout changes on screen resize
- ✅ Mobile view: 2 columns
- ✅ Desktop view: 4 columns
- ✅ Padding scales appropriately

---

**Version**: 1.0.0 Phase 2  
**Last Updated**: 2024  
**Status**: ✅ Production Ready

Start testing now and enjoy your responsive InsightMind app! 🚀
