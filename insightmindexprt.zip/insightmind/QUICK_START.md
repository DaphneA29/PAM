# 🚀 Quick Start Guide - InsightMind

## ⚡ 5 Menit Setup

### Step 1: Persiapan (1 menit)
```bash
cd c:\Users\Pipin\Downloads\insightmind
```

### Step 2: Install Dependencies (2 menit)
```bash
flutter pub get
```

### Step 3: Jalankan App (1 menit)
```bash
flutter run
```

### Step 4: Explore! (1 menit)
- Lihat Home Page
- Click "Screening" untuk test pertanyaan
- Jawab semua pertanyaan
- Lihat Result Page
- Cek History & Profile

---

## 🎯 Fitur Utama

### 1. Home Page
- **Greeting Message** - Pesan sambutan personal
- **Health Dashboard** - Status kesehatan dengan mini stats
- **Quick Actions** - Screening & Riwayat dalam 1 klik
- **Feature Grid** - 4 fitur utama (Mood, Analytics, Tips, Profile)

### 2. Screening
- **Progress Bar** - Track progress jawaban
- **Question Cards** - Pertanyaan dengan numbered badges
- **Option Buttons** - Pilih jawaban dengan visual feedback
- **Submit** - Lihat hasil setelah semua dijawab

### 3. Result
- **Score Display** - Skor besar dan jelas
- **Risk Level** - Indikator warna (Baik/Sedang/Tinggi)
- **Recommendations** - Saran personalisasi
- **Tips** - 4 tips perawatan diri

### 4. History
- **Summary** - Statistik screening
- **List** - Riwayat dengan tanggal & skor
- **Status** - Color-coded indicators

### 5. Profile
- **Personal Info** - Nama, email, tanggal lahir, gender
- **Health Info** - Tinggi, berat badan, status
- **Settings** - Notifikasi, dark mode, bahasa
- **Logout** - Keluar dari akun

---

## 🎨 Design Highlights

### Colors
```
🔵 Indigo (Primary)     - Buttons, Headers
🟢 Green (Good)         - Positive results
🟠 Orange (Medium)      - Caution results
🔴 Red (High)           - Warning results
🌊 Teal (Secondary)     - History, Secondary actions
```

### Buttons
```
[✓ Filled Button]       - Main actions (Screening, Finish)
[  Outlined Button ]    - Secondary actions (Reset, Share)
```

### Cards
```
┌─────────────────────┐
│ With shadow & border│
│ Gradient optional   │
│ Proper padding      │
└─────────────────────┘
```

---

## 📁 File Structure

**Pages** (5 files)
- `home_page.dart` - Dashboard utama
- `screening_page.dart` - Pertanyaan
- `result_page.dart` - Hasil & rekomendasi
- `history_page.dart` - Riwayat
- `profile_page.dart` - Profil

**Widgets** (4 files)
- `health_dashboard.dart` - Gradient card dengan stats
- `statistics_widget.dart` - Statistik 3 metrics
- `health_tips_widget.dart` - Tips scrollable
- `onboarding_widget.dart` - Promo banner

---

## 💻 Common Customizations

### Ubah Greeting Message
```dart
// File: home_page.dart, line 69
Text(
  'Selamat datang kembali!',  // ← Ubah di sini
  style: Theme.of(context).textTheme.titleLarge?.copyWith(
    fontSize: 24,
    fontWeight: FontWeight.bold,
  ),
),
```

### Ubah Warna Primary
```dart
// File: src/app.dart, line 19
seedColor: Colors.indigo,  // ← Ubah ke Colors.teal, dll
```

### Ubah Spacing
```dart
// Ganti angka dalam SizedBox
const SizedBox(height: 24)  // ← Ubah ke 16, 20, dll
const EdgeInsets.all(16)    // ← Ubah padding
```

### Ubah Font Size
```dart
// Ganti fontSize value
fontSize: 24,  // ← Ubah ukuran
```

---

## 🧪 Testing

### Test Screening Flow
1. Klik "Screening" button di home
2. Jawab 1 pertanyaan
3. Lihat progress bar update
4. Jawab semua pertanyaan
5. Klik "Lihat Hasil"
6. Lihat result page dengan score & rekomendasi

### Test Navigation
1. Dari home → klik "Screening"
2. Dari screening → klik back button
3. Dari home → klik "Riwayat"
4. Dari history → klik feature cards di home
5. Dari profile → klik logout

### Test Responsive
1. Rotate device (landscape/portrait)
2. Test di tablet jika ada
3. Zoom di browser (web)

---

## 🔍 Debug Tips

### Hot Reload
```
Ctrl+Shift+, (reload live)
Ctrl+Shift+. (full restart)
```

### Print Debug Info
```dart
print('Debug: $variable');
print('Score: ${result.score}');
```

### Check Widget Tree
```
Toggle widget inspector: Ctrl+Alt+W
```

### Clear Cache
```bash
flutter clean
flutter pub get
flutter run
```

---

## 📱 Keyboard Shortcuts

| Action | Shortcut |
|--------|----------|
| Hot Reload | Ctrl+Shift+, |
| Hot Restart | Ctrl+Shift+. |
| Open DevTools | Ctrl+Shift+P → DevTools |
| Inspect Widget | Ctrl+Alt+W |
| Performance | Ctrl+Alt+P |

---

## 🎓 Learning Paths

### For Designers
1. Buka `DESIGN_PREVIEW.md`
2. Lihat color palette & typography
3. Review component examples
4. Check spacing guidelines

### For Developers
1. Buka `DEVELOPER_CHEATSHEET.md`
2. Copy-paste components as needed
3. Read code comments
4. Check `WIDGET_INTEGRATION_GUIDE.md`

### For Project Managers
1. Buka `COMPLETION_REPORT.md`
2. Review project metrics
3. Check quality assurance section
4. See deployment readiness

---

## 🚀 What's Next?

### Immediate
- ✅ Test aplikasi
- ✅ Customize branding
- ✅ Review design

### Short-term
- Add real database
- Add notifications
- Add more screens

### Long-term
- Chart dashboards
- PDF export
- Online consultation
- Community features

---

## ❓ FAQ

**Q: Bagaimana cara change warna?**
A: Edit `Colors.indigo` di `src/app.dart` atau langsung di widget dengan `Colors.yourColor`

**Q: Bisa menambah pertanyaan baru?**
A: Ya, update data di provider atau database kamu

**Q: Bisa integrate dengan API?**
A: Ya, gunakan `http` package dan update provider

**Q: Bisa dark mode?**
A: Bisa, tambahkan dark theme di `app.dart`

**Q: Responsive di semua device?**
A: Sudah responsive, tapi perlu test di berbagai ukuran

---

## 📞 Quick Links

| Doc | Purpose |
|-----|---------|
| `COMPLETION_REPORT.md` | Overview lengkap |
| `FEATURE_GUIDE.md` | Penjelasan fitur |
| `DEVELOPER_CHEATSHEET.md` | Quick reference |
| `DESIGN_PREVIEW.md` | Visual guide |
| `WIDGET_INTEGRATION_GUIDE.md` | Widget docs |

---

## ✨ Pro Tips

1. **Gunakan const** untuk better performance
   ```dart
   const SizedBox(height: 16)  // Good
   SizedBox(height: 16)        // Not optimal
   ```

2. **Extract widgets** untuk cleaner code
   ```dart
   Widget _buildHeader() => // widget
   ```

3. **Use theme colors** untuk consistency
   ```dart
   Colors.indigo[600]  // Theme color
   0xFF3F51B5          // Hardcoded (avoid)
   ```

4. **Add comments** untuk logic kompleks
   ```dart
   // Calculate average risk score
   ```

5. **Test frequently** untuk catch bugs early
   ```bash
   flutter run
   ```

---

## 🎯 Success Checklist

- [ ] `flutter pub get` berjalan tanpa error
- [ ] App dapat dijalankan dengan `flutter run`
- [ ] Semua pages dapat diakses
- [ ] Navigation berfungsi
- [ ] Buttons responsive
- [ ] Text readable
- [ ] Colors muncul dengan benar
- [ ] Responsive di berbagai ukuran layar

---

## 🔐 Important Notes

⚠️ **Sample Data** - Data masih dummy, perlu database
⚠️ **No Persistence** - Data hilang saat restart
⚠️ **No Error Handling** - UI ready, logic perlu di-improve
⚠️ **No Push Notifications** - Ready to integrate

---

## 📈 Performance Tips

1. **Use const constructors** where possible
2. **Optimize widget rebuilds** dengan shouldRebuild
3. **Lazy load images** dengan cached_network_image
4. **Profile performance** dengan DevTools

---

## 🎉 You're Ready!

Sekarang aplikasi sudah siap untuk:
- Development & testing
- Customization
- Deployment
- Integration dengan backend

**Happy Coding! 🚀**

---

**InsightMind Quick Start v1.0**
*Last Updated: January 14, 2026*
