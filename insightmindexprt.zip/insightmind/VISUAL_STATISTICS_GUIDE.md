# 📊 InsightMind - Visual Statistics Flow Guide

## 🎯 Permintaan User & Solusi

**User**: "pada setiap tombol berikan fungsi statistik dan algonya sesuai dengan tombol yang ada di halaman"

**Solusi Lengkap**: Setiap tombol di aplikasi sekarang memiliki algoritma statistik yang terintegrasi

---

## 📱 HOME PAGE - Dashboard Overview

```
┌─────────────────────────────────────┐
│         Selamat datang kembali!      │
│   Pantau kesehatan mental Anda       │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│        🏥 Health Dashboard           │
└─────────────────────────────────────┘

┌──────────┬──────────┬──────────┐
│ Screening│ Riwayat  │ Analitik │
│ 📋      │ 📊      │ 📈      │
├──────────┼──────────┼──────────┤
│ Laporan  │ Profil   │          │
│ 📄      │ 👤      │          │
└──────────┴──────────┴──────────┘

┌─────────────────────────────────────┐
│      📊 STATISTIK SUMMARY           │
│  ─────────────────────────────────  │
│  • Total Screening: 4               │
│  • Rata-rata Skor: 35.8            │
│  • Status Tren: Menurun ⬇️          │
│  ─────────────────────────────────  │
│  Risiko:  [4] [2] [3]              │
│           Baik Sedang Tinggi        │
└─────────────────────────────────────┘

┌──────────────────────────────────┐
│     ✨ FITUR UNGGULAN            │
│ [Mood] [Analitik] [Tips] [Profil]│
└──────────────────────────────────┘
```

---

## ❓ SCREENING PAGE - Algoritma Kalkulasi

### User Journey
```
┌─────────────────────────────────┐
│  Pertanyaan 1: Bagaimana mood?  │
│  [😞] [😐] [😊] [😄] [😆]      │
│  JAWABAN DIPILIH: 2             │
└─────────────────────────────────┘

┌─────────────────────────────────┐
│  Pertanyaan 2: Tingkat stres?   │
│  [1] [2] [3] [4] [5]            │
│  JAWABAN DIPILIH: 4             │
└─────────────────────────────────┘
     ... (9 pertanyaan total)

┌─────────────────────────────────┐
│  BUTTON: Lihat Hasil 📊         │
└─────────────────────────────────┘
```

### Algoritma Dijalankan
```
STEP 1: Kumpulkan Jawaban
  ├─ Pertanyaan 1: 2
  ├─ Pertanyaan 2: 4
  ├─ Pertanyaan 3: 3
  ├─ Pertanyaan 4: 2
  ├─ Pertanyaan 5: 5
  ├─ Pertanyaan 6: 3
  ├─ Pertanyaan 7: 4
  ├─ Pertanyaan 8: 2
  └─ Pertanyaan 9: 1

STEP 2: Hitung Total Skor
  Total = 2+4+3+2+5+3+4+2+1 = 26

STEP 3: Aplikasikan calculateRiskLevel(26)
  26 < 30 → RISIKO BAIK ✅🟢

STEP 4: Buat ScreeningResult
  {
    score: 26,
    riskLevel: "Baik",
    date: 2024-01-15 14:30:00,
    answers: [2,4,3,2,5,3,4,2,1]
  }

STEP 5: Simpan ke screeningHistoryProvider
  screeningHistoryProvider += new ScreeningResult

STEP 6: Tampilkan Result Page
  Navigasi ke ResultPage dengan hasil
```

---

## 🎯 RESULT PAGE - Rekomendasi Dinamis

### Skenario: Skor 26 (Baik)

```
┌──────────────────────────────┐
│    SKOR ANDA: 26             │
│  TINGKAT RISIKO: BAIK 🟢     │
└──────────────────────────────┘

┌──────────────────────────────┐
│  ✅ REKOMENDASI UNTUK ANDA   │
├──────────────────────────────┤
│ 1. 🟢 Status Baik: Pertahankan
│    gaya hidup sehat          │
│                              │
│ 2. ✨ Terus jaga keseimbang- │
│    an hidup dan pekerjaan    │
│                              │
│ 3. 💪 Lakukan aktivitas      │
│    fisik yang disukai        │
│                              │
│ 4. 🧠 Praktik mindfulness    │
│    atau meditasi             │
│                              │
│ 5. 📱 Jaga hubungan sosial   │
│    yang positif              │
│                              │
│ 6. 👨‍⚕️ Lakukan screening      │
│    berkala setiap 1-2 bulan  │
└──────────────────────────────┘

┌──────────────────────────────┐
│  📋 TIPS PERAWATAN DIRI      │
│ ├─ 😴 Tidur Cukup           │
│ ├─ 💪 Olahraga Teratur      │
│ ├─ 🥗 Makan Sehat           │
│ └─ 👥 Interaksi Sosial      │
└──────────────────────────────┘
```

### Algoritma getRecommendations()
```
INPUT: score=26, answers=[2,4,3,2,5,3,4,2,1]

CHECK RISK LEVEL:
  if (26 < 30) {
    return REKOMENDASI_BAIK  // 6 rekomendasi
  }
```

---

## 📜 HISTORY PAGE - Statistik dari Riwayat

### Real Data dari screeningHistoryProvider

```
┌─────────────────────────────────┐
│    RIWAYAT SCREENING            │
├─────────────────────────────────┤
│                                 │
│  📊 STATISTIK RINGKAS           │
│  ─────────────────────────────  │
│  Total Screening: 4             │
│  Rata-rata Skor: 35.8          │
│  Status Tren: Menurun ⬇️        │
│                                 │
│  Risiko:                        │
│  ├─ Baik (3): ███░░░            │
│  ├─ Sedang (0): ░░░░░           │
│  └─ Tinggi (1): █░░░░           │
│                                 │
├─────────────────────────────────┤
│   HASIL SCREENING TERAKHIR      │
├─────────────────────────────────┤
│ 📅 15 Jan 2024, 14:30 - Skor 26│
│    Status: BAIK 🟢              │
│                                 │
│ 📅 14 Jan 2024, 10:15 - Skor 32│
│    Status: SEDANG 🟠            │
│                                 │
│ 📅 13 Jan 2024, 09:00 - Skor 28│
│    Status: BAIK 🟢              │
│                                 │
│ 📅 12 Jan 2024, 16:45 - Skor 52│
│    Status: TINGGI 🔴            │
│                                 │
└─────────────────────────────────┘
```

### Algoritma calculateStatistics()

```
INPUT: screeningHistory = [
  {score: 26, level: "Baik"},
  {score: 32, level: "Sedang"},
  {score: 28, level: "Baik"},
  {score: 52, level: "Tinggi"}
]

PROCESS:
├─ Total Screening = 4
├─ Total Score = 26+32+28+52 = 138
├─ Average Score = 138/4 = 34.5
├─ High Risk Count = 1 (52)
├─ Moderate Risk Count = 1 (32)
├─ Low Risk Count = 2 (26,28)
│
├─ High Risk % = (1/4) × 100 = 25%
├─ Moderate Risk % = (1/4) × 100 = 25%
├─ Low Risk % = (2/4) × 100 = 50%
│
└─ Trend = recent(26) < previous(32) = Menurun ⬇️

OUTPUT: StatisticsData {
  totalScreenings: 4,
  averageScore: 34.5,
  highRiskCount: 1,
  moderateRiskCount: 1,
  lowRiskCount: 2,
  ...
}
```

---

## 📈 ANALYTICS PAGE - Analisis Mendalam (NEW)

### Tab 1: Overall Statistics
```
┌──────────────────────────────────┐
│   📊 STATISTIK KESELURUHAN       │
├──────────────────────────────────┤
│ • Total Screening: 4    📊       │
│ • Rata-rata: 34.5       📈       │
│ • Maksimal: 52          ⬆️        │
│ • Minimal: 26           ⬇️        │
│ • Tren: Menurun         📉       │
└──────────────────────────────────┘
```

### Tab 2: Risk Distribution
```
┌──────────────────────────────────┐
│  🎯 DISTRIBUSI RISIKO            │
├──────────────────────────────────┤
│ Risiko Tinggi: 1 [25%]           │
│ ███░░░░░░░░░░░░░░░░░░░░░░░     │
│                                  │
│ Risiko Sedang: 1 [25%]           │
│ ███░░░░░░░░░░░░░░░░░░░░░░░     │
│                                  │
│ Risiko Baik: 2 [50%]             │
│ ██████░░░░░░░░░░░░░░░░░░░░░    │
│                                  │
└──────────────────────────────────┘
```

### Tab 3: Component Analysis
```
┌──────────────────────────────────┐
│  🔍 ANALISIS KOMPONEN            │
├──────────────────────────────────┤
│ MOOD/DEPRESI: 2.7 (dari 10)     │
│ 🔵 ██░░░░░░░░░░░░░░░░           │
│                                  │
│ KECEMASAN: 3.5 (dari 10)        │
│ 🟣 ███░░░░░░░░░░░░░░░░░          │
│                                  │
│ STRESS: 2.3 (dari 10)           │
│ 🔴 ██░░░░░░░░░░░░░░░░░░░         │
│                                  │
└──────────────────────────────────┘

ALGORITMA analyzeAnswerPatterns():
  Mood = (ans[0] + ans[1] + ans[2]) / 3
  Anxiety = (ans[3] + ans[4] + ans[5]) / 3
  Stress = (ans[6] + ans[7] + ans[8]) / 3
```

### Tab 4: Score Range
```
┌──────────────────────────────────┐
│  📏 JANGKAUAN SKOR               │
├──────────────────────────────────┤
│ Minimum: 26    │ Rata-rata: 34.5│ Maksimum: 52
│ 🟢              │ 🟡              │ 🔴
│                                  │
│ SKALA RISIKO:                    │
│ ╔═══════════════╗                │
│ ║ 🟢🟢🟢│🟡🟡│🔴 ║                │
│ ╚═══════════════╝                │
│ 0  10  20  30  40  50  60  70  80│
│  Baik   Sedang         Tinggi     │
│                                  │
└──────────────────────────────────┘
```

### Tab 5: Recent Screenings
```
┌──────────────────────────────────┐
│  ⏰ SCREENING TERBARU             │
├──────────────────────────────────┤
│ 📅 15 Jan 2024, 14:30            │
│    Skor: 26    │  🟢 BAIK        │
│ ───────────────────────────────  │
│ 📅 14 Jan 2024, 10:15            │
│    Skor: 32    │  🟠 SEDANG      │
│ ───────────────────────────────  │
│ 📅 13 Jan 2024, 09:00            │
│    Skor: 28    │  🟢 BAIK        │
│ ───────────────────────────────  │
│ 📅 12 Jan 2024, 16:45            │
│    Skor: 52    │  🔴 TINGGI      │
│ ───────────────────────────────  │
│ 📅 11 Jan 2024, 11:20            │
│    Skor: 38    │  🟠 SEDANG      │
│                                  │
└──────────────────────────────────┘
```

---

## 🔗 Data Flow Diagram

```
                    SCREENING PAGE
                         │
                         ↓
              Kumpulkan 9 Jawaban
                         │
                         ↓
                  Hitung Total Skor
                    (Sum Answers)
                         │
                         ↓
           calculateRiskLevel(score)
                 │
         ┌───────┼───────┐
         ↓       ↓       ↓
        Tinggi Sedang  Baik
        (≥50)  (≥30)   (<30)
         │       │       │
         └───────┼───────┘
                 ↓
          Buat ScreeningResult
          + Simpan ke Provider
                 │
                 ↓
           RESULT PAGE
                 │
          getRecommendations()
                 │
         6+ Rekomendasi Dinamis
                 │
                 ↓
    User dapat lihat Rekomendasi
                 │
         ┌───────┼────────┐
         ↓       ↓        ↓
      HISTORY ANALYTICS  REPORT
         │       │        │
         ├─► calculateStatistics()
         │       │        │
    Agregasi    │    Export PDF
         │       │        │
         ├─► analyzeAnswerPatterns()
         │       │        │
      Trend   Component  Stats
         │       │        │
         └───────┼────────┘
                 ↓
         HOME PAGE DASHBOARD
              (Summary)
```

---

## 🎓 Ringkasan Algoritma Setiap Tombol

### 1️⃣ Screening Button
```
ALGORITMA: calculateRiskLevel(score)
INPUT:  9 jawaban screening
PROSES: Sum jawaban → tentukan risiko
OUTPUT: Tinggi/Sedang/Baik
NEXT:   Simpan & tampilkan rekomendasi
```

### 2️⃣ Riwayat Button
```
ALGORITMA: calculateStatistics()
INPUT:  Semua screening results
PROSES: Agregasi, hitung rata-rata, trend
OUTPUT: StatisticsData
NEXT:   Tampilkan di history page
```

### 3️⃣ Analitik Button
```
ALGORITMA: analyzeAnswerPatterns() +
           calculateStatistics()
INPUT:  Semua screening hasil
PROSES: Breakdown mood/anxiety/stress,
        trend, distribusi risiko
OUTPUT: Comprehensive analytics
NEXT:   Tampilkan di analytics page
```

### 4️⃣ Laporan Button
```
ALGORITMA: calculateStatistics() +
           getRecommendations()
INPUT:  Screening data
PROSES: Generate PDF report
OUTPUT: Exportable PDF
NEXT:   Download atau bagikan
```

### 5️⃣ Profil Button
```
ALGORITMA: -
INPUT:  User data
PROSES: Kelola profil & setting
OUTPUT: Updated user profile
NEXT:   Simpan ke database
```

---

## ✨ Result Summary

```
┌─────────────────────────────────────┐
│   ✅ PHASE 3 COMPLETION SUMMARY      │
├─────────────────────────────────────┤
│                                     │
│ ✓ Risk Level Calculation            │
│ ✓ Recommendations Engine            │
│ ✓ Statistics Aggregation            │
│ ✓ Trend Analysis                    │
│ ✓ Component Breakdown               │
│ ✓ Analytics Dashboard               │
│ ✓ Responsive Design                 │
│ ✓ Zero Compilation Errors           │
│                                     │
├─────────────────────────────────────┤
│  ALGORITMA TERINTEGRASI:            │
│  • calculateRiskLevel()             │
│  • calculateStatistics()            │
│  • getRecommendations()             │
│  • analyzeAnswerPatterns()          │
│  • getTrendStatus()                 │
│                                     │
├─────────────────────────────────────┤
│  PAGES DENGAN STATISTIK:            │
│  • Home Page (Summary)              │
│  • Screening Page (Calculation)     │
│  • Result Page (Recommendations)    │
│  • History Page (Aggregation)       │
│  • Analytics Page (Complete)        │
│                                     │
└─────────────────────────────────────┘
```

---

**Status**: ✅ READY FOR PRODUCTION

Setiap tombol sekarang memiliki algoritma statistik yang sesuai dengan fungsinya!
