# InsightMind - Mental Health Screening App

## 📱 Deskripsi
InsightMind adalah aplikasi Flutter untuk screening kesehatan mental yang user-friendly dengan tampilan menarik dan fitur lengkap.

## 🎯 Fitur Utama

### 1. **Home Page** (`home_page.dart`)
- Halaman utama dengan greeting message
- Health dashboard dengan status kesehatan mental
- Quick action buttons untuk screening dan riwayat
- Feature grid dengan 4 fitur utama:
  - Mood Tracker
  - Analitik
  - Tips
  - Profil

### 2. **Screening Page** (`screening_page.dart`)
- Tampilan pertanyaan dengan progress indicator
- Progress bar visual yang menarik
- Custom question card dengan design yang elegant
- Interactive option buttons dengan state indicator
- Button untuk melihat hasil dan reset jawaban

### 3. **Result Page** (`result_page.dart`)
- Menampilkan skor dan tingkat risiko dengan color coding
- Gradient background sesuai risiko level
- Rekomendasi personalisasi berdasarkan hasil
- Tips perawatan diri dengan icon dan deskripsi
- Share functionality untuk hasil screening

### 4. **History Page** (`history_page.dart`)
- Riwayat screening dengan tanggal dan skor
- Summary card dengan statistik total screening
- List view dari hasil screening sebelumnya
- Color indicator untuk status kesehatan

### 5. **Profile Page** (`profile_page.dart`)
- Informasi pribadi (nama, email, tanggal lahir, gender)
- Informasi kesehatan (tinggi badan, berat badan)
- Settings (notifikasi, mode gelap, bahasa)
- Logout button

## 🎨 Widgets Buat Sendiri

### Health Dashboard (`health_dashboard.dart`)
- Gradient card dengan status kesehatan
- Mini stats dengan icon dan value
- Responsive layout

### Statistics Widget (`statistics_widget.dart`)
- Menampilkan statistik minggu ini
- 3 metric cards (Screening, Avg Score, Completed)
- Icon dan color yang eye-catching

### Health Tips Widget (`health_tips_widget.dart`)
- Horizontal scrollable tips
- 4 tips kesehatan dengan icon
- Colorful design untuk setiap tip

## 🎭 Design System

### Color Palette
- **Primary**: Indigo (`Colors.indigo`)
- **Secondary**: Teal (`Colors.teal`)
- **Accent Colors**: Orange, Blue, Purple, Pink, Green
- **Neutral**: Gray shades

### Typography
- **Title Large**: 24pt, Bold (untuk header main)
- **Title Medium**: 18pt, Bold (untuk section title)
- **Body Medium**: 14pt, Regular (body text)
- **Small**: 11-13pt (supporting text)

### Spacing
- Large gaps: 24pt
- Medium gaps: 16-20pt
- Small gaps: 8-12pt

### Border Radius
- Large containers: 16pt
- Medium containers: 12pt
- Small elements: 8pt

## 📦 Dependencies Utama
```yaml
flutter_riverpod: ^2.0.0        # State management
table_calendar: ^3.0.9          # Calendar widget (future)
fl_chart: ^1.1.1                # Charts untuk analitik
google_fonts: ^5.1.0            # Custom fonts
intl: ^0.18.0                   # Localization (ID)
shared_preferences: ^2.1.1      # Local storage
hive: ^2.2.3                    # Database
```

## 📂 Struktur Folder
```
lib/
├── main.dart                   # Entry point
├── src/
│   └── app.dart               # App configuration
└── features/
    └── insightmind/
        ├── data/              # Data layer
        ├── domain/            # Domain layer
        └── presentation/
            ├── pages/         # Screen pages
            │   ├── home_page.dart
            │   ├── screening_page.dart
            │   ├── result_page.dart
            │   ├── history_page.dart
            │   └── profile_page.dart
            ├── widgets/       # Reusable widgets
            │   ├── health_dashboard.dart
            │   ├── statistics_widget.dart
            │   ├── health_tips_widget.dart
            └── providers/     # Riverpod providers
```

## 🚀 Cara Menjalankan

1. Install dependencies:
```bash
flutter pub get
```

2. Jalankan aplikasi:
```bash
flutter run
```

3. Build APK:
```bash
flutter build apk --release
```

## 💡 Fitur yang Bisa Dikembangkan
- Integrasi dengan API backend
- Local notification untuk reminder screening
- Export data ke PDF
- Multi-language support
- Dark mode theme
- Chart visualization untuk trend analysis
- Konsultasi online dengan psikolog

## 🎓 Learning Resources
- Flutter Documentation: https://flutter.dev/docs
- Riverpod Guide: https://riverpod.dev
- Material Design 3: https://m3.material.io

---

**InsightMind** - Pantau Kesehatan Mental Anda Dengan Mudah ❤️
