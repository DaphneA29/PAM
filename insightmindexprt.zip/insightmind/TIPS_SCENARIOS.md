# Dynamic Tips & Recommendations Guide

## 🟢 Scenario 1: Score 5 (Baik/Good Status)

### Recommendations:
1. 🟢 Status Baik: Pertahankan gaya hidup sehat
2. ✨ Terus jaga keseimbangan hidup dan pekerjaan
3. 💪 Lakukan aktivitas fisik yang Anda nikmati
4. 🧠 Praktek mindfulness atau meditasi
5. 📱 Jaga hubungan sosial yang positif
6. 👨‍⚕️ Lakukan screening berkala setiap 1-2 bulan

### Tips Perawatan Diri (6 tips):
1. 💪 **Tetap Aktif** - Lanjutkan olahraga regular yang Anda sukai
2. 🌙 **Tidur Berkualitas** - Pertahankan rutinitas tidur 7-8 jam setiap malam
3. 🍽️ **Makanan Sehat** - Terus jaga pola makan sehat yang sudah terbukti efektif
4. 👨‍👩‍👧‍👦 **Interaksi Sosial** - Jaga hubungan baik dengan teman, keluarga, dan komunitas
5. 🧠 **Mindfulness Harian** - Lakukan meditasi atau breathing exercise 10 menit setiap hari
6. 📊 **Screening Berkala** - Lakukan screening setiap 1-2 bulan untuk monitoring

---

## 🟠 Scenario 2: Score 15 (Sedang/Moderate Status)

### Recommendations:
1. 🟠 Risiko Sedang: Tingkatkan aktivitas self-care
2. 🏃 Olahraga teratur 30 menit, 3-4 kali per minggu
3. 🥗 Perhatikan pola makan yang sehat dan seimbang
4. 📱 Batasi waktu screen/gadget sebelum tidur
5. 🎨 Lakukan hobi yang menyenangkan secara rutin
6. 📅 Pertimbangkan konsultasi dengan psikolog

### Tips Perawatan Diri (6 tips):
1. 🏃 **Olahraga Rutin** - Lakukan aktivitas fisik 30 menit, 3-4 kali per minggu
2. 😴 **Pola Tidur Stabil** - Tidur 7-8 jam dengan jadwal yang konsisten setiap hari
3. 🥗 **Nutrisi Seimbang** - Makan makanan bergizi: protein, sayur, buah, dan biji-bijian
4. 📱 **Batasi Gadget** - Kurangi screen time minimal 1 jam sebelum tidur
5. 🎨 **Hobi Positif** - Luangkan waktu untuk hobi yang menyenangkan Anda
6. 📅 **Konsultasi Opsional** - Pertimbangkan terapi atau konseling untuk hasil lebih baik

---

## 🔴 Scenario 3: Score 25 (Tinggi/High Risk Status)

### Recommendations:
1. 🔴 Risiko Tinggi: Segera konsultasi dengan profesional kesehatan mental
2. 📞 Hubungi layanan konseling di kampus atau rumah sakit terdekat
3. 😴 Prioritaskan istirahat yang cukup (7-8 jam per hari)
4. 🧘 Lakukan meditasi atau mindfulness 10-15 menit setiap hari
5. 👥 Berbicara dengan orang terpercaya tentang perasaan Anda

### Tips Perawatan Diri (6 tips):
1. 🔴 **Konsultasi Profesional** - Segera hubungi psikolog atau psikiater untuk bantuan profesional
2. 😴 **Istirahat Total** - Tidur minimal 8-9 jam per hari untuk pemulihan optimal
3. 🧘 **Meditasi Intensif** - Lakukan meditasi guided 15-20 menit minimal 2x sehari
4. ⛔ **Hindari Stress** - Kurangi beban kerja, ambil cuti jika diperlukan
5. 👥 **Dukungan Sosial** - Ceritakan perasaan Anda kepada orang terpercaya
6. 💊 **Pantau Kesehatan** - Hindari alkohol, obat-obatan, dan stimulan lainnya

---

## Scoring Guide

### How to Get Different Scores:

**To get Score ~5 (Baik/Good):**
- Answer "Tidak Sama Sekali" (0 points) for most questions
- Mix in some "Beberapa Hari" (1 point) occasionally
- Result: Tips about maintaining health, not urgent

**To get Score ~15 (Sedang/Moderate):**
- Answer a mix of "Beberapa Hari" (1 point) and "Lebih Dari Separuh Hari" (2 points)
- Some "Hampir Setiap Hari" (3 points) too
- Result: Tips about improvement and self-care

**To get Score ~25 (Tinggi/High):**
- Answer mostly "Hampir Setiap Hari" (3 points)
- Some "Lebih Dari Separuh Hari" (2 points)
- Result: Urgent recommendations for professional help

---

## Implementation Details

### Algorithm Changes:
1. ✅ `getRecommendations(score, answers)` - Updated to use 20/10 thresholds
2. ✅ `getTips(score)` - New function providing 6 dynamic tips per risk level
3. ✅ `result_page.dart` - Replaced hardcoded tips with `getTips(score)`

### Risk Level Ranges (Max Score = 27):
| Status | Score Range | Threshold | Color | Urgency |
|--------|-------------|-----------|-------|---------|
| Baik | 0-9 | < 10 | 🟢 Green | Low |
| Sedang | 10-19 | 10-19 | 🟠 Orange | Medium |
| Tinggi | 20-27 | ≥ 20 | 🔴 Red | High |

---

## Testing Checklist

- [ ] Complete screening and get Score 5 → Check if showing "Baik" status (green)
- [ ] Complete screening and get Score 15 → Check if showing "Sedang" status (orange)
- [ ] Complete screening and get Score 25 → Check if showing "Tinggi" status (red)
- [ ] Verify recommendations change based on score
- [ ] Verify tips change based on score
- [ ] Test on different pages (result_page, report_page, etc.)
- [ ] Verify PDF report shows correct recommendations for the score

---

## Features Completed

✅ Dynamic recommendations based on score
✅ Dynamic tips based on score
✅ Correct score thresholds (20/10 for max 27)
✅ Color-coded risk levels (green/orange/red)
✅ User sees appropriate guidance for their mental health status
✅ Screening affects all UI (recommendations, tips, colors, status text)
✅ PDF report includes dynamic recommendations
✅ Analytics track by risk level (Baik/Sedang/Tinggi)
