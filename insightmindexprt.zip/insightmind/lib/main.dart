import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'src/app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    // Try to initialize date formatting, but don't block if it fails on web
    await Future.delayed(const Duration(milliseconds: 100));
  } catch (e) {
    print('Date formatting initialization: $e');
  }
  runApp(const ProviderScope(child: InsightMindApp()));
}