// App Responsive Breakpoints
class AppConstants {
  // Screen size breakpoints
  static const double mobileMaxWidth = 600;
  static const double tabletMaxWidth = 1200;
  static const double desktopMinWidth = 1200;

  // Responsive padding
  static const double paddingMobile = 16.0;
  static const double paddingTablet = 20.0;
  static const double paddingDesktop = 24.0;

  // Feature flags
  static const bool enablePDFExport = true;
  static const bool enableResponsiveLayout = true;

  // App info
  static const String appName = 'InsightMind';
  static const String appVersion = '1.0.0';
}

// Screen size helper
class ResponsiveHelper {
  static bool isMobile(double width) => width < AppConstants.mobileMaxWidth;
  static bool isTablet(double width) =>
      width >= AppConstants.mobileMaxWidth && width < AppConstants.tabletMaxWidth;
  static bool isDesktop(double width) => width >= AppConstants.desktopMinWidth;

  static double getResponsivePadding(double width) {
    if (isMobile(width)) return AppConstants.paddingMobile;
    if (isTablet(width)) return AppConstants.paddingTablet;
    return AppConstants.paddingDesktop;
  }

  static int getGridColumns(double width) {
    if (isMobile(width)) return 2;
    if (isTablet(width)) return 3;
    return 4;
  }
}
