class MentalResult {
  final int score;
  final String riskLevel;

  const MentalResult({required this.score, required this.riskLevel});
}