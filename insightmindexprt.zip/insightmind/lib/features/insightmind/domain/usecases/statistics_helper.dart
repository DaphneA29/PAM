import 'package:flutter_riverpod/flutter_riverpod.dart';

// Data structure untuk hasil screening
class ScreeningResult {
  final int score;
  final String riskLevel;
  final DateTime date;
  final List<int> answers;

  const ScreeningResult({
    required this.score,
    required this.riskLevel,
    required this.date,
    required this.answers,
  });
}

// Data structure untuk statistik keseluruhan
class StatisticsData {
  final int totalScreenings;
  final double averageScore;
  final int highRiskCount;
  final int moderateRiskCount;
  final int lowRiskCount;
  final List<ScreeningResult> history;

  const StatisticsData({
    required this.totalScreenings,
    required this.averageScore,
    required this.highRiskCount,
    required this.moderateRiskCount,
    required this.lowRiskCount,
    required this.history,
  });

  // Hitung persentase setiap kategori risiko
  double get highRiskPercentage =>
      totalScreenings == 0 ? 0 : (highRiskCount / totalScreenings) * 100;
  double get moderateRiskPercentage =>
      totalScreenings == 0 ? 0 : (moderateRiskCount / totalScreenings) * 100;
  double get lowRiskPercentage =>
      totalScreenings == 0 ? 0 : (lowRiskCount / totalScreenings) * 100;

  // Tren - apakah score meningkat atau menurun
  // History disimpan dengan newest di akhir array
  // history[length-1] = screening terbaru
  // history[length-2] = screening sebelumnya
  String getTrendStatus() {
    if (history.isEmpty || history.length < 2) return 'Belum cukup data';

    // Ambil index untuk newest dan previous
    int lastIndex = history.length - 1;
    int prevIndex = lastIndex - 1;
    
    int current = history[lastIndex].score;    // terbaru (yang baru dikerjakan)
    int previous = history[prevIndex].score;   // sebelumnya
    
    // Bandingkan score
    // Score meningkat = beresiko lebih tinggi
    if (current > previous) {
      return 'Meningkat';
    } else if (current < previous) {
      return 'Menurun';
    } else {
      return 'Stabil';
    }
  }

  // Skor terburuk (risiko tertinggi)
  int get maxScore => history.isEmpty ? 0 : history.map((r) => r.score).reduce((a, b) => a > b ? a : b);

  // Skor terbaik (risiko terendah)
  int get minScore => history.isEmpty ? 0 : history.map((r) => r.score).reduce((a, b) => a < b ? a : b);
}

// Algoritma untuk menghitung risk level berdasarkan score
// Max score = 27 (9 pertanyaan × 3 point max)
// Semakin tinggi score semakin beresiko
String calculateRiskLevel(int score) {
  if (score >= 20) {
    return 'Tinggi';      // High risk: 20-27 (75%)
  } else if (score >= 10) {
    return 'Sedang';      // Moderate: 10-19 (37-74%)
  } else {
    return 'Baik';        // Good: 0-9 (0-36%)
  }
}

// Fungsi untuk menghitung statistik dari list hasil screening
StatisticsData calculateStatistics(List<ScreeningResult> results) {
  if (results.isEmpty) {
    return const StatisticsData(
      totalScreenings: 0,
      averageScore: 0,
      highRiskCount: 0,
      moderateRiskCount: 0,
      lowRiskCount: 0,
      history: [],
    );
  }

  int highRisk = 0;
  int moderateRisk = 0;
  int lowRisk = 0;
  double totalScore = 0;

  for (var result in results) {
    totalScore += result.score;

    if (result.riskLevel == 'Tinggi') {
      highRisk++;
    } else if (result.riskLevel == 'Sedang') {
      moderateRisk++;
    } else {
      lowRisk++;
    }
  }

  double averageScore = totalScore / results.length;

  return StatisticsData(
    totalScreenings: results.length,
    averageScore: averageScore,
    highRiskCount: highRisk,
    moderateRiskCount: moderateRisk,
    lowRiskCount: lowRisk,
    history: results,
  );
}

// Provider untuk menyimpan screening history
final screeningHistoryProvider =
    StateProvider<List<ScreeningResult>>((ref) => []);

// Provider untuk menyimpan statistics
final statisticsProvider = Provider<StatisticsData>((ref) {
  final history = ref.watch(screeningHistoryProvider);
  return calculateStatistics(history);
});

// Fungsi untuk rekomendasi berdasarkan score (MAX SCORE = 27)
List<String> getRecommendations(int score, List<int> answers) {
  List<String> recommendations = [];

  if (score >= 20) {
    // TINGGI (High Risk): Score 20-27
    recommendations.addAll([
      '🔴 Risiko Tinggi: Segera konsultasi dengan profesional kesehatan mental',
      '📞 Hubungi layanan konseling di kampus atau rumah sakit terdekat',
      '😴 Prioritaskan istirahat yang cukup (7-8 jam per hari)',
      '🧘 Lakukan meditasi atau mindfulness 10-15 menit setiap hari',
      '👥 Berbicara dengan orang terpercaya tentang perasaan Anda',
    ]);
  } else if (score >= 10) {
    // SEDANG (Moderate): Score 10-19
    recommendations.addAll([
      '🟠 Risiko Sedang: Tingkatkan aktivitas self-care',
      '🏃 Olahraga teratur 30 menit, 3-4 kali per minggu',
      '🥗 Perhatikan pola makan yang sehat dan seimbang',
      '📱 Batasi waktu screen/gadget sebelum tidur',
      '🎨 Lakukan hobi yang menyenangkan secara rutin',
      '📅 Pertimbangkan konsultasi dengan psikolog',
    ]);
  } else {
    // BAIK (Good): Score 0-9
    recommendations.addAll([
      '🟢 Status Baik: Pertahankan gaya hidup sehat',
      '✨ Terus jaga keseimbangan hidup dan pekerjaan',
      '💪 Lakukan aktivitas fisik yang Anda nikmati',
      '🧠 Praktek mindfulness atau meditasi',
      '📱 Jaga hubungan sosial yang positif',
      '👨‍⚕️ Lakukan screening berkala setiap 1-2 bulan',
    ]);
  }

  return recommendations;
}

// Fungsi untuk tips perawatan diri dinamis berdasarkan score
List<({String title, String description, String icon})> getTips(int score) {
  List<({String title, String description, String icon})> tips = [];

  if (score >= 20) {
    // TINGGI (High Risk) - Urgent Care Tips
    tips = [
      (
        title: 'Konsultasi Profesional',
        description: 'Segera hubungi psikolog atau psikiater untuk bantuan profesional',
        icon: 'person_4'
      ),
      (
        title: 'Istirahat Total',
        description: 'Tidur minimal 8-9 jam per hari untuk pemulihan optimal',
        icon: 'nights_stay'
      ),
      (
        title: 'Meditasi Intensif',
        description: 'Lakukan meditasi guided 15-20 menit minimal 2x sehari',
        icon: 'self_improvement'
      ),
      (
        title: 'Hindari Stress',
        description: 'Kurangi beban kerja, ambil cuti jika diperlukan',
        icon: 'no_encryption'
      ),
      (
        title: 'Dukungan Sosial',
        description: 'Ceritakan perasaan Anda kepada orang terpercaya',
        icon: 'people'
      ),
      (
        title: 'Pantau Kesehatan',
        description: 'Hindari alkohol, obat-obatan, dan stimulan lainnya',
        icon: 'monitor_heart'
      ),
    ];
  } else if (score >= 10) {
    // SEDANG (Moderate) - Improvement Tips
    tips = [
      (
        title: 'Olahraga Rutin',
        description: 'Lakukan aktivitas fisik 30 menit, 3-4 kali per minggu',
        icon: 'directions_run'
      ),
      (
        title: 'Pola Tidur Stabil',
        description: 'Tidur 7-8 jam dengan jadwal yang konsisten setiap hari',
        icon: 'bedtime'
      ),
      (
        title: 'Nutrisi Seimbang',
        description: 'Makan makanan bergizi: protein, sayur, buah, dan biji-bijian',
        icon: 'restaurant'
      ),
      (
        title: 'Batasi Gadget',
        description: 'Kurangi screen time minimal 1 jam sebelum tidur',
        icon: 'phone_iphone'
      ),
      (
        title: 'Hobi Positif',
        description: 'Luangkan waktu untuk hobi yang menyenangkan Anda',
        icon: 'palette'
      ),
      (
        title: 'Konsultasi Opsional',
        description: 'Pertimbangkan terapi atau konseling untuk hasil lebih baik',
        icon: 'psychology'
      ),
    ];
  } else {
    // BAIK (Good) - Maintenance Tips
    tips = [
      (
        title: 'Tetap Aktif',
        description: 'Lanjutkan olahraga regular yang Anda sukai',
        icon: 'fitness_center'
      ),
      (
        title: 'Tidur Berkualitas',
        description: 'Pertahankan rutinitas tidur 7-8 jam setiap malam',
        icon: 'dark_mode'
      ),
      (
        title: 'Makanan Sehat',
        description: 'Terus jaga pola makan sehat yang sudah terbukti efektif',
        icon: 'local_dining'
      ),
      (
        title: 'Interaksi Sosial',
        description: 'Jaga hubungan baik dengan teman, keluarga, dan komunitas',
        icon: 'group'
      ),
      (
        title: 'Mindfulness Harian',
        description: 'Lakukan meditasi atau breathing exercise 10 menit setiap hari',
        icon: 'meditation'
      ),
      (
        title: 'Screening Berkala',
        description: 'Lakukan screening setiap 1-2 bulan untuk monitoring',
        icon: 'health_and_safety'
      ),
    ];
  }

  return tips;
}

// Fungsi untuk analisis pola dari jawaban
Map<String, dynamic> analyzeAnswerPatterns(List<int> answers) {
  if (answers.isEmpty) {
    return {};
  }

  // Kategori pertanyaan (contoh berdasarkan 9 pertanyaan)
  // 0-2: Mood/Depresi, 3-5: Kecemasan, 6-8: Stress
  Map<String, dynamic> patterns = {
    'mood_score': 0,
    'anxiety_score': 0,
    'stress_score': 0,
  };

  if (answers.length >= 3) {
    patterns['mood_score'] = (answers[0] + answers[1] + answers[2]) ~/ 3;
  }
  if (answers.length >= 6) {
    patterns['anxiety_score'] = (answers[3] + answers[4] + answers[5]) ~/ 3;
  }
  if (answers.length >= 9) {
    patterns['stress_score'] = (answers[6] + answers[7] + answers[8]) ~/ 3;
  }

  return patterns;
}
