import 'package:flutter/material.dart';

class HealthTipsWidget extends StatelessWidget {
  const HealthTipsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final tips = [
      {
        'icon': Icons.bedtime,
        'title': 'Tidur Teratur',
        'description': 'Tidur 7-8 jam setiap malam untuk istirahat optimal',
        'color': Colors.blue,
      },
      {
        'icon': Icons.fitness_center,
        'title': 'Olahraga Rutin',
        'description': 'Lakukan aktivitas fisik minimal 30 menit per hari',
        'color': Colors.red,
      },
      {
        'icon': Icons.local_dining,
        'title': 'Makan Sehat',
        'description': 'Konsumsi nutrisi seimbang dari berbagai jenis makanan',
        'color': Colors.green,
      },
      {
        'icon': Icons.people,
        'title': 'Hubungan Sosial',
        'description': 'Jaga interaksi positif dengan teman dan keluarga',
        'color': Colors.purple,
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Tips Kesehatan Mental',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              for (int i = 0; i < tips.length; i++) ...[
                _buildTipCard(
                  icon: tips[i]['icon'] as IconData,
                  title: tips[i]['title'] as String,
                  description: tips[i]['description'] as String,
                  color: tips[i]['color'] as Color,
                ),
                if (i < tips.length - 1) const SizedBox(width: 12),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTipCard({
    required IconData icon,
    required String title,
    required String description,
    required Color color,
  }) {
    return Container(
      width: 250,
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
      ),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            padding: const EdgeInsets.all(8),
            child: Icon(
              icon,
              color: color,
              size: 20,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            description,
            style: TextStyle(
              fontSize: 11,
              color: Colors.grey[600],
              height: 1.4,
            ),
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}
