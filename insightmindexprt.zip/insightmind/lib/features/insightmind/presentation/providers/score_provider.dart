import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/usecases/statistics_helper.dart';

// Provider untuk menyimpan jawaban screening
final answersProvider = StateProvider<List<int>>((ref) => []);

// Provider untuk menyimpan skor screening terbaru
final scoreProvider = StateProvider<int>((ref) => 0);

// Provider untuk menyimpan hasil screening (score + riskLevel)
final resultProvider = StateProvider((ref) {
  final score = ref.watch(scoreProvider);
  final riskLevel = calculateRiskLevel(score);
  
  return (
    score: score,
    riskLevel: riskLevel,
  );
});