import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/entities/question.dart';

final questionsProvider = Provider<List<Question>>((ref) {
  return defaultQuestions;
});

final answersProvider = StateProvider<List<int>>((ref) {
  return [];
});
