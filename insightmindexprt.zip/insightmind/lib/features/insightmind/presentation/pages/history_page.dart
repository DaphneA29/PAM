import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/usecases/statistics_helper.dart';
import 'screening_detail_page.dart';

class HistoryPage extends ConsumerWidget {
  const HistoryPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isMobile = MediaQuery.of(context).size.width < 600;
    final screeningHistory = ref.watch(screeningHistoryProvider);
    final statistics = ref.watch(statisticsProvider);

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(isMobile ? 16.0 : 24.0),
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      shape: BoxShape.circle,
                    ),
                    padding: const EdgeInsets.all(8),
                    child: const Icon(Icons.arrow_back, size: 20),
                  ),
                ),
                Text(
                  'Riwayat Screening',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(width: 40),
              ],
            ),
            const SizedBox(height: 20),

            // Summary Card
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.teal[600]!, Colors.teal[400]!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              padding: EdgeInsets.all(isMobile ? 16.0 : 24.0),
              child: isMobile
                  ? Column(
                      children: [
                        _buildSummaryStat(
                          icon: Icons.done_all,
                          value: '${statistics.totalScreenings}',
                          label: 'Total Screening',
                          context: context,
                        ),
                        const SizedBox(height: 20),
                        Container(
                          width: double.infinity,
                          height: 1,
                          color: Colors.white.withOpacity(0.3),
                        ),
                        const SizedBox(height: 20),
                        _buildSummaryStat(
                          icon: Icons.trending_up,
                          value: statistics.totalScreenings > 0
                              ? statistics.averageScore.toStringAsFixed(1)
                              : '0.0',
                          label: 'Rata-rata Skor',
                          context: context,
                        ),
                        const SizedBox(height: 20),
                        Container(
                          width: double.infinity,
                          height: 1,
                          color: Colors.white.withOpacity(0.3),
                        ),
                        const SizedBox(height: 20),
                        _buildSummaryStat(
                          icon: Icons.info,
                          value: statistics.totalScreenings > 0
                              ? statistics.getTrendStatus()
                              : 'Belum ada',
                          label: 'Status Tren',
                          context: context,
                        ),
                      ],
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildSummaryStat(
                          icon: Icons.done_all,
                          value: '${statistics.totalScreenings}',
                          label: 'Total Screening',
                          context: context,
                        ),
                        Container(
                          width: 1,
                          height: 60,
                          color: Colors.white.withOpacity(0.3),
                        ),
                        _buildSummaryStat(
                          icon: Icons.trending_up,
                          value: statistics.totalScreenings > 0
                              ? statistics.averageScore.toStringAsFixed(1)
                              : '0.0',
                          label: 'Rata-rata Skor',
                          context: context,
                        ),
                        Container(
                          width: 1,
                          height: 60,
                          color: Colors.white.withOpacity(0.3),
                        ),
                        _buildSummaryStat(
                          icon: Icons.info,
                          value: statistics.totalScreenings > 0
                              ? statistics.getTrendStatus()
                              : 'Belum ada',
                          label: 'Status Tren',
                          context: context,
                        ),
                      ],
                    ),
            ),
            const SizedBox(height: 24),

            // History List
            Text(
              'Hasil Screening',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
            ),
            const SizedBox(height: 12),
            if (screeningHistory.isEmpty)
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(32.0),
                  child: Column(
                    children: [
                      Icon(
                        Icons.history,
                        size: 64,
                        color: Colors.grey[300],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Belum ada riwayat screening',
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else
              ...List.generate(screeningHistory.length, (index) {
                final item = screeningHistory[index];
                Color statusColor;
                switch (item.riskLevel) {
                  case 'Tinggi':
                    statusColor = Colors.red;
                    break;
                  case 'Sedang':
                    statusColor = Colors.orange;
                    break;
                  default:
                    statusColor = Colors.green;
                }
                return _buildHistoryCard(
                  context,
                  date: item.date,
                  score: item.score,
                  status: item.riskLevel,
                  color: statusColor,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ScreeningDetailPage(screening: item),
                      ),
                    );
                  },
                );
              }),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryStat({
    required IconData icon,
    required String value,
    required String label,
    required BuildContext context,
  }) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 28),
        const SizedBox(height: 8),
        Text(
          value,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: Colors.white,
                fontSize: 22,
              ),
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.white70,
              ),
        ),
      ],
    );
  }

  Widget _buildHistoryCard(
    BuildContext context, {
    required DateTime date,
    required int score,
    required String status,
    required Color color,
    required VoidCallback onTap,
  }) {
    // Format tanggal dengan jam: "2026-01-14 14:30"
    final dateLocal = date.toLocal();
    final formattedDate =
        '${dateLocal.toString().split(' ')[0]} ${dateLocal.hour.toString().padLeft(2, '0')}:${dateLocal.minute.toString().padLeft(2, '0')}';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[200]!, width: 1),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: const EdgeInsets.all(8),
                  child: Icon(
                    Icons.assessment,
                    color: color,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        formattedDate,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Status: $status',
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '$score',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: color,
                      ),
                    ),
                    Text(
                      'Poin',
                      style: TextStyle(
                        fontSize: 10,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 8),
                Icon(
                  Icons.arrow_forward_ios,
                  size: 14,
                  color: Colors.grey[400],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
