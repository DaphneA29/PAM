import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/usecases/statistics_helper.dart';

class AnalyticsPage extends ConsumerWidget {
  const AnalyticsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isMobile = MediaQuery.of(context).size.width < 600;
    final statistics = ref.watch(statisticsProvider);

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(isMobile ? 16.0 : 24.0),
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      shape: BoxShape.circle,
                    ),
                    padding: const EdgeInsets.all(8),
                    child: const Icon(Icons.arrow_back, size: 20),
                  ),
                ),
                Text(
                  'Analitik Lengkap',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(width: 40),
              ],
            ),
            const SizedBox(height: 24),

            // Overall Statistics Card
            if (statistics.totalScreenings > 0) ...[
              _buildOverallStatsCard(context, statistics),
              const SizedBox(height: 24),
            ],

            // Risk Level Distribution
            if (statistics.totalScreenings > 0) ...[
              _buildRiskDistributionCard(context, statistics),
              const SizedBox(height: 24),
            ],

            // Component Analysis (Mood, Anxiety, Stress)
            if (statistics.history.isNotEmpty) ...[
              _buildComponentAnalysisCard(context, statistics),
              const SizedBox(height: 24),
            ],

            // Score Range Analysis
            if (statistics.history.isNotEmpty) ...[
              _buildScoreRangeCard(context, statistics),
              const SizedBox(height: 24),
            ],

            // Recent Screenings
            if (statistics.history.isNotEmpty) ...[
              _buildRecentScreeningsCard(context, statistics),
              const SizedBox(height: 24),
            ],

            // Empty State
            if (statistics.totalScreenings == 0) ...[
              Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 48.0),
                  child: Column(
                    children: [
                      Icon(
                        Icons.analytics,
                        size: 80,
                        color: Colors.grey[300],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Belum ada data analitik',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              color: Colors.grey[600],
                            ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Mulai screening untuk melihat analisis detail',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Colors.grey[500],
                            ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildOverallStatsCard(BuildContext context, StatisticsData stats) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.indigo[400]!, Colors.indigo[600]!],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Statistik Keseluruhan',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildStatItem(
                'Total',
                '${stats.totalScreenings}',
                Icons.done_all,
              ),
              _buildStatItem(
                'Rata-rata',
                stats.averageScore.toStringAsFixed(1),
                Icons.trending_up,
              ),
              _buildStatItem(
                'Maksimal',
                '${stats.maxScore}',
                Icons.arrow_upward,
              ),
              _buildStatItem(
                'Minimal',
                '${stats.minScore}',
                Icons.arrow_downward,
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: [
                Icon(
                  Icons.trending_up,
                  color: Colors.white70,
                  size: 18,
                ),
                const SizedBox(width: 8),
                Text(
                  'Tren: ${stats.getTrendStatus()}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon) {
    return Column(
      children: [
        Icon(icon, color: Colors.white70, size: 20),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 11,
          ),
        ),
      ],
    );
  }

  Widget _buildRiskDistributionCard(BuildContext context, StatisticsData stats) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[200]!, width: 1),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Distribusi Tingkat Risiko',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 20),
          _buildRiskDistributionBar(
            'Risiko Tinggi',
            stats.highRiskCount,
            stats.totalScreenings,
            Colors.red,
            stats.highRiskPercentage,
          ),
          const SizedBox(height: 16),
          _buildRiskDistributionBar(
            'Risiko Sedang',
            stats.moderateRiskCount,
            stats.totalScreenings,
            Colors.orange,
            stats.moderateRiskPercentage,
          ),
          const SizedBox(height: 16),
          _buildRiskDistributionBar(
            'Risiko Baik',
            stats.lowRiskCount,
            stats.totalScreenings,
            Colors.green,
            stats.lowRiskPercentage,
          ),
        ],
      ),
    );
  }

  Widget _buildRiskDistributionBar(
    String label,
    int count,
    int total,
    Color color,
    double percentage,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
            Text(
              '$count ($percentage${percentage.toStringAsFixed(1)}%)',
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 12,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(
            value: total == 0 ? 0 : count / total,
            minHeight: 12,
            backgroundColor: color.withOpacity(0.2),
            valueColor: AlwaysStoppedAnimation(color),
          ),
        ),
      ],
    );
  }

  Widget _buildComponentAnalysisCard(BuildContext context, StatisticsData stats) {
    // Calculate component analysis from all screenings
    Map<String, List<int>> componentScores = {
      'mood': [],
      'anxiety': [],
      'stress': [],
    };

    for (var result in stats.history) {
      final patterns = analyzeAnswerPatterns(result.answers);
      if (patterns.containsKey('mood_score')) {
        componentScores['mood']!.add(patterns['mood_score'] as int);
      }
      if (patterns.containsKey('anxiety_score')) {
        componentScores['anxiety']!.add(patterns['anxiety_score'] as int);
      }
      if (patterns.containsKey('stress_score')) {
        componentScores['stress']!.add(patterns['stress_score'] as int);
      }
    }

    // Calculate averages
    double moodAvg = componentScores['mood']!.isEmpty
        ? 0
        : componentScores['mood']!.fold(0, (a, b) => a + b) /
            componentScores['mood']!.length;
    double anxietyAvg = componentScores['anxiety']!.isEmpty
        ? 0
        : componentScores['anxiety']!.fold(0, (a, b) => a + b) /
            componentScores['anxiety']!.length;
    double stressAvg = componentScores['stress']!.isEmpty
        ? 0
        : componentScores['stress']!.fold(0, (a, b) => a + b) /
            componentScores['stress']!.length;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[200]!, width: 1),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Analisis Komponen',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 20),
          _buildComponentItem(
            'Mood/Depresi',
            moodAvg,
            Colors.blue,
            Icons.mood,
          ),
          const SizedBox(height: 16),
          _buildComponentItem(
            'Kecemasan',
            anxietyAvg,
            Colors.purple,
            Icons.psychology,
          ),
          const SizedBox(height: 16),
          _buildComponentItem(
            'Stress',
            stressAvg,
            Colors.red,
            Icons.energy_savings_leaf,
          ),
        ],
      ),
    );
  }

  Widget _buildComponentItem(
    String label,
    double score,
    Color color,
    IconData icon,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
            const Spacer(),
            Text(
              score.toStringAsFixed(1),
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(
            value: score / 10,
            minHeight: 8,
            backgroundColor: color.withOpacity(0.2),
            valueColor: AlwaysStoppedAnimation(color),
          ),
        ),
      ],
    );
  }

  Widget _buildScoreRangeCard(BuildContext context, StatisticsData stats) {
    final maxScore = stats.maxScore;
    final minScore = stats.minScore;
    final avgScore = stats.averageScore;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[200]!, width: 1),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Jangkauan Skor',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildScoreBox('Minimum', minScore.toString(), Colors.green),
              _buildScoreBox('Rata-rata', avgScore.toStringAsFixed(1), Colors.blue),
              _buildScoreBox('Maksimum', maxScore.toString(), Colors.red),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            height: 40,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              gradient: LinearGradient(
                colors: [
                  Colors.green,
                  Colors.yellow[700]!,
                  Colors.red,
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Baik', style: TextStyle(fontSize: 11, color: Colors.grey[600])),
              Text('Sedang', style: TextStyle(fontSize: 11, color: Colors.grey[600])),
              Text('Tinggi', style: TextStyle(fontSize: 11, color: Colors.grey[600])),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildScoreBox(String label, String value, Color color) {
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color.withOpacity(0.5), width: 2),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Column(
            children: [
              Text(
                value,
                style: TextStyle(
                  color: color,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  color: color.withOpacity(0.8),
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRecentScreeningsCard(BuildContext context, StatisticsData stats) {
    final recentScreenings = stats.history.take(5).toList();

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[200]!, width: 1),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Screening Terbaru',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 16),
          ...List.generate(
            recentScreenings.length,
            (index) {
              final screening = recentScreenings[index];
              Color riskColor;
              IconData riskIcon;

              switch (screening.riskLevel) {
                case 'Tinggi':
                  riskColor = Colors.red;
                  riskIcon = Icons.warning;
                  break;
                case 'Sedang':
                  riskColor = Colors.orange;
                  riskIcon = Icons.info;
                  break;
                default:
                  riskColor = Colors.green;
                  riskIcon = Icons.check_circle;
              }

              return Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            screening.date.toString().substring(0, 19),
                            style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Skor: ${screening.score}',
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                      Container(
                        decoration: BoxDecoration(
                          color: riskColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        child: Row(
                          children: [
                            Icon(riskIcon, color: riskColor, size: 16),
                            const SizedBox(width: 6),
                            Text(
                              screening.riskLevel,
                              style: TextStyle(
                                color: riskColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  if (index < recentScreenings.length - 1) ...[
                    const SizedBox(height: 12),
                    Divider(color: Colors.grey[200]),
                    const SizedBox(height: 12),
                  ],
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}
