import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/entities/question.dart';
import '../providers/questionnaire_provider.dart';
import '../providers/score_provider.dart';
import '../../domain/usecases/statistics_helper.dart';
import 'result_page.dart';

class ScreeningPage extends ConsumerWidget {
  const ScreeningPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final questions = ref.watch(questionsProvider);
    final qState = ref.watch(questionnaireProvider);
    final isMobile = MediaQuery.of(context).size.width < 600;

    final progress =
        questions.isEmpty ? 0.0 : (qState.answers.length / questions.length);

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.fromLTRB(isMobile ? 16 : 24, 12, isMobile ? 16 : 24, 24),
          children: [
            // Header
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          shape: BoxShape.circle,
                        ),
                        padding: const EdgeInsets.all(8),
                        child: const Icon(Icons.arrow_back, size: 20),
                      ),
                    ),
                    Text(
                      'Screening Kesehatan Mental',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(width: 40),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  'Jawab pertanyaan-pertanyaan berikut dengan jujur',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Colors.grey[600],
                        fontSize: 13,
                      ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Progress Card
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.indigo[600]!, Colors.indigo[400]!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Progress Screening',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Colors.white70,
                              fontSize: 12,
                            ),
                      ),
                      Text(
                        '${qState.answers.length}/${questions.length}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: progress.clamp(0.0, 1.0),
                      minHeight: 8,
                      backgroundColor: Colors.white.withOpacity(0.3),
                      valueColor: AlwaysStoppedAnimation(Colors.lightGreen[300]),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Questions
            for (int i = 0; i < questions.length; i++) ...[
              _QuestionCard(
                index: i,
                question: questions[i],
                selectedScore: qState.answers[questions[i].id],
                onSelected: (score) {
                  ref
                      .read(questionnaireProvider.notifier)
                      .selectAnswer(questionId: questions[i].id, score: score);
                },
              ),
              const SizedBox(height: 12),
            ],

            const SizedBox(height: 12),

            // Action Buttons
            FilledButton.icon(
              icon: const Icon(Icons.check_circle_outline),
              label: const Text('Lihat Hasil'),
              onPressed: () {
                if (!qState.isComplete) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                          'Lengkapi semua pertanyaan sebelum melihat hasil.'),
                      backgroundColor: Colors.orange,
                    ),
                  );
                  return;
                }
                
                // Calculate score from answers
                final ordered = <int>[];
                for (final q in questions) {
                  ordered.add(qState.answers[q.id]!);
                }
                
                // Calculate total score using statistics algorithm
                final totalScore = ordered.fold<int>(0, (sum, score) => sum + score);
                
                // Calculate risk level using algorithm
                final riskLevel = calculateRiskLevel(totalScore);
                
                // DEBUG: Print calculation
                print('=== SCREENING CALCULATION ===');
                print('Answers: $ordered');
                print('Total Score: $totalScore');
                print('Risk Level: $riskLevel');
                print('============================');
                
                // Create screening result
                final result = ScreeningResult(
                  score: totalScore,
                  riskLevel: riskLevel,
                  date: DateTime.now(),
                  answers: ordered,
                );
                
                // Save to screening history provider
                ref.read(screeningHistoryProvider.notifier).state = [
                  ...ref.read(screeningHistoryProvider),
                  result,
                ];
                
                // Update score provider with calculated score
                ref.read(scoreProvider.notifier).state = totalScore;
                
                // Update answers provider
                ref.read(answersProvider.notifier).state = ordered;
                
                // Show success message
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Skor: $totalScore | Risiko: $riskLevel'),
                    backgroundColor: riskLevel == 'Tinggi'
                        ? Colors.red
                        : riskLevel == 'Sedang'
                            ? Colors.orange
                            : Colors.green,
                    duration: const Duration(seconds: 2),
                  ),
                );
                
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const ResultPage()),
                );
              },
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () {
                ref.read(questionnaireProvider.notifier).reset();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Jawaban direset.'),
                    backgroundColor: Colors.blue,
                  ),
                );
              },
              icon: const Icon(Icons.refresh),
              label: const Text('Reset Jawaban'),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuestionCard extends StatelessWidget {
  final int index;
  final Question question;
  final int? selectedScore;
  final ValueChanged<int> onSelected;

  const _QuestionCard({
    required this.index,
    required this.question,
    required this.selectedScore,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: selectedScore != null ? Colors.indigo[300]! : Colors.grey[200]!,
          width: selectedScore != null ? 2 : 1,
        ),
        boxShadow: [
          if (selectedScore != null)
            BoxShadow(
              color: Colors.indigo.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            )
          else
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 4,
              offset: const Offset(0, 1),
            ),
        ],
      ),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Question Number and Text
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.indigo[100],
                  shape: BoxShape.circle,
                ),
                padding: const EdgeInsets.all(8),
                child: Text(
                  '${index + 1}',
                  style: TextStyle(
                    color: Colors.indigo[700],
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  question.text,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Options
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final opt in question.options)
                _buildOptionButton(
                  context,
                  label: opt.label,
                  score: opt.score,
                  isSelected: selectedScore == opt.score,
                  onTap: () => onSelected(opt.score),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOptionButton(
    BuildContext context, {
    required String label,
    required int score,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: isSelected ? Colors.indigo[50] : Colors.grey[50],
          border: Border.all(
            color: isSelected ? Colors.indigo[400]! : Colors.grey[300]!,
            width: isSelected ? 2 : 1,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 18,
              height: 18,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isSelected ? Colors.indigo : Colors.grey[300],
              ),
              child: isSelected
                  ? const Icon(Icons.check, color: Colors.white, size: 12)
                  : null,
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.indigo[700] : Colors.grey[700],
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }
}