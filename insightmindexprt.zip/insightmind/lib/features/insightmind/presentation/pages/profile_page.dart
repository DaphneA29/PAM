import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/usecases/statistics_helper.dart';

class ProfilePage extends ConsumerWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isMobile = MediaQuery.of(context).size.width < 600;
    final screeningHistory = ref.watch(screeningHistoryProvider);
    final statistics = ref.watch(statisticsProvider);
    
    // Get latest screening result (last in array = newest)
    final latestResult = screeningHistory.isNotEmpty ? screeningHistory.last : null;

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(isMobile ? 16.0 : 24.0),
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      shape: BoxShape.circle,
                    ),
                    padding: const EdgeInsets.all(8),
                    child: const Icon(Icons.arrow_back, size: 20),
                  ),
                ),
                Text(
                  'Profil Saya',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                const SizedBox(width: 40),
              ],
            ),
            const SizedBox(height: 24),

            // Profile Header
            Center(
              child: Column(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.pink[400]!, Colors.pink[600]!],
                      ),
                      shape: BoxShape.circle,
                    ),
                    padding: const EdgeInsets.all(40),
                    child: const Icon(
                      Icons.person,
                      size: 60,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Pengguna InsightMind',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'user@insightmind.com',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[600],
                        ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Mental Health Status Card (if screening exists)
            if (latestResult != null) ...[
              _buildSectionTitle(context, 'Status Kesehatan Mental'),
              const SizedBox(height: 12),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      latestResult.riskLevel == 'Tinggi'
                          ? Colors.red.withOpacity(0.8)
                          : latestResult.riskLevel == 'Sedang'
                              ? Colors.orange.withOpacity(0.8)
                              : Colors.green.withOpacity(0.8),
                      latestResult.riskLevel == 'Tinggi'
                          ? Colors.red
                          : latestResult.riskLevel == 'Sedang'
                              ? Colors.orange
                              : Colors.green,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Status Terakhir',
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                        ),
                        Text(
                          latestResult.date.toString().substring(0, 10),
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: Colors.white70,
                                fontSize: 11,
                              ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Skor: ${latestResult.score}',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      child: Text(
                        'Risiko: ${latestResult.riskLevel}',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Statistics Overview
              _buildSectionTitle(context, 'Ringkasan Statistik'),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _buildStatCard(
                      context,
                      label: 'Total\nScreening',
                      value: '${statistics.totalScreenings}',
                      color: Colors.blue,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildStatCard(
                      context,
                      label: 'Rata-rata\nSkor',
                      value: statistics.averageScore.toStringAsFixed(1),
                      color: Colors.purple,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _buildStatCard(
                      context,
                      label: 'Skor\nTertinggi',
                      value: '${statistics.maxScore}',
                      color: Colors.red,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildStatCard(
                      context,
                      label: 'Skor\nTerendah',
                      value: '${statistics.minScore}',
                      color: Colors.green,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
            ],

            // Personal Info Section
            _buildSectionTitle(context, 'Informasi Pribadi'),
            const SizedBox(height: 12),
            _buildInfoCard(context, 'Nama Lengkap', 'Pengguna InsightMind'),
            _buildInfoCard(context, 'Email', 'user@insightmind.com'),
            _buildInfoCard(context, 'Tanggal Lahir', '1 Januari 2000'),
            _buildInfoCard(context, 'Gender', 'Laki-laki'),
            const SizedBox(height: 24),

            // Health Info Section
            _buildSectionTitle(context, 'Informasi Kesehatan'),
            const SizedBox(height: 12),
            _buildInfoCard(context, 'Tinggi Badan', '170 cm'),
            _buildInfoCard(context, 'Berat Badan', '70 kg'),
            _buildInfoCard(
              context,
              'Status Kesehatan',
              latestResult?.riskLevel ?? 'Belum ada data',
            ),
            const SizedBox(height: 24),

            // Settings Section
            _buildSectionTitle(context, 'Pengaturan'),
            const SizedBox(height: 12),
            _buildSettingItem(
              context,
              icon: Icons.notifications,
              title: 'Notifikasi',
              trailing: Switch(
                value: true,
                onChanged: (value) {},
              ),
            ),
            _buildSettingItem(
              context,
              icon: Icons.dark_mode,
              title: 'Mode Gelap',
              trailing: Switch(
                value: false,
                onChanged: (value) {},
              ),
            ),
            _buildSettingItem(
              context,
              icon: Icons.language,
              title: 'Bahasa',
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            ),
            const SizedBox(height: 24),

            // Danger Zone
            OutlinedButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('Keluar Akun?'),
                    content: const Text(
                      'Anda yakin ingin keluar dari akun ini?',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Batal'),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Anda telah keluar'),
                              backgroundColor: Colors.red,
                            ),
                          );
                        },
                        child: const Text(
                          'Keluar',
                          style: TextStyle(color: Colors.red),
                        ),
                      ),
                    ],
                  ),
                );
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.red,
                side: const BorderSide(color: Colors.red),
              ),
              child: const Text('Keluar Akun'),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Text(
      title,
      style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
    );
  }

  Widget _buildStatCard(
    BuildContext context, {
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.3), width: 1),
      ),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
      child: Column(
        children: [
          Text(
            value,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: color,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 11,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard(BuildContext context, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey[200]!, width: 1),
      ),
      padding: const EdgeInsets.all(12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 12,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required Widget trailing,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey[200]!, width: 1),
      ),
      padding: const EdgeInsets.all(12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(icon, color: Colors.indigo, size: 20),
              const SizedBox(width: 12),
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 13,
                ),
              ),
            ],
          ),
          trailing,
        ],
      ),
    );
  }
}