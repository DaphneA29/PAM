import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/usecases/statistics_helper.dart';
import 'report_page.dart';

class ScreeningDetailPage extends ConsumerWidget {
  final ScreeningResult screening;

  const ScreeningDetailPage({
    super.key,
    required this.screening,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final score = screening.score;
    final riskLevel = screening.riskLevel;
    final answers = screening.answers;

    // Get recommendations using algorithm
    final recommendations = getRecommendations(score, answers);

    String riskColorLabel;
    Color riskColor;
    IconData riskIcon;

    switch (riskLevel) {
      case 'Tinggi':
        riskColorLabel = 'Tinggi';
        riskColor = Colors.red;
        riskIcon = Icons.warning;
        break;
      case 'Sedang':
        riskColorLabel = 'Sedang';
        riskColor = Colors.orange;
        riskIcon = Icons.info;
        break;
      default:
        riskColorLabel = 'Baik';
        riskColor = Colors.green;
        riskIcon = Icons.check_circle;
    }

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: ListView(
            children: [
              // Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.grey[200],
                        shape: BoxShape.circle,
                      ),
                      padding: const EdgeInsets.all(8),
                      child: const Icon(Icons.arrow_back, size: 20),
                    ),
                  ),
                  Text(
                    'Detail Screening',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(width: 40),
                ],
              ),
              const SizedBox(height: 32),

              // Result Card
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [riskColor.withOpacity(0.8), riskColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    Icon(
                      riskIcon,
                      size: 80,
                      color: Colors.white,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Skor Anda',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Colors.white70,
                            fontSize: 14,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '$score',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            color: Colors.white,
                            fontSize: 48,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(height: 20),
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      child: Text(
                        'Tingkat Risiko: $riskColorLabel',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Tanggal: ${screening.date.toLocal().toString().split(' ')[0]}',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Colors.white70,
                          ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Recommendation Section
              Text(
                'Rekomendasi untuk Anda',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const SizedBox(height: 12),
              Container(
                decoration: BoxDecoration(
                  color: riskColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: riskColor.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                padding: const EdgeInsets.all(16),
                child: ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: recommendations.length,
                  separatorBuilder: (context, index) => const SizedBox(height: 12),
                  itemBuilder: (context, index) => Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: riskColor.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Center(
                          child: Text(
                            '${index + 1}',
                            style: TextStyle(
                              color: riskColor,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          recommendations[index],
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                fontSize: 13,
                                color: Colors.grey[800],
                                height: 1.6,
                              ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Tips Section (Dynamic based on score)
              Text(
                'Tips Perawatan Diri',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const SizedBox(height: 12),
              ..._buildDynamicTips(score),
              const SizedBox(height: 24),

              // Download Button
              FilledButton.icon(
                icon: const Icon(Icons.download),
                label: const Text('Download PDF'),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ReportPage(
                        screening: screening,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Map icon names to IconData
  IconData _getIconFromName(String iconName) {
    switch (iconName) {
      case 'person_4':
        return Icons.person;
      case 'nights_stay':
        return Icons.nights_stay;
      case 'self_improvement':
        return Icons.self_improvement;
      case 'no_encryption':
        return Icons.do_not_disturb;
      case 'people':
        return Icons.people;
      case 'monitor_heart':
        return Icons.monitor_heart;
      case 'directions_run':
        return Icons.directions_run;
      case 'bedtime':
        return Icons.bedtime;
      case 'restaurant':
        return Icons.restaurant;
      case 'phone_iphone':
        return Icons.phone_iphone;
      case 'palette':
        return Icons.palette;
      case 'psychology':
        return Icons.psychology;
      case 'fitness_center':
        return Icons.fitness_center;
      case 'dark_mode':
        return Icons.dark_mode;
      case 'local_dining':
        return Icons.local_dining;
      case 'group':
        return Icons.group;
      case 'meditation':
        return Icons.self_improvement;
      case 'health_and_safety':
        return Icons.health_and_safety;
      default:
        return Icons.lightbulb;
    }
  }

  List<Widget> _buildDynamicTips(int score) {
    final tips = getTips(score);

    List<Widget> tipWidgets = [];
    for (var tip in tips) {
      tipWidgets.add(
        _buildTipCard(
          icon: _getIconFromName(tip.icon),
          title: tip.title,
          description: tip.description,
        ),
      );
    }

    return tipWidgets;
  }

  Widget _buildTipCard({
    required IconData icon,
    required String title,
    required String description,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey[200]!, width: 1),
      ),
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.indigo[50],
              borderRadius: BorderRadius.circular(8),
            ),
            padding: const EdgeInsets.all(8),
            child: Icon(
              icon,
              color: Colors.indigo,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
