# InsightMind - Tombol dengan Fungsi Statistik & Algoritma

## Ringkasan: Setiap Tombol Sekarang Memiliki Fungsi Statistik

Berdasarkan permintaan "pada setiap tombol berikan fungsi statistik dan algonya sesuai dengan tombol yang ada di halaman", berikut adalah implementasi lengkap:

---

## 🏠 HOME PAGE - 6 Tombol dengan Fungsi Statistik

### 1️⃣ **SCREENING Button** 🔵
- **Algoritma**: `calculateRiskLevel(score)`
- **Fungsi**: 
  - Menghitung skor total dari 9 pertanyaan
  - Menentukan tingkat risiko (Tinggi/Sedang/Baik)
  - Menyimpan hasil ke riwayat
- **Lokasi Algoritma**: `screening_page.dart` (Lihat Hasil button)

### 2️⃣ **RIWAYAT (History) Button** 🟢
- **Algoritma**: 
  - `calculateStatistics(results)` - Agregasi semua screening
  - `getTrendStatus()` - Analisis tren skor
- **Fungsi**:
  - Menampilkan total screening
  - Menampilkan rata-rata skor
  - Menampilkan status tren (Meningkat/Menurun/Stabil)
  - Breakdown risiko (Tinggi/Sedang/Baik)
- **Lokasi Algoritma**: `history_page.dart` (Summary card)

### 3️⃣ **ANALITIK (Analytics) Button** 🔷 [NEW]
- **Algoritma**:
  - `calculateStatistics()` - Statistik keseluruhan
  - `analyzeAnswerPatterns()` - Analisis komponen
  - Perhitungan persentase dan trend
- **Fungsi**:
  - Overall statistics (total, rata-rata, min, max, tren)
  - Risk distribution visualization
  - Component analysis (Mood/Anxiety/Stress breakdown)
  - Score range analysis
  - Recent screenings table
- **Lokasi Algoritma**: `analytics_page.dart` (Semua sections)

### 4️⃣ **LAPORAN (Report) Button** 🟣
- **Algoritma**: Menggunakan hasil dari `calculateStatistics()`
- **Fungsi**:
  - Generate PDF dengan statistik
  - Export summary data
  - Personalized recommendations
- **Lokasi Algoritma**: `report_page.dart` (PDF generation)

### 5️⃣ **PROFIL (Profile) Button** 🌸
- **Fungsi**: 
  - Kelola profil pengguna
  - Pengaturan aplikasi
- **Catatan**: Tidak memiliki statistik (fokus pada data personal)

### 📊 STATISTIK WIDGET (Bagian Tengah Home Page)
- **Algoritma**: 
  - `statisticsProvider` - Computed statistics
  - Agregasi riwayat screening
- **Fungsi**:
  - Tampil summary stats
  - Total screenings
  - Average score
  - Trend status
  - Risk breakdown cards

---

## 📋 SCREENING PAGE - Statistik pada Submit

### 🔘 "Lihat Hasil" Button
- **Algoritma Utama**: `calculateRiskLevel(int score)`
  
**Proses Algoritma**:
```
1. Kumpulkan semua jawaban (9 pertanyaan)
2. Hitung total skor = sum(semua jawaban)
3. Terapkan algoritma risiko:
   - Jika skor >= 50  → Risiko Tinggi 🔴
   - Jika skor >= 30  → Risiko Sedang 🟠
   - Jika skor < 30   → Risiko Baik 🟢
4. Buat ScreeningResult object
5. Simpan ke screeningHistoryProvider
6. Tampilkan hasil di ResultPage
```

**Output**: ScreeningResult dengan score, riskLevel, date, answers

---

## 📈 RESULT PAGE - Rekomendasi Dinamis

### Algoritma: `getRecommendations(score, answers)`

**Rekomendasi Tinggi (≥50)** 🔴:
- 🔴 Segera konsultasi profesional
- 📞 Hubungi layanan konseling
- 😴 Prioritas istirahat
- 🧘 Meditasi mindfulness  
- 👥 Berbicara dengan terpercaya

**Rekomendasi Sedang (30-49)** 🟠:
- 🟠 Tingkatkan self-care
- 🏃 Olahraga teratur
- 🥗 Perhatian pola makan
- 📱 Batasi screen time
- 🎨 Lakukan hobi
- 📅 Pertimbangkan konsultasi

**Rekomendasi Baik (<30)** 🟢:
- 🟢 Pertahankan gaya hidup sehat
- ✨ Keseimbangan hidup-kerja
- 💪 Aktivitas fisik
- 🧠 Mindfulness
- 📱 Jaga hubungan sosial
- 👨‍⚕️ Screening berkala

---

## 📊 HISTORY PAGE - Statistics dari Riwayat

### Algoritma Utama: `calculateStatistics(List<ScreeningResult>)`

**Statistik yang Ditampilkan**:
- Total Screening: Jumlah screening keseluruhan
- Rata-rata Skor: Mean dari semua screening
- Status Tren: Perbandingan skor terbaru vs sebelumnya
  - Meningkat: recent > previous ⬆️
  - Menurun: recent < previous ⬇️
  - Stabil: recent = previous ➡️

**Risk Breakdown**:
- Count dan percentage untuk setiap level risiko
- Visual progress bars
- Color-coded display

---

## 🔍 ANALYTICS PAGE (NEW) - Analisis Mendalam

### Algoritma 1: Overall Statistics
```
Total Screenings: count semua screening
Average Score: sum(skor) / total screening  
Max Score: tertinggi dari semua skor
Min Score: terendah dari semua skor
Trend: recent vs previous comparison
```

### Algoritma 2: Risk Distribution
```
highRiskPercentage = (count_tinggi / total) × 100
moderateRiskPercentage = (count_sedang / total) × 100
lowRiskPercentage = (count_baik / total) × 100
```

### Algoritma 3: Component Analysis `analyzeAnswerPatterns()`
```
Mood/Depresi = (q0 + q1 + q2) / 3
Kecemasan = (q3 + q4 + q5) / 3  
Stress = (q6 + q7 + q8) / 3
```

### Algoritma 4: Score Range
```
Min, Max, Average visualization
Gradient scale (Green→Yellow→Red)
Risk tier indicator
```

### Algoritma 5: Recent Screenings
```
Sort by date descending
Take 5 most recent
Display: date, score, risk level
Color-coded badges
```

---

## 📊 Statistik Helper - Core Algorithms

**File**: `lib/features/insightmind/domain/usecases/statistics_helper.dart`

### Data Structures
```dart
class ScreeningResult {
  int score                    // 0-90 based on answers
  String riskLevel             // 'Tinggi'/'Sedang'/'Baik'
  DateTime date               // Kapan screening dilakukan
  List<int> answers           // 9 jawaban mentah
}

class StatisticsData {
  int totalScreenings
  double averageScore
  int highRiskCount
  int moderateRiskCount  
  int lowRiskCount
  List<ScreeningResult> history
  
  // Computed properties:
  double highRiskPercentage
  double moderateRiskPercentage
  double lowRiskPercentage
  String getTrendStatus()    // Trend analyzer
  int maxScore               // Highest score
  int minScore               // Lowest score
}
```

### Core Functions
```dart
1. calculateRiskLevel(int score) → String
   Menentukan kategori risiko berdasarkan skor

2. calculateStatistics(List<ScreeningResult>) → StatisticsData
   Mengagregasi semua screening ke dalam statistik

3. getRecommendations(int score, List<int> answers) → List<String>
   Menghasilkan 6+ rekomendasi berdasarkan risiko

4. analyzeAnswerPatterns(List<int> answers) → Map
   Memecah jawaban menjadi 3 komponen
```

### Providers
```dart
screeningHistoryProvider     // Menyimpan semua screening results
statisticsProvider           // Computed stats dari history
```

---

## 🎯 Ringkasan Fungsi Statistik per Tombol

| Tombol | Algoritma Utama | Fungsi | Lokasi |
|--------|-----------------|--------|--------|
| **Screening** | `calculateRiskLevel()` | Hitung skor & risiko | screening_page.dart |
| **Riwayat** | `calculateStatistics()` | Aggregasi & trend | history_page.dart |
| **Analitik** | `analyzeAnswerPatterns()` | Breakdown komponen | analytics_page.dart |
| **Laporan** | `calculateStatistics()` | PDF dengan stats | report_page.dart |
| **Profil** | - | Kelola data user | profile_page.dart |
| **Statistik Widget** | `statisticsProvider` | Summary display | home_page.dart |

---

## 📱 Responsive Algoritma

Semua algoritma bekerja seamlessly pada:
- 📱 Mobile (<600dp)
- 📱 Tablet (600-1200dp)  
- 💻 Desktop (≥1200dp)

UI akan menyesuaikan, algoritma tetap sama untuk konsistensi data.

---

## ✅ Status Implementasi

- ✅ Screening button: Score calculation + risk level
- ✅ History button: Statistics aggregation + trends
- ✅ Analytics button: Comprehensive analysis (NEW)
- ✅ Report button: PDF export dengan stats
- ✅ Home statistics card: Summary display
- ✅ Semua algoritma terintegrasi
- ✅ Tidak ada compilation errors
- ✅ Responsive design untuk semua buttons

---

## 🚀 Alur Data Lengkap

```
User Screening (9 questions)
    ↓
Screening Page "Lihat Hasil" Button
    ↓
calculateRiskLevel(score) Algorithm
    ↓
Save ScreeningResult to screeningHistoryProvider
    ↓
Show Result Page with getRecommendations()
    ↓
User dapat:
  - Lihat Riwayat → History Page (calculateStatistics)
  - Lihat Analitik → Analytics Page (analyzeAnswerPatterns)
  - Download Laporan → Report Page (statistics export)
  - Lihat Dashboard → Home Page (statisticsProvider summary)
```

---

**Kesimpulan**: Setiap tombol di aplikasi InsightMind sekarang memiliki fungsi statistik dan algoritma yang sesuai dengan peran masing-masing. Algoritma diorganisir secara terpusat di `statistics_helper.dart` dan diintegrasikan ke dalam UI melalui Riverpod providers untuk state management yang clean.
