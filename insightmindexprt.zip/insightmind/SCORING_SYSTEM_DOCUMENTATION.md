# InsightMind Scoring System - Complete Data Flow

## Overview
Sistem scoring terintegrasi penuh dari screening → statistics → analytics → PDF report

## Data Flow Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      SCREENING PAGE                             │
│  User menjawab 9 pertanyaan (nilai 0-9 per pertanyaan)        │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                    CALCULATION ENGINE                           │
│  Total Score = Sum of all answers (0-81 max)                  │
│  Risk Level:                                                    │
│   - Score >= 50  → TINGGI (High)                              │
│   - Score 30-49  → SEDANG (Moderate)                          │
│   - Score < 30   → BAIK (Good)                                │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│              PROVIDER STORAGE & STATE MANAGEMENT               │
│  screeningHistoryProvider:                                     │
│    Stores: List<ScreeningResult> = [                          │
│      {score, riskLevel, date, answers}                        │
│    ]                                                            │
│                                                                 │
│  scoreProvider:                                                 │
│    Stores: int (latest score)                                 │
│                                                                 │
│  answersProvider:                                              │
│    Stores: List<int> (latest answers)                         │
│                                                                 │
│  statisticsProvider:                                            │
│    Calculates from screeningHistory:                          │
│    - totalScreenings                                           │
│    - averageScore                                              │
│    - highRiskCount, moderateRiskCount, lowRiskCount          │
│    - maxScore, minScore                                        │
└──────────────────────────┬──────────────────────────────────────┘
                           │
          ┌────────────────┼────────────────┐
          │                │                │
          ▼                ▼                ▼
    ┌──────────┐    ┌──────────┐    ┌──────────┐
    │ Result   │    │Analytics │    │ PDF      │
    │ Page     │    │ Page     │    │ Report   │
    └──────────┘    └──────────┘    └──────────┘

## Detailed Scoring System

### 1. Screening Page (screening_page.dart)
**Input**: User answers (0-9 per question, 9 questions total)

**Processing**:
```dart
final ordered = <int>[];
for (final q in questions) {
  ordered.add(qState.answers[q.id]!);
}
final totalScore = ordered.fold<int>(0, (sum, score) => sum + score);
final riskLevel = calculateRiskLevel(totalScore);
```

**Output**: ScreeningResult object saved to providers
- screeningHistoryProvider += new result
- scoreProvider = totalScore
- answersProvider = ordered

### 2. Risk Level Calculation (statistics_helper.dart)
```dart
String calculateRiskLevel(int score) {
  if (score >= 50) return 'Tinggi';      // High risk
  else if (score >= 30) return 'Sedang'; // Moderate risk
  else return 'Baik';                    // Good status
}
```

**Risk Categories**:
- TINGGI (High): Score 50-81
  - Requires immediate professional consultation
  - Recommendations focus on urgent care
  
- SEDANG (Moderate): Score 30-49
  - Requires improved self-care
  - Recommendations for lifestyle changes
  
- BAIK (Good): Score 0-29
  - Maintains healthy status
  - Recommendations for maintenance

### 3. Statistics Calculation (statistics_helper.dart)
```dart
StatisticsData calculateStatistics(List<ScreeningResult> results) {
  - Counts results by risk level
  - Calculates average score
  - Tracks max/min scores
  - Stores complete history
}
```

### 4. Data Flow to Pages

#### Result Page (result_page.dart)
- Displays: Score + Risk Level
- Shows: Personalized recommendations
- Uses: getRecommendations(score, answers)
- Algorithms: 5 specific recommendations per risk level

#### Analytics Page (analytics_page.dart)
- Displays: Full statistics dashboard
- Shows:
  - Total screenings performed
  - Average score over time
  - Risk distribution (pie chart)
  - Score ranges analysis
  - Recent screening history
- Uses: statisticsProvider (auto-updates)

#### Report PDF (report_page.dart)
- Generates: Professional PDF report
- Includes:
  - Latest screening score + risk level
  - Personalized recommendations
  - Statistics summary
  - Date stamped
- Uses: Real-time provider data

## Testing Checklist

✅ **Scoring Calculation**
- [x] Total score calculated correctly
- [x] Risk level determined accurately
- [x] Risk categories work properly

✅ **Data Persistence**
- [x] screeningHistoryProvider stores results
- [x] scoreProvider updates with latest
- [x] statisticsProvider recalculates auto

✅ **Page Integration**
- [x] Result page shows correct score
- [x] Analytics updates with new data
- [x] PDF includes latest results

✅ **Recommendations**
- [x] Different recommendations per risk level
- [x] Based on actual answers (analyzeAnswerPatterns)
- [x] Actionable and specific

## Example Flow

### User Screening Journey:
1. User opens Screening Page
2. Answers 9 questions with scores (0-9 each)
3. Total: e.g., 8+7+6+5+4+3+2+1+0 = 36
4. Risk Level = "Sedang" (30-49 range)
5. Taps "Lihat Hasil" button

### Automatic Updates:
- Result Page shows: Score 36, Risk Level "Sedang"
- Recommendations display: "Tingkatkan self-care" approach
- Analytics Page updates: totalScreenings++, averageScore recalculates
- Profile Page shows: Latest status "Sedang"
- Statistics update: moderateRiskCount++
- PDF ready to download with all data

## Key Algorithms

### calculateRiskLevel(score)
Simple threshold-based categorization

### calculateStatistics(results)
Aggregate analysis of all screenings

### getRecommendations(score, answers)
Personalized advice based on score ranges and answer patterns

### analyzeAnswerPatterns(answers)
Breaks down by component: mood, anxiety, stress

## Performance Notes
- All calculations are deterministic (same input = same output)
- Data flows unidirectionally (screening → storage → display)
- No blocking operations (async where needed)
- Real-time updates via Riverpod providers

