# Dynamic Tips & Recommendations Update

## Summary
✅ Updated the app to show **dynamic tips and recommendations** based on screening score and risk level.

## Changes Made

### 1. Updated `statistics_helper.dart`

#### Updated `getRecommendations()` function:
- **Before**: Used OLD thresholds (score >= 50, score >= 30)
- **After**: Uses NEW thresholds (score >= 20, score >= 10) - appropriate for max score of 27
- Now correctly shows:
  - **Tinggi (High Risk)** - Scores 20-27: Urgent professional help recommendations
  - **Sedang (Moderate)** - Scores 10-19: Self-care improvement recommendations  
  - **Baik (Good)** - Scores 0-9: Maintenance recommendations

#### Created NEW `getTips()` function:
- Returns dynamic tips based on risk level (uses same 20/10 thresholds)
- Returns 6 actionable tips per risk level:

**Tinggi (High Risk - Scores 20-27):**
1. 🔴 Konsultasi Profesional - Segera hubungi psikolog/psikiater
2. 😴 Istirahat Total - Tidur 8-9 jam per hari
3. 🧘 Meditasi Intensif - Meditasi guided 15-20 menit 2x sehari
4. ⛔ Hindari Stress - Kurangi beban kerja, ambil cuti
5. 👥 Dukungan Sosial - Ceritakan perasaan kepada orang terpercaya
6. 💊 Pantau Kesehatan - Hindari alkohol & obat-obatan

**Sedang (Moderate - Scores 10-19):**
1. 🏃 Olahraga Rutin - 30 menit, 3-4x per minggu
2. 😴 Pola Tidur Stabil - 7-8 jam dengan jadwal konsisten
3. 🥗 Nutrisi Seimbang - Protein, sayur, buah, biji-bijian
4. 📱 Batasi Gadget - Kurangi screen time 1 jam sebelum tidur
5. 🎨 Hobi Positif - Luangkan waktu untuk hobi menyenangkan
6. 📅 Konsultasi Opsional - Pertimbangkan terapi/konseling

**Baik (Good - Scores 0-9):**
1. 💪 Tetap Aktif - Lanjutkan olahraga regular
2. 🌙 Tidur Berkualitas - 7-8 jam setiap malam
3. 🍽️ Makanan Sehat - Jaga pola makan yang sudah terbukti
4. 👨‍👩‍👧‍👦 Interaksi Sosial - Jaga hubungan baik dengan sosial
5. 🧠 Mindfulness Harian - Meditasi 10 menit setiap hari
6. 📊 Screening Berkala - Lakukan screening 1-2 bulan sekali

### 2. Updated `result_page.dart`

#### Replaced hardcoded tips with dynamic tips:
- **Before**: Had 4 hardcoded tip cards (Tidur Cukup, Olahraga Teratur, Makan Sehat, Interaksi Sosial)
- **After**: Calls `getTips(score)` to generate 6 dynamic tips based on actual score

#### Added helper methods:
- `_getIconFromName(String iconName)`: Maps icon names to Flutter IconData
- `_buildDynamicTips(int score)`: Generates list of tip widgets from getTips() result

#### Dynamic behavior:
- Tips section now renders based on score:
  - Score 0-9: Shows 6 maintenance tips
  - Score 10-19: Shows 6 improvement tips
  - Score 20-27: Shows 6 urgent-action tips

## How it Works

### Flow:
1. User completes screening and gets a score (0-27)
2. `result_page.dart` displays result with score
3. Page calls `getRecommendations(score, answers)` → shows 5-6 recommendations
4. Page calls `getTips(score)` → shows 6 tips
5. Both recommendations and tips change based on the score

### Example Scenarios:

**Score 5 (Baik/Good):**
- Recommendations: Focus on maintaining health
- Tips: Maintenance-focused (keep exercising, sleep well, eat healthy, etc.)
- Color: 🟢 Green

**Score 15 (Sedang/Moderate):**
- Recommendations: Focus on improvement and self-care
- Tips: Improvement-focused (exercise regularly, stable sleep, balanced nutrition, limit gadgets, etc.)
- Color: 🟠 Orange

**Score 25 (Tinggi/High):**
- Recommendations: Focus on professional help and urgent care
- Tips: Urgent-focused (professional consultation, adequate rest, intensive meditation, stress management, etc.)
- Color: 🔴 Red

## Testing

To test:
1. Complete screening with different answers:
   - Score ~5: Select mostly "Tidak Sama Sekali" (0 points)
   - Score ~15: Mix of "Beberapa Hari" and "Lebih Dari Separuh Hari"
   - Score ~25: Select mostly "Hampir Setiap Hari" (3 points)
2. Check result page - tips and recommendations should change accordingly

## Technical Details

### Score Thresholds (Max = 27):
- **Baik (Good)**: 0-9 (0-33%)
- **Sedang (Moderate)**: 10-19 (37-70%)
- **Tinggi (High)**: 20-27 (74-100%)

### Risk Level Colors:
- 🟢 Green for Baik (Good)
- 🟠 Orange for Sedang (Moderate)
- 🔴 Red for Tinggi (High)

### Files Modified:
1. `lib/features/insightmind/domain/usecases/statistics_helper.dart`
   - Updated `getRecommendations()` with new thresholds
   - Added new `getTips()` function with dynamic tips

2. `lib/features/insightmind/presentation/pages/result_page.dart`
   - Replaced hardcoded tips with dynamic `getTips(score)` call
   - Added `_getIconFromName()` helper for icon mapping
   - Added `_buildDynamicTips()` method for generating tip widgets
   - Modified `_buildTipCard()` to accept IconData instead of icon names

## Result

✅ Recommendations now dynamically change based on score
✅ Tips now dynamically change based on score  
✅ All changes respect the 20/10 score thresholds (max 27)
✅ User sees appropriate guidance for their risk level
✅ System is now ready for "rekomendasi dan tips menyesuaikan dengan skor"
