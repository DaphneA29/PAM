# 📚 Panduan Integrasi Widgets - InsightMind

## Daftar Widgets yang Telah Dibuat

### ✅ Health Dashboard Widget
**File:** `lib/features/insightmind/presentation/widgets/health_dashboard.dart`

**Kegunaan:** Menampilkan status kesehatan mental dengan gradient background dan mini stats.

**Cara Menggunakan:**
```dart
import 'package:insightmind/features/insightmind/presentation/widgets/health_dashboard.dart';

// Di dalam widget build:
const HealthDashboard(),
```

**Features:**
- Gradient background dengan indigo theme
- Mini stats (Hari Baik, Stress Level, Mood Avg)
- Status kesehatan mental dengan icon
- Responsive design

---

### ✅ Statistics Widget
**File:** `lib/features/insightmind/presentation/widgets/statistics_widget.dart`

**Kegunaan:** Menampilkan statistik screening minggu ini.

**Cara Menggunakan:**
```dart
import 'package:insightmind/features/insightmind/presentation/widgets/statistics_widget.dart';

// Di dalam widget build:
const StatisticsWidget(),
```

**Features:**
- 3 metric cards (Screening, Avg Score, Completed)
- Icon dan color yang berbeda
- Responsive layout

---

### ✅ Health Tips Widget
**File:** `lib/features/insightmind/presentation/widgets/health_tips_widget.dart`

**Kegunaan:** Menampilkan tips kesehatan mental dalam format horizontal scroll.

**Cara Menggunakan:**
```dart
import 'package:insightmind/features/insightmind/presentation/widgets/health_tips_widget.dart';

// Di dalam widget build:
const HealthTipsWidget(),
```

**Features:**
- 4 tips dengan colorful design
- Horizontal scrollable
- Setiap tip memiliki icon, title, dan description

---

### ✅ Onboarding Widget
**File:** `lib/features/insightmind/presentation/widgets/onboarding_widget.dart`

**Kegunaan:** Banner untuk mendorong user mulai screening.

**Cara Menggunakan:**
```dart
import 'package:insightmind/features/insightmind/presentation/widgets/onboarding_widget.dart';

// Di dalam widget build:
const OnboardingWidget(),
```

**Features:**
- Gradient background
- Call-to-action button
- Clean dan minimalist design

---

## 📄 Pages yang Telah Diupdate

### 🏠 Home Page (`home_page.dart`)
**Status:** ✅ Fully Updated

**Perubahan:**
- Menghilangkan AppBar, menggunakan SafeArea
- Menambahkan header dengan greeting message
- Integrasi HealthDashboard widget
- Quick action buttons (Screening, Riwayat)
- Features grid dengan 4 fitur utama
- Bottom navigation ready

**Struktur:**
```
SafeArea
├── CustomHeader (Greeting + Icon)
├── HealthDashboard
├── QuickActions (Row: Screening, Riwayat)
└── FeaturesGrid (4 Feature Cards)
```

---

### 📋 Screening Page (`screening_page.dart`)
**Status:** ✅ Fully Updated

**Perubahan:**
- Menghilangkan AppBar, menggunakan custom header dengan back button
- Progress bar dengan gradient background
- Enhanced question cards dengan border dan shadow
- Custom option buttons dengan radio-style indicator
- Better visual feedback for selected answers

**Struktur:**
```
SafeArea
├── CustomHeader (Back Button + Title)
├── ProgressCard (Gradient Background)
├── QuestionList (Enhanced _QuestionCard)
│   └── _QuestionCard (dengan numbered badge)
│       └── OptionButtons (dengan circle checkbox)
└── ActionButtons (View Results, Reset)
```

---

### 🎯 Result Page (`result_page.dart`)
**Status:** ✅ Fully Updated

**Perubahan:**
- Gradient background sesuai risk level
- Better result visualization
- Recommendation section dengan icon
- Tips perawatan diri dengan 4 item
- Share functionality
- Improved button styling

**Struktur:**
```
SafeArea
├── CustomHeader (Back Button + Title)
├── ResultCard (Gradient Background)
│   ├── Risk Icon (Dynamic)
│   ├── Large Score Display
│   └── Risk Level Badge
├── RecommendationSection
│   └── Icon + Text
├── TipsSection
│   └── 4 TipCards
└── ActionButtons (Finish, Share)
```

---

### 📱 History Page (`history_page.dart`)
**Status:** ✅ Created

**Fitur:**
- Back navigation button
- Summary card dengan statistik
- List view dari history screening
- Color-coded status (Green, Orange, Red)
- Formatted date dengan indonesian locale

**Struktur:**
```
SafeArea
├── CustomHeader (Back Button + Title)
├── SummaryCard (Teal Gradient)
│   ├── Total Screening
│   ├── Average Score
└── HistoryList
    └── HistoryCard (dengan color indicator)
```

---

### 👤 Profile Page (`profile_page.dart`)
**Status:** ✅ Created

**Fitur:**
- Circular avatar dengan gradient
- Personal info section
- Health info section
- Settings section dengan switches
- Logout button (dengan confirmation dialog)

**Struktur:**
```
SafeArea
├── CustomHeader (Back Button + Title)
├── ProfileHeader
│   ├── Avatar Circle
│   ├── Name
│   └── Email
├── PersonalInfoSection
├── HealthInfoSection
├── SettingsSection
│   ├── Notifications Toggle
│   ├── Dark Mode Toggle
│   └── Language
└── LogoutButton
```

---

## 🎨 Design Tokens

### Colors
```dart
Primary: Colors.indigo (600, 700, 800)
Secondary: Colors.teal
Accent: Colors.orange, Colors.blue, Colors.purple, Colors.pink, Colors.green
Background: Color(0xFFF7F8FC)
Neutral: Colors.grey[50-900]
```

### Spacing
```dart
const EdgeInsets.all(16)      // Standard padding
const EdgeInsets.all(24)      // Large padding
const SizedBox(height: 8)     // Small gap
const SizedBox(height: 12)    // Medium gap
const SizedBox(height: 16)    // Standard gap
const SizedBox(height: 20)    // Large gap
const SizedBox(height: 24)    // Extra large gap
```

### Border Radius
```dart
BorderRadius.circular(8)      // Small elements
BorderRadius.circular(12)     // Medium containers
BorderRadius.circular(16)     // Large containers
```

### Typography
```dart
fontSize: 24, FontWeight.bold      // Page titles
fontSize: 18, FontWeight.w600      // Section titles
fontSize: 14, FontWeight.w500      // Body text
fontSize: 12, FontWeight.w400      // Supporting text
fontSize: 11, FontWeight.normal    // Minor text
```

---

## 🔧 Cara Menambahkan Widget Baru ke Home Page

Jika Anda ingin menambahkan widget tambahan (misal StatisticsWidget), tambahkan di home_page.dart:

```dart
import 'package:insightmind/features/insightmind/presentation/widgets/statistics_widget.dart';

// Di dalam _buildFeaturesSection atau di mana saja:
const SizedBox(height: 24),
const StatisticsWidget(),
const SizedBox(height: 24),
const HealthTipsWidget(),
```

---

## 📦 Widget Files Structure

```
lib/features/insightmind/presentation/widgets/
├── health_dashboard.dart        ✅ Created
├── statistics_widget.dart       ✅ Created
├── health_tips_widget.dart      ✅ Created
├── onboarding_widget.dart       ✅ Created
└── [future widgets...]
```

---

## 🚀 Next Steps

### Untuk Development:
1. Tambahkan bottom navigation bar dengan TabBar
2. Implementasi real data dari database
3. Tambahkan animations dan transitions
4. Implementasi push notifications
5. Tambahkan chart untuk trend analysis

### Design Improvements:
1. Implementasi theme switching (light/dark mode)
2. Tambahkan more micro-interactions
3. Optimize images dengan caching
4. Implementasi skeleton loaders

### Features:
1. Export data ke PDF
2. Sharing ke social media
3. Konsultasi online dengan psikolog
4. Journal/diary feature
5. Community forum

---

**Created with ❤️ for InsightMind v2**
