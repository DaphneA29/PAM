package com.example.flutter_application_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
