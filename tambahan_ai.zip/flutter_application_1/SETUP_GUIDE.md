# Setup Guide untuk Fitur Baru

## 1. Instalasi Dependencies

Dependencies sudah ditambahkan ke `pubspec.yaml`. Jalankan:

```bash
flutter pub get
```

## 2. Android Configuration (AndroidManifest.xml)

Buka `android/app/src/main/AndroidManifest.xml` dan tambahkan permissions:

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACTIVITY_RECOGNITION" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-permission android:name="android.permission.INTERNET" />

<!-- For Android 12+ (pedometer) -->
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

## 3. Build.gradle Configuration

Edit `android/build.gradle`:

```gradle
allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
```

Edit `android/app/build.gradle`:

```gradle
android {
    ...
    compileSdkVersion 34  // Update to latest

    defaultConfig {
        ...
        minSdkVersion 21   // Untuk ML Kit
        targetSdkVersion 34
    }
}

dependencies {
    ...
    // ML Kit sudah di-handle oleh package google_ml_kit
}
```

## 4. iOS Configuration (Opsional)

Edit `ios/Podfile`:

```ruby
post_install do |installer|
  installer.pods_project.targets.each do |target|
    flutter_additional_ios_build_settings(target)
    target.build_configurations.each do |config|
      config.build_settings['GCC_PREPROCESSOR_DEFINITIONS'] ||= [
        '$(inherited)',
        'PERMISSION_CAMERA=1',
      ]
    end
  end
end
```

Edit `ios/Runner/Info.plist`:

```xml
<key>NSCameraUsageDescription</key>
<string>Kami membutuhkan akses kamera untuk mendeteksi emosi melalui wajah Anda</string>

<key>NSMotionUsageDescription</key>
<string>Kami membutuhkan akses motion sensor untuk menghitung langkah Anda</string>
```

## 5. Testing Features

### Mood Tracker dengan Kamera:

1. Buka Home Page
2. Klik "Mood Tracker" card
3. Klik "Ambil Foto" untuk mengaktifkan kamera
4. Ambil foto wajah yang jelas
5. Lihat hasil deteksi emosi + rekomendasi AI

### Exercise Tracker Smartwatch:

1. Buka Home Page
2. Klik "Exercise" card
3. Pastikan app memiliki permission untuk "Activity Recognition"
4. Klik "Mulai" untuk memulai tracking
5. Mulai berjalan/berlari
6. Lihat step counter real-time
7. Klik "Simpan" ketika selesai

## 6. Troubleshooting

### Camera Permission Error:

```dart
// Pastikan permission_handler di-setup dengan benar
// Jalankan di Android:
// adb shell pm grant com.example.flutter_application_1 android.permission.CAMERA
```

### Pedometer Not Counting:

- Pastikan Google Play Services terinstall di device
- Jalankan di physical device, bukan emulator
- Enable "Activity Recognition" di app settings
- Pastikan phone di pocket/tangan saat berjalan

### ML Kit Initialization Error:

- Download Google Play Services for ML Kit melalui Google Play
- Pastikan internet connection aktif
- Restart app

## 7. File Baru yang Ditambahkan

```
lib/
  services/
    emotion_detection_service.dart          # Core emotion detection logic
  pages/
    mood_tracker_page_new.dart              # Advanced mood tracker with camera
    exercise_tracker_page_smartwatch.dart   # Smartwatch-style exercise tracking

FEATURES_ADVANCED.md                        # Dokumentasi lengkap
SETUP_GUIDE.md                              # File ini
```

## 8. Versi Widget

- Old `mood_tracker_page.dart` - Basic mood selection (tetap ada, di-fix layout issue)
- New `mood_tracker_page_new.dart` - Camera + AI emotion detection ✨
- Old `exercise_tracker_page.dart` - Duration-based tracking (tetap ada)
- New `exercise_tracker_page_smartwatch.dart` - Smartwatch step counter ✨

## 9. Running the App

```bash
# Clean build
flutter clean
flutter pub get

# Run on device
flutter run

# Run with specific device
flutter devices
flutter run -d <device_id>
```

## 10. Performance Tips

- Emotion detection bisa lambat di device lama
- Exercise tracking menggunakan battery lebih banyak (wakelock)
- Disable wakelock setelah selesai tracking
- Gunakan camera dengan resolusi sedang (tidak full HD)

---

## API Integration (Opsional - Untuk Python Backend)

Jika ingin menggunakan Python untuk emotion detection:

```python
# requirements.txt
flask==2.3.0
opencv-python==4.7.0
deepface==0.0.79
tensorflow==2.13.0
numpy==1.24.0
```

```python
# app.py
from flask import Flask, request, jsonify
from deepface import DeepFace
import base64
import cv2
import numpy as np

@app.route('/detect-emotion', methods=['POST'])
def detect_emotion():
    data = request.json
    img_data = base64.b64decode(data['image'])
    nparr = np.frombuffer(img_data, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    result = DeepFace.analyze(img, actions=['emotion'])
    emotion = max(result[0]['emotion'], key=result[0]['emotion'].get)

    return jsonify({'emotion': emotion})
```

Komunikasi dari Flutter:

```dart
Future<String> detectEmotionFromServer(Uint8List imageBytes) async {
  final base64Image = base64Encode(imageBytes);
  final response = await http.post(
    Uri.parse('http://your-server/detect-emotion'),
    headers: {'Content-Type': 'application/json'},
    body: jsonEncode({'image': base64Image}),
  );

  if (response.statusCode == 200) {
    return jsonDecode(response.body)['emotion'];
  }
  throw Exception('Failed to detect emotion');
}
```

---

Selamat! Features baru sudah siap digunakan! 🎉
