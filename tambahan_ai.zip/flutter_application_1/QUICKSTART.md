# Quick Start Guide - InsightMind v2

## 🎯 Panduan Cepat Menggunakan Aplikasi

### 1️⃣ Pertama Kali Membuka Aplikasi

```
Aplikasi InsightMind → Login/Register Page
```

**Pilih Tab "Daftar"** untuk membuat akun baru:

- Masukkan Nama Lengkap
- Masukkan Email
- Buat Password
- Konfirmasi Password
- Tekan "Daftar"

Atau **Pilih Tab "Masuk"** jika sudah punya akun:

- Email
- Password
- Tekan "Masuk"

---

### 2️⃣ Halaman Utama (Home Page)

Setelah login, Anda akan masuk ke **Home Page** yang menampilkan:

#### **🔴 Screening Mental Health** (Hero Section)

- Besar, berwarna, dan menonjol
- Klik "Mulai" untuk memulai screening kesehatan mental

#### **💚 Fitur Kesehatan** (Grid 2x2)

- **😊 Mood Tracker** - Catat suasana hati Anda
- **😴 Sleep Tracker** - Monitor pola tidur
- **💧 Hydration** - Segera hadir (soon)
- **🏃 Exercise** - Segera hadir (soon)

#### **💡 Tips Kesehatan**

- Tips harian yang berguna untuk kesehatan mental

---

### 3️⃣ Screening Mental Health (Quiz)

**Flow**: Klik "Mulai Screening" → Quiz Page

Setiap pertanyaan ditampilkan dalam **satu layar penuh**:

1. ✅ Baca pertanyaan dengan cermat
2. ✅ Pilih salah satu dari 4 opsi jawaban
3. ✅ Tekan **"Lanjut"** untuk pertanyaan berikutnya
4. ✅ Gunakan **"Sebelumnya"** jika ingin mengoreksi jawaban
5. ✅ Setelah semua 9 pertanyaan dijawab, tekan **"Selesai"**

### 4️⃣ Ringkasan & AI Insights

Setelah menyelesaikan screening:

**Halaman Ringkasan** menampilkan:

- ✅ Semua jawaban yang Anda berikan
- ✅ Status jawaban (Dijawab/Belum)

**Tekan "Lihat AI Insights"** untuk mendapatkan:

- 📊 **Health Score** (0-100%)
- 🎯 **Status Kesehatan** dengan rekomendasi
- 💡 **AI Recommendations** personal
- 📈 **Daily Overview** aktivitas kesehatan hari ini
- 🏥 **Tips Kesehatan** yang berguna

---

### 5️⃣ Fitur Kesehatan

#### **😊 Mood Tracker**

1. Pilih level mood Anda (emoji 😢 hingga 😄)
2. Tambahkan catatan opsional (apa yang mempengaruhi mood)
3. Tekan "Simpan Mood"
4. Lihat riwayat mood hari ini di bawah

#### **😴 Sleep Tracker**

1. Atur waktu tidur dengan time picker
2. Atur waktu bangun
3. Lihat durasi tidur yang terhitung otomatis
4. Berikan rating untuk kualitas tidur (1-5 bintang)
5. Tekan "Simpan Data Tidur"
6. Lihat riwayat di bawah

---

### 6️⃣ Customization & Settings

#### **🎨 Kustomisasi Warna Tema**

**Via Home Page**:

- Klik ikon 🎨 (palette) di AppBar
- Pilih warna dari preset atau use color picker

**Via Settings**:

- Menu drawer → Settings
- Scroll ke bagian "Tema"
- Klik "Kustomisasi Warna Tema"
- Pilih warna atau gunakan color picker
- Perubahan langsung diterapkan ✨

#### **🌓 Mode Tampilan (Theme)**

Di Settings:

- **Terang** - Tampilan light mode
- **Gelap** - Tampilan dark mode
- **Otomatis** - Ikuti pengaturan sistem device

---

### 7️⃣ Profil Saya

**Akses via**:

- Klik ikon 👤 di AppBar HomeScreen
- Atau Menu Drawer → Tap on header

**Halaman Profil menampilkan/edit**:

- Nama Lengkap
- Email (read-only)
- Umur (opsional)
- Jenis Kelamin (opsional)

Setiap perubahan otomatis tersimpan.

---

### 8️⃣ Menu Drawer

Klik ☰ (hamburger menu) untuk akses:

| Menu              | Deskripsi                                    |
| ----------------- | -------------------------------------------- |
| **Riwayat** 📜    | Lihat semua hasil screening sebelumnya       |
| **Pengaturan** ⚙️ | Mode tampilan, kustomisasi tema, tentang app |
| **Logout** 🚪     | Keluar dari akun dan kembali ke login        |

---

## 🔐 Keamanan & Data

✅ **Data Disimpan Lokal** di device Anda

- SharedPreferences: Login, theme, settings
- Hive: History, health metrics (lebih cepat)

✅ **Privacy**:

- Tidak ada data yang dikirim ke server (untuk sekarang)
- Password disimpan lokal (tips: di production gunakan hashing)

---

## 💡 Tips & Tricks

### **Tips Menggunakan Screening**

- ✅ Jawab dengan jujur untuk hasil yang akurat
- ✅ Screening dapat diulang kapan saja
- ✅ Bandingkan hasil dari waktu ke waktu

### **Tips Tracking Kesehatan**

- ✅ Catat mood setiap hari untuk pattern yang jelas
- ✅ Tidur 7-8 jam per malam adalah ideal
- ✅ Konsistensi tracking lebih penting dari perfeksi

### **Tips UI/UX**

- ✅ Klik AppBar back button untuk kembali
- ✅ Swipe dari kiri untuk open drawer di beberapa halaman
- ✅ Gunakan refresh untuk reload data terbaru

---

## 🚀 Fitur yang Akan Datang

Fitur yang sedang dikembangkan:

- 💧 **Hydration Tracker** - Track konsumsi air harian
- 🏃 **Exercise Tracker** - Monitor aktivitas olahraga
- 📱 **Push Notifications** - Reminder untuk tracking
- 📊 **Advanced Analytics** - Charts dan trending
- 🌐 **Backend Sync** - Sync data ke cloud
- 👥 **Social Features** - Share progress dengan teman

---

## ❓ FAQ

**Q: Bagaimana jika saya lupa password?**
A: Untuk sekarang belum ada fitur reset password. Anda hanya bisa membuat akun baru dengan email lain.

**Q: Apakah data saya aman?**
A: Ya, data disimpan lokal di device Anda. Tidak ada yang dikirim ke server.

**Q: Bisakah saya backup data?**
A: Belum ada fitur backup built-in, tapi dapat dikembangkan di masa depan.

**Q: Berapa lama screening memakan waktu?**
A: Sekitar 5-10 menit tergantung kecepatan Anda menjawab.

**Q: Bolehkah saya mengubah email?**
A: Belum ada fitur untuk mengubah email, hanya nama dan profil lain.

---

## 📞 Butuh Bantuan?

Untuk pertanyaan atau laporan bug:

- Periksa FEATURES.md untuk dokumentasi lengkap
- Review code comments untuk penjelasan teknis
- Test semua fitur di different scenarios

---

**Version**: 1.0.0  
**Last Updated**: January 2026  
**Status**: ✅ Ready to Use
