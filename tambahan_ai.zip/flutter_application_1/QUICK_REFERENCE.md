# 🎯 Quick Reference - Advanced Features

## 🚀 Getting Started

### 1. Install Dependencies

```bash
cd flutter_application_1
flutter pub get
```

### 2. Add Permissions to `android/app/src/main/AndroidManifest.xml`

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.ACTIVITY_RECOGNITION" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
```

### 3. Update SDK in `android/app/build.gradle`

```gradle
minSdkVersion 21
targetSdkVersion 34
```

### 4. Run the App

```bash
flutter run
```

---

## 😊 Mood Tracker - New Version

**Location**: `lib/features/pages/mood_tracker_page_new.dart`

### How to Use:

1. Tap "Mood Tracker" on home page
2. Choose between:
   - **📸 Take Photo** - AI detects your emotion from face
   - **😐 Manual Select** - Pick mood from 6 options
3. View AI recommendation
4. Tap "Simpan Mood" to save

### Emotions Detected:

| Emoji | Emotion | Condition              |
| ----- | ------- | ---------------------- |
| 😊    | Bahagia | Smile > 70%            |
| 😄    | Senang  | Smile 50-70%           |
| 😌    | Santai  | Relaxed face           |
| 😐    | Netral  | No expression          |
| 😕    | Ragu    | Head tilt > 25°        |
| 😢    | Sedih   | No smile + eyes closed |

### Architecture:

```
MoodTrackerPage (ConsumerStatefulWidget)
├── CameraController (camera package)
├── EmotionDetectionService
│   ├── FaceDetector (google_ml_kit)
│   └── Emotion Analysis
└── HealthMetricsProvider (Riverpod)
```

---

## 🏃 Exercise Tracker - Smartwatch Mode

**Location**: `lib/features/pages/exercise_tracker_page_smartwatch.dart`

### How to Use:

1. Tap "Exercise" on home page
2. Grant "Activity Recognition" permission when prompted
3. Tap "Mulai" to start tracking
4. Start walking/running
5. Watch stats update in real-time
6. Tap "Simpan" when done

### Real-Time Stats:

| Stat     | Unit     | Update                |
| -------- | -------- | --------------------- |
| Langkah  | steps    | Every step            |
| Status   | 🚶/🏃/⏸️ | Every activity change |
| Kalori   | kcal     | Every 10 steps        |
| Durasi   | HH:MM:SS | Every second          |
| Avg Pace | step/min | Real-time             |
| % Target | %        | Real-time             |

### Activity Detection:

- 🚶 Walking - Normal pace
- 🏃 Running - Fast pace
- ⏸️ Stopped - No movement detected

### Architecture:

```
ExerciseTrackerPageSmartWatch (ConsumerStatefulWidget)
├── Pedometer (pedometer package)
│   ├── StepCountStream
│   └── PedestrianStatusStream
├── ActivityDetection
├── Wakelock (keep screen on)
└── HealthMetricsProvider (Riverpod)
```

---

## 📱 Technical Stack

### Packages:

- **camera**: Real-time camera feed
- **google_ml_kit**: Face detection & landmarks
- **image**: Image processing
- **pedometer**: Step counter
- **wakelock**: Keep screen on
- **permission_handler**: Runtime permissions

### Data Flow:

```
User Action
    ↓
Widget (ConsumerStatefulWidget)
    ↓
Service Layer (ML Kit / Pedometer)
    ↓
Riverpod Provider (State Management)
    ↓
Hive Database (Local Storage)
    ↓
Health Metrics History
```

---

## 🔍 Debugging Tips

### Mood Tracker Issues:

```dart
// Check face detection
print('Faces detected: ${detectedFaces.length}');
print('Confidence: ${detectedFace.confidence}');

// Check emotion classification
print('Smile: ${face.smilingProbability}');
print('Head angle: ${face.headEulerAngleY}');
```

### Exercise Tracker Issues:

```dart
// Check step count
print('Steps: $_steps');
print('Status: $_status');
print('Activity: ${event.status}');
```

### Permission Issues:

```bash
# Check permissions
adb shell pm list permissions

# Grant permission
adb shell pm grant com.example.flutter_application_1 android.permission.CAMERA

# Check device capabilities
adb shell cmd sensorservice list
```

---

## 📊 Database Schema

### HealthMetric Structure:

```dart
class HealthMetric {
  String id;                    // UUID
  String userId;                // User reference
  String type;                  // 'mood' | 'exercise'
  double value;                 // Score (1-5) or steps
  String notes;                 // Emotion name or stats
  DateTime recordedAt;          // Timestamp
}
```

### Storage Example:

```
Mood Entry:
{
  id: "uuid-123",
  userId: "user-456",
  type: "mood",
  value: 4.0,           // MoodScore
  notes: "Senang",      // Detected emotion
  recordedAt: 2024-01-07 14:30:00
}

Exercise Entry:
{
  id: "uuid-789",
  userId: "user-456",
  type: "exercise",
  value: 5280.0,        // Steps
  notes: "Langkah: 5280 | Kalori: 211.2 | Durasi: 45:30",
  recordedAt: 2024-01-07 15:15:00
}
```

---

## ⚙️ Configuration

### Mood Tracker Config:

```dart
// Emotion detection sensitivity
FaceDetectorOptions(
  enableClassification: true,   // Enable emotion analysis
  enableLandmarks: true,        // Face landmarks
  enableContours: true,         // Face shape
)

// Emotion thresholds
smilingProbability > 0.7 → Happy
headEulerAngleY > 25 → Confused
```

### Exercise Tracker Config:

```dart
int dailyGoal = 8000;           // Target steps
double caloriesPerStep = 0.04;  // Cal calculation
Duration wakelock = always on;  // During tracking
```

---

## 🎮 User Flow

### Mood Tracker Flow:

```
Home → Mood Tracker
  ↓
  ├─→ Take Photo
  │   ├─→ Camera View
  │   ├─→ ML Kit Detection
  │   ├─→ Emotion Analysis
  │   └─→ Show Results
  │
  └─→ Manual Select
      ├─→ 6 Mood Grid
      ├─→ AI Recommendation
      └─→ Show Results
  ↓
Save Mood → History
```

### Exercise Tracker Flow:

```
Home → Exercise Tracker
  ↓
  Permissions Check
  ↓
  Start Tracking
  ├─→ Wakelock ON
  ├─→ Pedometer Listening
  ├─→ Status Detection
  └─→ Real-time Updates
  ↓
  Save Session → History
  ├─→ Step Count
  ├─→ Duration
  ├─→ Calories
  └─→ Stats
```

---

## 🧪 Testing Checklist

- [ ] Camera works on physical device
- [ ] Face detection detects face correctly
- [ ] Emotions detected accurately
- [ ] Steps counting in real-time
- [ ] Activity detection (walk/run/stop) works
- [ ] Data saved to history
- [ ] Permissions requested correctly
- [ ] App doesn't crash with missing permissions
- [ ] Wakelock works (screen stays on)
- [ ] AI recommendations display
- [ ] All stats calculate correctly

---

## 📞 Support

### Common Errors:

**"Camera permission denied"**

```bash
→ Go to Settings > Apps > InsightMind > Permissions > Camera
→ Enable Camera permission
```

**"Steps not counting"**

```bash
→ Ensure device has Google Play Services
→ Enable Activity Recognition in app settings
→ Use physical device (emulator won't work)
```

**"Face not detected"**

```bash
→ Ensure good lighting
→ Face should be clearly visible
→ Try again with different angle
```

**"App crashes on startup"**

```bash
→ Run: flutter clean
→ Run: flutter pub get
→ Run: flutter run
```

---

## 📚 Documentation Files

- `FEATURES_SUMMARY.md` - Complete feature overview
- `SETUP_GUIDE.md` - Detailed setup instructions
- `FEATURES_ADVANCED.md` - Technical deep dive

---

## 🎉 You're All Set!

Your InsightMind app now has:

- ✅ AI-powered Mood Detection with facial recognition
- ✅ Smartwatch-style Exercise Tracking with real-time steps
- ✅ Cloud-free, privacy-first architecture
- ✅ Beautiful, modern UI/UX
- ✅ Seamless integration with existing features

Happy tracking! 🚀
