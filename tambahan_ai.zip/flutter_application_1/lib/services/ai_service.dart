import 'dart:convert';
import 'package:http/http.dart' as http;

class AiService {
  final String _apiKey = 'AIzaSyDQyHSyDPIAhvlW2dLs5pRL1C5SjQBES9M';
  
  // UPDATE: Pake model gemini-2.5-flash sesuai hasil diagnosa lu
  final String _baseUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

  Future<String> sendMessage(String message) async {
    try {
      final url = Uri.parse('$_baseUrl?key=$_apiKey');

      final body = jsonEncode({
        "contents": [
          {
            "role": "user",
            "parts": [
              {"text": message}
            ]
          }
        ],
        // Gemini 2.5 Flash mendukung 'system_instruction' secara native
        "system_instruction": {
          "parts": [
            {
              "text": "Kamu adalah InsightMind AI, asisten psikolog yang sangat empatik dan hangat. "
                      "Gunakan bahasa Indonesia yang santai tapi tetap sopan dan menenangkan."
            }
          ]
        },
        "generationConfig": {
          "temperature": 1.0,
          "topP": 0.95,
          "topK": 64,
          "maxOutputTokens": 2048,
        }
      });

      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: body,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['candidates'][0]['content']['parts'][0]['text'];
      } else {
        print('DEBUG ERROR HTTP: ${response.statusCode} - ${response.body}');
        return 'Daph, server lagi rewel nih. Coba sapa aku lagi ya!';
      }
    } catch (e) {
      print('DEBUG ERROR CONNECTION: $e');
      return 'Koneksi lu lagi gak stabil nih, bro. Cek internet ya!';
    }
  }
}