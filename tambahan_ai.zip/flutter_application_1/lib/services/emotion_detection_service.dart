import 'dart:developer' as developer;

/// Service untuk emotion recommendations tanpa camera/image processing
class EmotionDetectionService {
  /// Placeholder untuk emotion detection (camera feature disabled)
  /// Now only handles emotion recommendation logic
  void initialize() {
    // Initialization disabled - camera feature removed
  }

  /// Placeholder untuk detectEmotions - tidak digunakan lagi
  Future<List<DetectedFace>> detectEmotions(dynamic image) async {
    return <DetectedFace>[];
  }

  /// Get emotion description and recommendations
  EmotionRecommendation getEmotionRecommendation(String emotion) {
    switch (emotion) {
      case 'Bahagia':
        return EmotionRecommendation(
          emoji: '😊',
          title: 'Kamu Terlihat Bahagia!',
          description: 'Suasana hati kamu sangat positif hari ini.',
          recommendation:
              'Pertahankan energi positif ini dengan melakukan aktivitas yang kamu sukai.',
          moodScore: 5,
          color: 0xFFFFD700,
        );
      case 'Senang':
        return EmotionRecommendation(
          emoji: '😄',
          title: 'Kamu Terlihat Senang',
          description: 'Kamu dalam suasana hati yang bagus.',
          recommendation:
              'Ini adalah waktu yang baik untuk berbagi kebahagiaan dengan orang lain.',
          moodScore: 4,
          color: 0xFF90EE90,
        );
      case 'Santai':
        return EmotionRecommendation(
          emoji: '😌',
          title: 'Kamu Terlihat Santai',
          description: 'Kamu dalam kondisi yang tenang dan rileks.',
          recommendation:
              'Pertahankan ketenangan ini dengan melakukan aktivitas yang menenangkan.',
          moodScore: 3,
          color: 0xFF87CEEB,
        );
      case 'Netral':
        return EmotionRecommendation(
          emoji: '😐',
          title: 'Ekspresi Netral',
          description: 'Kamu dalam keadaan emosi yang stabil.',
          recommendation:
              'Coba lakukan aktivitas yang bisa meningkatkan suasana hatimu.',
          moodScore: 2,
          color: 0xFFC0C0C0,
        );
      case 'Ragu':
        return EmotionRecommendation(
          emoji: '😕',
          title: 'Terlihat Ragu',
          description: 'Kamu mungkin sedang berpikir keras tentang sesuatu.',
          recommendation:
              'Coba ambil napas dalam dan pikirkan masalahnya dengan tenang.',
          moodScore: 2,
          color: 0xFFFFB6C1,
        );
      case 'Sedih':
        return EmotionRecommendation(
          emoji: '😢',
          title: 'Terlihat Sedih',
          description: 'Kamu mungkin sedang mengalami suasana hati yang turun.',
          recommendation:
              'Coba berbicara dengan seseorang yang dekat, atau lakukan aktivitas yang membuat bahagia.',
          moodScore: 1,
          color: 0xFF6495ED,
        );
      default:
        return EmotionRecommendation(
          emoji: '😐',
          title: 'Cek Emosi',
          description: 'Suasana hati kamu tidak terdeteksi dengan jelas.',
          recommendation: 'Coba ambil foto yang lebih jelas.',
          moodScore: 0,
          color: 0xFFA9A9A9,
        );
    }
  }

  void dispose() {
    // Dispose disabled - camera feature removed
  }
}

class DetectedFace {
  final dynamic face;
  final String emotion;
  final double confidence;

  DetectedFace({
    required this.face,
    required this.emotion,
    required this.confidence,
  });
}

class EmotionRecommendation {
  final String emoji;
  final String title;
  final String description;
  final String recommendation;
  final int moodScore;
  final int color;

  EmotionRecommendation({
    required this.emoji,
    required this.title,
    required this.description,
    required this.recommendation,
    required this.moodScore,
    required this.color,
  });
}
