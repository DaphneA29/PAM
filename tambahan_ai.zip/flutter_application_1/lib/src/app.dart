import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../features/pages/home_page.dart';
import '../features/pages/settings_page.dart';
import '../features/pages/history_page.dart';
import '../features/pages/login_page.dart'; // Login enabled
import '../features/pages/profile_page.dart';
import '../features/pages/health_insights_page.dart';
import '../features/providers.dart';

import '../features/pages/main_scaffold.dart';

class InsightMindApp extends ConsumerWidget {
  const InsightMindApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeProvider);
    final themeColor = ref.watch(themeColorProvider);
    final currentUser = ref.watch(currentUserProvider);

    // Cek apakah user sudah login
    String initialRoute = currentUser != null ? '/' : '/login';

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'InsightMind',
      theme: ThemeData(
        brightness: Brightness.light,
        primaryColor: themeColor,
        useMaterial3: true,
        fontFamily:
            'GoogleFonts.poppins().fontFamily', // Will fix font later if needed
        colorScheme: ColorScheme.fromSeed(
          seedColor: themeColor,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F8FB),
        appBarTheme: AppBarTheme(
          backgroundColor: themeColor,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: themeColor,
            foregroundColor: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          color: Colors.white,
        ),
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: themeColor,
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: themeColor,
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF121212),
        appBarTheme: AppBarTheme(
          backgroundColor: themeColor,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
      themeMode: themeMode,
      initialRoute: initialRoute,
      routes: {
        '/': (ctx) => const MainScaffold(),
        '/login': (ctx) => const LoginPage(),
        '/settings': (ctx) => const SettingsPage(),
        '/history': (ctx) => const HistoryPage(),
        '/profile': (ctx) => const ProfilePage(),
        '/health-insights': (ctx) => const HealthInsightsPage(),
      },
    );
  }
}
