import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:insightmind_v2/features/insightmind/presentation/providers/ai_provider.dart';// <--- PASTIKAN IMPORT INI BENAR
import 'dart:math' as math; // <--- tambahin ini bro biar 'math' nggak merah lagi

class AiChatPage extends ConsumerStatefulWidget {
  const AiChatPage({super.key});

  @override
  ConsumerState<AiChatPage> createState() => _AiChatPageState();
}

class _AiChatPageState extends ConsumerState<AiChatPage> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  
  // warna spesial buat insightmind ai
  final Color aiPrimary = const Color(0xFF6C63FF); 
  final Color aiBg = const Color(0xFF1A1A2E);      
  final Color aiBubbleUser = const Color(0xFF4E4EBA);
  final Color aiBubbleBot = const Color(0xFF2E2E48);

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // INI FUNGSI YANG BIKIN MERAH TADI, JANGAN SAMPAI KETINGGALAN COPAS
  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _sendChat() async {
    final msg = _controller.text.trim();
    if (msg.isEmpty) return;

    _controller.clear();
    // tambah pesan user
    ref.read(chatMessagesProvider.notifier).addMessage('user', msg);
    _scrollToBottom();

    // aktifkan loading
    ref.read(aiLoadingProvider.notifier).state = true;
    _scrollToBottom();

    // panggil gemini 2.5 flash
    final response = await ref.read(aiServiceProvider).sendMessage(msg);

    // matikan loading
    ref.read(aiLoadingProvider.notifier).state = false;
    ref.read(chatMessagesProvider.notifier).addMessage('ai', response);
    _scrollToBottom();
  }

  @override
  Widget build(BuildContext context) {
    final messages = ref.watch(chatMessagesProvider);
    final isLoading = ref.watch(aiLoadingProvider);

    return Scaffold(
      backgroundColor: aiBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('InsightMind AI', style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
              itemCount: messages.length + (isLoading ? 1 : 0),
              itemBuilder: (context, index) {
                if (isLoading && index == messages.length) {
                  return _ThinkingIndicator(color: aiPrimary);
                }
                final message = messages[index];
                return _ChatBubble(
                  text: message['text']!,
                  isUser: message['role'] == 'user',
                  userColor: aiBubbleUser,
                  botColor: aiBubbleBot,
                );
              },
            ),
          ),
          _buildInputArea(),
        ],
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Color(0xFF16213E),
        borderRadius: BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30)),
      ),
      child: SafeArea(
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _controller,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Curhat di sini...',
                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.5)),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.1),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: BorderSide.none),
                ),
              ),
            ),
            const SizedBox(width: 10),
            CircleAvatar(
              backgroundColor: aiPrimary,
              child: IconButton(icon: const Icon(Icons.send, color: Colors.white), onPressed: _sendChat),
            ),
          ],
        ),
      ),
    );
  }
}

// sertakan widget _ChatBubble dan _ThinkingIndicator dari kode sebelumnya di sini...
// --- WIDGET BUBBLE CHAT ---
class _ChatBubble extends StatelessWidget {
  final String text;
  final bool isUser;
  final Color userColor;
  final Color botColor;

  const _ChatBubble({
    required this.text,
    required this.isUser,
    required this.userColor,
    required this.botColor,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.75,
        ),
        decoration: BoxDecoration(
          color: isUser ? userColor : botColor,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
            bottomLeft: Radius.circular(isUser ? 20 : 0),
            bottomRight: Radius.circular(isUser ? 0 : 20),
          ),
        ),
        child: Text(
          text,
          style: const TextStyle(
            color: Colors.white, 
            fontSize: 15, 
            height: 1.4,
          ),
        ),
      ),
    );
  }
}

// --- WIDGET TYPING/THINKING INDICATOR ---
class _ThinkingIndicator extends StatefulWidget {
  final Color color;
  const _ThinkingIndicator({required this.color});

  @override
  State<_ThinkingIndicator> createState() => _ThinkingIndicatorState();
}

class _ThinkingIndicatorState extends State<_ThinkingIndicator> with TickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this, 
      duration: const Duration(milliseconds: 1200)
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: List.generate(3, (index) {
          return FadeTransition(
            opacity: _DelayTween(begin: 0.3, end: 1.0, delay: index * 0.2)
                .animate(_controller),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 2),
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: widget.color.withOpacity(0.7), 
                shape: BoxShape.circle
              ),
            ),
          );
        }),
      ),
    );
  }
}

// Helper class untuk animasi titik-titik
class _DelayTween extends Tween<double> {
  _DelayTween({super.begin, super.end, required this.delay});

  final double delay;

  @override
  double lerp(double t) {
    return super.lerp((math.sin((t - delay) * 2 * math.pi) + 1) / 2);
  }
}