import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../models/health_metric.dart';
import '../providers.dart';

class QuizPage extends ConsumerStatefulWidget {
  const QuizPage({super.key});

  @override
  ConsumerState<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends ConsumerState<QuizPage> {
  int currentQuestionIndex = 0;
  List<int> answers = [];

  final List<Map<String, dynamic>> questions = [
    {
      'question':
          'Dalam 2 minggu terakhir, seberapa sering Anda merasa sedih atau tertekan?',
      'options': [
        'Tidak pernah',
        'Beberapa hari',
        'Lebih dari setengah hari',
        'Hampir setiap hari'
      ],
      'scores': [0, 1, 2, 3]
    },
    {
      'question':
          'Dalam 2 minggu terakhir, seberapa sering Anda merasa tidak bersemangat atau tidak tertarik pada hal-hal?',
      'options': [
        'Tidak pernah',
        'Beberapa hari',
        'Lebih dari setengah hari',
        'Hampir setiap hari'
      ],
      'scores': [0, 1, 2, 3]
    },
    {
      'question':
          'Dalam 2 minggu terakhir, seberapa sering Anda merasa lelah atau kehilangan energi?',
      'options': [
        'Tidak pernah',
        'Beberapa hari',
        'Lebih dari setengah hari',
        'Hampir setiap hari'
      ],
      'scores': [0, 1, 2, 3]
    },
    {
      'question':
          'Dalam 2 minggu terakhir, seberapa sering Anda merasa tidak berharga atau bersalah?',
      'options': [
        'Tidak pernah',
        'Beberapa hari',
        'Lebih dari setengah hari',
        'Hampir setiap hari'
      ],
      'scores': [0, 1, 2, 3]
    },
    {
      'question':
          'Dalam 2 minggu terakhir, seberapa sering Anda merasa sulit berkonsentrasi?',
      'options': [
        'Tidak pernah',
        'Beberapa hari',
        'Lebih dari setengah hari',
        'Hampir setiap hari'
      ],
      'scores': [0, 1, 2, 3]
    },
    {
      'question':
          'Dalam 2 minggu terakhir, seberapa sering Anda merasa gelisah atau lamban?',
      'options': [
        'Tidak pernah',
        'Beberapa hari',
        'Lebih dari setengah hari',
        'Hampir setiap hari'
      ],
      'scores': [0, 1, 2, 3]
    },
    {
      'question':
          'Dalam 2 minggu terakhir, seberapa sering Anda mengalami masalah tidur?',
      'options': [
        'Tidak pernah',
        'Beberapa hari',
        'Lebih dari setengah hari',
        'Hampir setiap hari'
      ],
      'scores': [0, 1, 2, 3]
    },
    {
      'question':
          'Dalam 2 minggu terakhir, seberapa sering Anda memiliki pikiran tentang menyakiti diri sendiri?',
      'options': [
        'Tidak pernah',
        'Beberapa hari',
        'Lebih dari setengah hari',
        'Hampir setiap hari'
      ],
      'scores': [0, 1, 2, 3]
    }
  ];

  @override
  Widget build(BuildContext context) {
    final themeColor = ref.watch(themeColorProvider);
    final currentUser = ref.watch(currentUserProvider);

    if (currentQuestionIndex >= questions.length) {
      // Calculate results
      int totalScore = answers.reduce((a, b) => a + b);
      String riskLevel;
      String recommendation;

      if (totalScore <= 4) {
        riskLevel = 'Rendah';
        recommendation =
            'Kondisi mental Anda dalam kondisi baik. Tetap jaga kesehatan mental dengan istirahat yang cukup dan aktivitas positif.';
      } else if (totalScore <= 9) {
        riskLevel = 'Ringan';
        recommendation =
            'Anda menunjukkan gejala ringan. Disarankan untuk berbicara dengan orang terdekat dan menjaga pola hidup sehat.';
      } else if (totalScore <= 14) {
        riskLevel = 'Sedang';
        recommendation =
            'Anda menunjukkan gejala sedang. Disarankan untuk berkonsultasi dengan profesional kesehatan mental.';
      } else {
        riskLevel = 'Berat';
        recommendation =
            'Anda menunjukkan gejala berat. Sangat disarankan untuk segera berkonsultasi dengan profesional kesehatan mental.';
      }

      // Save result
      if (currentUser != null) {
        final healthMetric = HealthMetric(
          id: const Uuid().v4(),
          userId: currentUser.id,
          type: 'mental_health',
          value: totalScore.toDouble(),
          notes: 'Screening mental health - Risk level: $riskLevel',
          recordedAt: DateTime.now(),
        );

        ref.read(healthMetricsProvider.notifier).addMetric(healthMetric);
      }

      // Show results
      return Scaffold(
        appBar: AppBar(
          title: Text('Hasil Screening'),
          backgroundColor: themeColor,
        ),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Icon(
                riskLevel == 'Rendah'
                    ? Icons.sentiment_very_satisfied
                    : riskLevel == 'Ringan'
                        ? Icons.sentiment_satisfied
                        : riskLevel == 'Sedang'
                            ? Icons.sentiment_neutral
                            : Icons.sentiment_very_dissatisfied,
                size: 80,
                color: themeColor,
              ),
              const SizedBox(height: 20),
              Text(
                'Tingkat Risiko: $riskLevel',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: themeColor,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              Text(
                'Skor: $totalScore dari ${questions.length * 3}',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              Text(
                recommendation,
                style: const TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  minimumSize: const Size(double.infinity, 50),
                ),
                child: const Text('Kembali ke Beranda'),
              ),
            ],
          ),
        ),
      );
    }

    final currentQuestion = questions[currentQuestionIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text('Screening Mental Health'),
        backgroundColor: themeColor,
      ),
      body: Column(
        children: [
          LinearProgressIndicator(
            value: (currentQuestionIndex + 1) / questions.length,
            backgroundColor: themeColor.withOpacity(0.2),
            valueColor: AlwaysStoppedAnimation<Color>(themeColor),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Pertanyaan ${currentQuestionIndex + 1} dari ${questions.length}',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    currentQuestion['question'],
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 30),
                  ...List.generate(
                    currentQuestion['options'].length,
                    (index) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            answers.add(currentQuestion['scores'][index]);
                            currentQuestionIndex++;
                          });
                        },
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            border:
                                Border.all(color: themeColor.withOpacity(0.3)),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            currentQuestion['options'][index],
                            style: const TextStyle(fontSize: 16),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
