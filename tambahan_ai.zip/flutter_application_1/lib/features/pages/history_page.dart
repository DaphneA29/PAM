// ignore_for_file: sort_child_properties_last

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
// Removed calendar — history is based only on screening entries
// services are available via material import
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'history_detail_page.dart';

import '../models/history_entry.dart';
import '../models/health_metric.dart';
import '../providers.dart';

class HistoryPage extends ConsumerStatefulWidget {
  // Optional testEntries is used only in tests to bypass provider/Hive and
  // render a deterministic list.
  final List<HistoryEntry>? testEntries;

  const HistoryPage({super.key, this.testEntries});

  @override
  ConsumerState<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends ConsumerState<HistoryPage> {
  String _search = '';
  final GlobalKey<AnimatedListState> _listKey = GlobalKey<AnimatedListState>();
  List<HistoryEntry> _displayed = [];
  bool _listeningInitialized = false;

  @override
  void initState() {
    super.initState();
  }

  void _onHistoryChanged(List<HistoryEntry>? prev, List<HistoryEntry>? next) {
    final prevFiltered = _applyFilter(prev ?? []);
    final nextFiltered = _applyFilter(next ?? []);

    // removals: items present in prevFiltered but not in nextFiltered
    final prevIds = prevFiltered.map((e) => e.id).toSet();
    final nextIds = nextFiltered.map((e) => e.id).toSet();

    final removed = prevFiltered.where((e) => !nextIds.contains(e.id)).toList();
    for (final r in removed) {
      final idx = _displayed.indexWhere((el) => el.id == r.id);
      if (idx >= 0) {
        final removedItem = _displayed.removeAt(idx);
        _listKey.currentState?.removeItem(
          idx,
          (context, animation) => SizeTransition(
            sizeFactor: animation,
            axis: Axis.horizontal,
            child: SizedBox(
              width: 320,
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Text(removedItem.title),
                ),
              ),
            ),
          ),
          duration: const Duration(milliseconds: 300),
        );
      }
    }

    // insertions: items present in nextFiltered but not in prevFiltered
    final added = nextFiltered.where((e) => !prevIds.contains(e.id)).toList();
    for (final a in added) {
      final insertIndex = nextFiltered.indexWhere((el) => el.id == a.id);
      _displayed.insert(insertIndex, a);
      _listKey.currentState?.insertItem(insertIndex,
          duration: const Duration(milliseconds: 300));
    }
  }

  @override
  Widget build(BuildContext context) {
    // Initialize provider listener during build phase to satisfy Riverpod's
    // requirement that ref.listen is called while building.
    if (widget.testEntries == null && !_listeningInitialized) {
      _listeningInitialized = true;
      ref.listen<List<HistoryEntry>>(historyProvider, (previous, next) {
        _onHistoryChanged(previous, next);
      });
    }

    // Watch both screening history and health metrics
    final entries = widget.testEntries != null
        ? List<HistoryEntry>.from(widget.testEntries!)
        : ref.watch(historyProvider);
    final healthMetrics = ref.watch(healthMetricsProvider);
    final themeColor = ref.watch(themeColorProvider);

    final filtered = _applyFilter(entries);

    // Ensure displayed list initialized on first build
    if (_displayed.isEmpty && filtered.isNotEmpty) {
      _displayed = List.from(filtered);
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('📊 Riwayat'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'Cari riwayat...',
                border: OutlineInputBorder(),
              ),
              onChanged: (v) => setState(() => _search = v.trim()),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Screening History Section
                  if (filtered.isNotEmpty) ...[
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: const Text(
                        'Riwayat Screening',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 260,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: filtered.length,
                        itemBuilder: (context, idx) {
                          final e = filtered[idx];
                          return Padding(
                            padding: const EdgeInsets.only(
                              left: 16,
                              right: 8,
                              bottom: 16,
                            ),
                            child: SizedBox(
                              width: 300,
                              child: Card(
                                elevation: 2,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: InkWell(
                                  onTap: () => _openDetail(e),
                                  child: Padding(
                                    padding: const EdgeInsets.all(16),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Expanded(
                                              child: Text(
                                                e.title,
                                                style: const TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 14,
                                                ),
                                              ),
                                            ),
                                            Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                horizontal: 8,
                                                vertical: 4,
                                              ),
                                              decoration: BoxDecoration(
                                                color:
                                                    themeColor.withOpacity(0.2),
                                                borderRadius:
                                                    BorderRadius.circular(8),
                                              ),
                                              child: Text(
                                                '${e.score}%',
                                                style: TextStyle(
                                                  color: themeColor,
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 8),
                                        Text(
                                          e.date
                                              .toLocal()
                                              .toString()
                                              .split(' ')[0],
                                          style: const TextStyle(
                                            color: Colors.black54,
                                            fontSize: 12,
                                          ),
                                        ),
                                        const SizedBox(height: 12),
                                        Expanded(
                                          child: Text(
                                            e.notes,
                                            maxLines: 4,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              fontSize: 13,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],

                  // Health Metrics Section
                  if (healthMetrics.isNotEmpty) ...[
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: const Text(
                        'Riwayat Health Tracking',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: healthMetrics.length,
                      itemBuilder: (context, index) {
                        final metric = healthMetrics[index];
                        return _HealthMetricCard(
                          metric: metric,
                          themeColor: themeColor,
                        );
                      },
                    ),
                  ],

                  // Empty State
                  if (filtered.isEmpty && healthMetrics.isEmpty)
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 40),
                        child: Column(
                          children: [
                            Icon(
                              Icons.history,
                              size: 60,
                              color: Colors.grey[300],
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'Belum ada riwayat',
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<HistoryEntry> _applyFilter(List<HistoryEntry> entries) {
    var list = entries;
    if (_search.isNotEmpty) {
      final q = _search.toLowerCase();
      list = list
          .where((e) =>
              e.title.toLowerCase().contains(q) ||
              e.notes.toLowerCase().contains(q))
          .toList();
    }
    // sort descending by date (most recent first)
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }

  void _openDetail(HistoryEntry e) {
    // If testEntries is set we are in test-mode and need to pass an onDelete
    // callback that operates on the local _displayed list so deletion works
    // without a ProviderScope/Hive setup.
    if (widget.testEntries != null) {
      Navigator.of(context).push(MaterialPageRoute(
        builder: (c) => HistoryDetailPage(
          entry: e,
          onDelete: () async {
            final idx = _displayed.indexWhere((el) => el.id == e.id);
            if (idx >= 0) {
              // Update state so the simplified ListView (used in tests)
              // reflects the removal.
              setState(() {
                _displayed.removeAt(idx);
              });
            }
          },
        ),
      ));
      return;
    }

    Navigator.of(context).push(MaterialPageRoute(
      builder: (c) => HistoryDetailPage(entry: e),
    ));
  }
}

class _HealthMetricCard extends StatelessWidget {
  final HealthMetric metric;
  final Color themeColor;

  const _HealthMetricCard({
    required this.metric,
    required this.themeColor,
  });

  String _getMetricIcon() {
    switch (metric.type) {
      case 'mood':
        return '😊';
      case 'sleep':
        return '😴';
      case 'hydration':
        return '💧';
      case 'exercise':
        return '🏃';
      default:
        return '📊';
    }
  }

  String _getMetricLabel() {
    switch (metric.type) {
      case 'mood':
        return 'Mood Tracking';
      case 'sleep':
        return 'Sleep Tracker';
      case 'hydration':
        return 'Hydration Tracker';
      case 'exercise':
        return 'Exercise Tracker';
      default:
        return 'Health Metric';
    }
  }

  String _getMetricValue() {
    switch (metric.type) {
      case 'mood':
        final moods = [
          'Sangat Sedih',
          'Sedih',
          'Netral',
          'Senang',
          'Sangat Senang'
        ];
        int index = metric.value.toInt() - 1;
        return moods[index < 0 || index >= moods.length ? 2 : index];
      case 'sleep':
        return '${metric.value.toStringAsFixed(1)} jam';
      case 'hydration':
        return '${metric.value.toStringAsFixed(2)} L';
      case 'exercise':
        return '${metric.value.toStringAsFixed(0)} menit';
      default:
        return metric.value.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Card(
        elevation: 1,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Text(_getMetricIcon(), style: const TextStyle(fontSize: 28)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _getMetricLabel(),
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      metric.recordedAt.toString().split('.')[0],
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 12,
                      ),
                    ),
                    if (metric.notes != null && metric.notes!.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                          metric.notes!,
                          style: TextStyle(
                            color: Colors.grey[700],
                            fontSize: 11,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: themeColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _getMetricValue(),
                  style: TextStyle(
                    color: themeColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
