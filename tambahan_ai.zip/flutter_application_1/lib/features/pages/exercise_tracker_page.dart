import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../models/health_metric.dart';
import '../providers.dart';
import '../../services/ai_service.dart';

class ExerciseTrackerPage extends ConsumerStatefulWidget {
  const ExerciseTrackerPage({super.key});

  @override
  ConsumerState<ExerciseTrackerPage> createState() =>
      _ExerciseTrackerPageState();
}

class _ExerciseTrackerPageState extends ConsumerState<ExerciseTrackerPage> {
  String _selectedType = 'Lari';
  double _duration = 30;
  int _intensity = 2;
  String _aiResponse = '';

  final List<String> _exerciseTypes = [
    'Lari',
    'Berjalan',
    'Bersepeda',
    'Berenang',
    'Yoga',
    'Gym',
    'Olahraga Bola',
    'Lainnya',
  ];

  Future<void> _generateAIResponse() async {
    final ai = AiService();
    final response = await ai.sendMessage(
        'Buatkan catatan singkat dan saran latihan untuk jenis $_selectedType, durasi ${_duration.toStringAsFixed(0)} menit, intensitas $_intensity.');
    if (!mounted) return;
    setState(() => _aiResponse = response);
  }

  Future<void> _saveExercise() async {
    if (_duration <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Masukkan durasi olahraga')),
      );
      return;
    }

    final user = ref.read(authProvider);
    if (user == null) return;

    final metric = HealthMetric(
      id: const Uuid().v4(),
      userId: user.id,
      type: 'exercise',
      value: _duration,
      notes: '$_selectedType - Intensitas: $_intensity/3',
      recordedAt: DateTime.now(),
    );

    await ref.read(healthMetricsProvider.notifier).addMetric(metric);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Olahraga berhasil dicatat!')),
    );

    setState(() {
      _duration = 30;
      _intensity = 2;
      _aiResponse = '';
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = ref.watch(themeColorProvider);
    final healthMetrics = ref.watch(healthMetricsProvider);
    final today = DateTime.now();

    final todayExercises = healthMetrics
        .where((m) =>
            m.type == 'exercise' &&
            m.recordedAt.year == today.year &&
            m.recordedAt.month == today.month &&
            m.recordedAt.day == today.day)
        .toList();

    final totalDuration =
        todayExercises.fold<double>(0, (sum, m) => sum + m.value);

    return Scaffold(
      appBar: AppBar(
        title: const Text('🏃 Exercise Tracker'),
        backgroundColor: themeColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Summary Section
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.green.withOpacity(0.7), Colors.teal],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Total Olahraga Hari Ini',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${totalDuration.toStringAsFixed(0)} Menit',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Target: 30 menit/hari',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: (totalDuration / 30).clamp(0.0, 1.0),
                    minHeight: 6,
                    backgroundColor: Colors.white30,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Exercise Type Selection
            const Text(
              'Jenis Olahraga',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: DropdownButton<String>(
                value: _selectedType,
                isExpanded: true,
                underline: const SizedBox(),
                items: _exerciseTypes.map((type) {
                  return DropdownMenuItem(
                    value: type,
                    child: Text(type),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() => _selectedType = value);
                  }
                },
              ),
            ),
            const SizedBox(height: 24),

            // Duration Input
            const Text(
              'Durasi (Menit)',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(
                      '${_duration.toStringAsFixed(0)} Menit',
                      style: const TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Slider(
                      value: _duration,
                      min: 5,
                      max: 180,
                      divisions: 35,
                      label: '${_duration.toStringAsFixed(0)} min',
                      onChanged: (value) {
                        setState(() => _duration = value);
                      },
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _DurationButton(
                          label: '15m',
                          onTap: () => setState(() => _duration = 15),
                        ),
                        _DurationButton(
                          label: '30m',
                          onTap: () => setState(() => _duration = 30),
                        ),
                        _DurationButton(
                          label: '45m',
                          onTap: () => setState(() => _duration = 45),
                        ),
                        _DurationButton(
                          label: '60m',
                          onTap: () => setState(() => _duration = 60),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Intensity Selection
            const Text(
              'Intensitas',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  RadioListTile<int>(
                    title: const Text('Ringan'),
                    subtitle: const Text('Santai, bisa mengobrol'),
                    value: 1,
                    groupValue: _intensity,
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => _intensity = value);
                      }
                    },
                  ),
                  const Divider(height: 0),
                  RadioListTile<int>(
                    title: const Text('Sedang'),
                    subtitle: const Text('Agak capai, napas lebih cepat'),
                    value: 2,
                    groupValue: _intensity,
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => _intensity = value);
                      }
                    },
                  ),
                  const Divider(height: 0),
                  RadioListTile<int>(
                    title: const Text('Tinggi'),
                    subtitle: const Text('Capai, napas cepat'),
                    value: 3,
                    groupValue: _intensity,
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => _intensity = value);
                      }
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // AI Response
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                icon: const Icon(Icons.lightbulb),
                label: const Text('Lihat AI Insight'),
                onPressed: _generateAIResponse,
              ),
            ),
            const SizedBox(height: 12),
            if (_aiResponse.isNotEmpty)
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                color: Colors.green.withOpacity(0.05),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '🤖 AI Insight',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _aiResponse,
                        style: const TextStyle(
                          fontSize: 13,
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 24),

            // Save Button
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                icon: const Icon(Icons.save),
                label: const Text('Simpan Olahraga'),
                onPressed: _saveExercise,
              ),
            ),
            const SizedBox(height: 24),

            // Today's History
            const Text(
              'Riwayat Hari Ini',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            if (todayExercises.isEmpty)
              Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Text(
                    'Belum ada catatan olahraga hari ini',
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: todayExercises.length,
                itemBuilder: (ctx, idx) {
                  final metric = todayExercises[idx];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      leading:
                          const Icon(Icons.fitness_center, color: Colors.green),
                      title: Text('${metric.value.toStringAsFixed(0)} Menit'),
                      subtitle: Text(metric.notes ?? 'Exercise'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          ref
                              .read(healthMetricsProvider.notifier)
                              .deleteMetric(metric.id);
                        },
                      ),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _DurationButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _DurationButton({
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.green.withOpacity(0.1),
          border: Border.all(color: Colors.green.withOpacity(0.3)),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.bold,
            color: Colors.green,
          ),
        ),
      ),
    );
  }
}
