import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../models/health_metric.dart';
import '../providers.dart';
import '../../services/ai_service.dart';

class HydrationTrackerPage extends ConsumerStatefulWidget {
  const HydrationTrackerPage({super.key});

  @override
  ConsumerState<HydrationTrackerPage> createState() =>
      _HydrationTrackerPageState();
}

class _HydrationTrackerPageState extends ConsumerState<HydrationTrackerPage> {
  double _waterIntake = 0.0;
  String _aiResponse = '';
  late TextEditingController _customAmountCtrl;

  @override
  void initState() {
    super.initState();
    _customAmountCtrl = TextEditingController();
    _loadTodayData();
  }

  void _loadTodayData() {
    final metrics = ref.read(healthMetricsProvider);
    final today = DateTime.now();
    final todayMetrics = metrics
        .where((m) =>
            m.type == 'hydration' &&
            m.recordedAt.year == today.year &&
            m.recordedAt.month == today.month &&
            m.recordedAt.day == today.day)
        .toList();

    double total = 0;
    for (var metric in todayMetrics) {
      total += metric.value;
    }
    setState(() => _waterIntake = total);
  }

  void _addWater(double liters) {
    setState(() => _waterIntake += liters);
    _generateAIResponse();
  }

  Future<void> _generateAIResponse() async {
    final ai = AiService();
    final response = await ai.sendMessage(
        'Buatkan ringkasan singkat dan saran hidrasi untuk asupan hari ini: ${_waterIntake.toStringAsFixed(2)} L.');
    if (!mounted) return;
    setState(() => _aiResponse = response);
  }

  Future<void> _saveWater() async {
    if (_waterIntake <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Masukkan jumlah air yang diminum')),
      );
      return;
    }

    final user = ref.read(authProvider);
    if (user == null) return;

    final metric = HealthMetric(
      id: const Uuid().v4(),
      userId: user.id,
      type: 'hydration',
      value: _waterIntake,
      notes: 'Intake air hari ini',
      recordedAt: DateTime.now(),
    );

    await ref.read(healthMetricsProvider.notifier).addMetric(metric);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Catat asupan air berhasil disimpan!')),
    );

    _generateAIResponse();
  }

  @override
  void dispose() {
    _customAmountCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = ref.watch(themeColorProvider);
    final healthMetrics = ref.watch(healthMetricsProvider);
    final today = DateTime.now();

    final todayData = healthMetrics
        .where((m) =>
            m.type == 'hydration' &&
            m.recordedAt.year == today.year &&
            m.recordedAt.month == today.month &&
            m.recordedAt.day == today.day)
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('💧 Hydration Tracker'),
        backgroundColor: themeColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Progress Section
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue.withOpacity(0.7), Colors.cyan],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Target Harian: 2-3 Liter',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        '${_waterIntake.toStringAsFixed(1)}L',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: LinearProgressIndicator(
                          value: (_waterIntake / 3).clamp(0.0, 1.0),
                          minHeight: 8,
                          backgroundColor: Colors.white30,
                          valueColor:
                              AlwaysStoppedAnimation<Color>(Colors.white),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _waterIntake >= 2 && _waterIntake <= 3
                        ? '✅ Target tercapai!'
                        : _waterIntake < 2
                            ? '${(2 - _waterIntake).toStringAsFixed(1)}L lagi untuk mencapai target'
                            : '✨ Sudah melebihi target!',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Quick Add Section
            const Text(
              'Tambah Air Cepat',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 4,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _QuickAddButton(
                  label: '250ml',
                  value: 0.25,
                  onTap: () => _addWater(0.25),
                ),
                _QuickAddButton(
                  label: '500ml',
                  value: 0.5,
                  onTap: () => _addWater(0.5),
                ),
                _QuickAddButton(
                  label: '750ml',
                  value: 0.75,
                  onTap: () => _addWater(0.75),
                ),
                _QuickAddButton(
                  label: '1L',
                  value: 1.0,
                  onTap: () => _addWater(1.0),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Custom Amount
            const Text(
              'Jumlah Custom',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _customAmountCtrl,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Masukkan liter (cth: 0.5)',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      suffixText: 'L',
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: themeColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 16,
                    ),
                  ),
                  onPressed: () {
                    final value = double.tryParse(_customAmountCtrl.text) ?? 0;
                    if (value > 0) {
                      _addWater(value);
                      _customAmountCtrl.clear();
                    }
                  },
                  child: const Text('Tambah'),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // AI Response
            if (_aiResponse.isNotEmpty)
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                color: Colors.blue.withOpacity(0.05),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '🤖 AI Insight',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _aiResponse,
                        style: const TextStyle(
                          fontSize: 13,
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 24),

            // Save Button
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                icon: const Icon(Icons.save),
                label: const Text('Simpan Catat Air'),
                onPressed: _saveWater,
              ),
            ),
            const SizedBox(height: 24),

            // Today's History
            const Text(
              'Riwayat Hari Ini',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            if (todayData.isEmpty)
              Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Text(
                    'Belum ada catatan air hari ini',
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: todayData.length,
                itemBuilder: (ctx, idx) {
                  final metric = todayData[idx];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      leading: const Icon(Icons.water_drop, color: Colors.blue),
                      title: Text('${metric.value.toStringAsFixed(2)}L'),
                      subtitle: Text(
                        '${metric.recordedAt.hour}:${metric.recordedAt.minute.toString().padLeft(2, '0')}',
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          ref
                              .read(healthMetricsProvider.notifier)
                              .deleteMetric(metric.id);
                          _loadTodayData();
                        },
                      ),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _QuickAddButton extends StatelessWidget {
  final String label;
  final double value;
  final VoidCallback onTap;

  const _QuickAddButton({
    required this.label,
    required this.value,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.blue.withOpacity(0.1),
          border: Border.all(color: Colors.blue.withOpacity(0.3)),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.water_drop, color: Colors.blue, size: 24),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
