import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pedometer/pedometer.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:uuid/uuid.dart';
import 'dart:async';
import '../models/health_metric.dart';
import '../providers.dart';
import '../../services/ai_service.dart';

class ExerciseTrackerPageSmartWatch extends ConsumerStatefulWidget {
  const ExerciseTrackerPageSmartWatch({super.key});

  @override
  ConsumerState<ExerciseTrackerPageSmartWatch> createState() =>
      _ExerciseTrackerPageSmartWatchState();
}

class _ExerciseTrackerPageSmartWatchState
    extends ConsumerState<ExerciseTrackerPageSmartWatch> {
  late Stream<StepCount> _stepCountStream;
  late Stream<dynamic> _pedestrianStatusStream;
  String _status = '🚶';
  int _sessionSteps = 0;
  bool _isTracking = false;
  late DateTime _startTime;
  Duration _elapsedTime = Duration.zero;
  late Timer _timer;
  double _calories = 0;
  String _aiResponse = '';

  final int dailyGoal = 8000;

  @override
  void initState() {
    super.initState();
    _initPedometer();
    _startTime = DateTime.now();
  }

  void _initPedometer() {
    _stepCountStream = Pedometer.stepCountStream;
    _pedestrianStatusStream = Pedometer.pedestrianStatusStream;

    _stepCountStream.listen(
      (StepCount event) {
        if (_isTracking) {
          setState(() {
            _sessionSteps = event.steps;
            _calculateCalories();
            _generateAIResponse();
          });
        }
      },
      onError: (error) {
        debugPrint("Step Count error: $error");
        _showErrorMessage('Pedometer tidak tersedia');
      },
    );

    _pedestrianStatusStream.listen(
      (dynamic event) {
        setState(() {
          _status = '🚶 Berjalan';
        });
      },
      onError: (error) {
        debugPrint("Pedestrian Status error: $error");
      },
    );
  }

  void _calculateCalories() {
    // Average: 0.04 calories per step for normal weight person
    _calories = _sessionSteps * 0.04;
  }

  Future<void> _generateAIResponse() async {
    final ai = AiService();
    final durationMinutes = _elapsedTime.inMinutes.toDouble();

    // Determine type from status string
    String type = 'olahraga';
    if (_status.toLowerCase().contains('berjalan') || _status.contains('🚶')) {
      type = 'walking';
    } else if (_status.toLowerCase().contains('berlari') ||
        _status.contains('🏃')) {
      type = 'running';
    }

    // Estimate intensity based on average pace (steps per minute)
    double pace = _elapsedTime.inMinutes > 0
        ? (_sessionSteps / _elapsedTime.inMinutes)
        : 0.0;
    int intensity = 1;
    if (pace > 100) {
      intensity = 3;
    } else if (pace > 60) {
      intensity = 2;
    }

    final response = await ai.sendMessage(
      'Buatkan catatan singkat dan saran latihan untuk jenis $type, durasi ${durationMinutes.toStringAsFixed(0)} menit, intensitas $intensity.');
    _aiResponse = response;
  }

  Future<void> _startTracking() async {
    await WakelockPlus.enable(); // Keep screen on during tracking
    setState(() {
      _isTracking = true;
      _startTime = DateTime.now();
      _sessionSteps = 0;
      _calories = 0;
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() {
        _elapsedTime = DateTime.now().difference(_startTime);
      });
    });

    _generateAIResponse();
  }

  Future<void> _stopTracking() async {
    await WakelockPlus.disable(); // Allow screen to turn off
    _timer.cancel();
    setState(() {
      _isTracking = false;
    });
  }

  Future<void> _saveSession() async {
    if (_sessionSteps <= 0) {
      _showErrorMessage('Tidak ada langkah yang tercatat');
      return;
    }

    final user = ref.read(authProvider);
    if (user == null) return;

    final metric = HealthMetric(
      id: const Uuid().v4(),
      userId: user.id,
      type: 'exercise',
      value: _sessionSteps.toDouble(),
      notes:
          'Langkah: $_sessionSteps | Kalori: ${_calories.toStringAsFixed(1)} | Durasi: ${_formatDuration(_elapsedTime)}',
      recordedAt: DateTime.now(),
    );

    await ref.read(healthMetricsProvider.notifier).addMetric(metric);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sesi olahraga berhasil disimpan!')),
      );
      Navigator.pop(context);
    }
  }

  String _formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    final seconds = duration.inSeconds.remainder(60);

    if (hours > 0) {
      return '$hours:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
    }
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  void _showErrorMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  void dispose() {
    if (_isTracking) {
      _stopTracking();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = ref.watch(themeColorProvider);
    final goalPercentage = (_sessionSteps / dailyGoal).clamp(0.0, 1.0);

    return Scaffold(
      appBar: AppBar(
        title: const Text('🏃 Exercise Tracker (Smartwatch Mode)'),
        backgroundColor: themeColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Big step counter display (smartwatch style)
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [themeColor.withOpacity(0.8), themeColor],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  Text(
                    _status,
                    style: const TextStyle(fontSize: 48),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    _sessionSteps.toString(),
                    style: const TextStyle(
                      fontSize: 72,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Langkah',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white70,
                    ),
                  ),
                  const SizedBox(height: 24),
                  // Progress circle
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 120,
                        height: 120,
                        child: CircularProgressIndicator(
                          value: goalPercentage,
                          strokeWidth: 8,
                          backgroundColor: Colors.white30,
                          valueColor: const AlwaysStoppedAnimation<Color>(
                            Colors.white,
                          ),
                        ),
                      ),
                      Column(
                        children: [
                          Text(
                            '${(goalPercentage * 100).toStringAsFixed(0)}%',
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${(dailyGoal - _sessionSteps).clamp(0, dailyGoal)} sisa',
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Stats grid
            GridView.count(
              crossAxisCount: 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _StatCard(
                  icon: Icons.local_fire_department,
                  label: 'Kalori',
                  value: _calories.toStringAsFixed(1),
                  unit: 'kcal',
                  color: Colors.red,
                ),
                _StatCard(
                  icon: Icons.schedule,
                  label: 'Durasi',
                  value: _formatDuration(_elapsedTime),
                  unit: '',
                  color: Colors.blue,
                ),
                _StatCard(
                  icon: Icons.speed,
                  label: 'Avg Pace',
                  value: (_elapsedTime.inMinutes > 0
                          ? (_sessionSteps / _elapsedTime.inMinutes)
                              .toStringAsFixed(1)
                          : '0.0')
                      .toString(),
                  unit: 'step/min',
                  color: Colors.green,
                ),
                _StatCard(
                  icon: Icons.location_on,
                  label: 'Target',
                  value: dailyGoal.toString(),
                  unit: 'langkah',
                  color: Colors.purple,
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Control buttons
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _isTracking ? Colors.red : themeColor,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    icon: Icon(_isTracking ? Icons.stop : Icons.play_arrow),
                    label: Text(_isTracking ? 'Hentikan' : 'Mulai'),
                    onPressed: _isTracking ? _stopTracking : _startTracking,
                  ),
                ),
                if (_isTracking) const SizedBox(width: 12),
                if (_isTracking)
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: themeColor,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      icon: const Icon(Icons.save),
                      label: const Text('Simpan'),
                      onPressed: _saveSession,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 24),

            // AI Response
            if (_aiResponse.isNotEmpty && _isTracking)
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                color: Colors.blue.withOpacity(0.05),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '🤖 AI Coaching',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _aiResponse,
                        style: const TextStyle(
                          fontSize: 13,
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 24),

            // Tips
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '💡 Tips Olahraga',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '• Target harian: $dailyGoal langkah\n'
                      '• Istirahat setiap 30 menit\n'
                      '• Minum air yang cukup\n'
                      '• Peregangan sebelum dan sesudah olahraga',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[700],
                        height: 1.6,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final String unit;
  final Color color;

  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.unit,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            colors: [color.withOpacity(0.1), color.withOpacity(0.05)],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 28),
              const SizedBox(height: 8),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 4),
              Text(
                unit,
                style: TextStyle(
                  fontSize: 10,
                  color: Colors.grey[600],
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
