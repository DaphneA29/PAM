import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../providers.dart';
import '../models/health_metric.dart';
import '../../services/ai_service.dart';

class SleepTrackerPage extends ConsumerStatefulWidget {
  const SleepTrackerPage({super.key});

  @override
  ConsumerState<SleepTrackerPage> createState() => _SleepTrackerPageState();
}

class _SleepTrackerPageState extends ConsumerState<SleepTrackerPage> {
  late TimeOfDay _bedTime;
  late TimeOfDay _wakeTime;
  int? _sleepQuality; // 1-5 scale
  String _aiResponse = '';

  @override
  void initState() {
    super.initState();
    _bedTime = TimeOfDay.now();
    _wakeTime = const TimeOfDay(hour: 7, minute: 0);
  }

  double _calculateSleepHours() {
    final bedMinutes = _bedTime.hour * 60 + _bedTime.minute;
    var wakeMinutes = _wakeTime.hour * 60 + _wakeTime.minute;

    if (wakeMinutes < bedMinutes) {
      wakeMinutes += 24 * 60; // Next day
    }

    return (wakeMinutes - bedMinutes) / 60.0;
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = ref.watch(themeColorProvider);
    final metrics = ref.watch(healthMetricsProvider);
    final todaySleep =
        metrics.where((m) => m.type == 'sleep').toList().reversed.toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Sleep Tracker'),
        backgroundColor: themeColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Catat Pola Tidur Anda',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Waktu Tidur',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 8),
                              InkWell(
                                onTap: () async {
                                  final picked = await showTimePicker(
                                    context: context,
                                    initialTime: _bedTime,
                                  );
                                  if (picked != null) {
                                    setState(() => _bedTime = picked);
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    border:
                                        Border.all(color: Colors.grey[300]!),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Row(
                                    children: [
                                      Icon(Icons.bedtime, color: themeColor),
                                      const SizedBox(width: 12),
                                      Text(
                                        _bedTime.format(context),
                                        style: const TextStyle(fontSize: 16),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Waktu Bangun',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 8),
                              InkWell(
                                onTap: () async {
                                  final picked = await showTimePicker(
                                    context: context,
                                    initialTime: _wakeTime,
                                  );
                                  if (picked != null) {
                                    setState(() => _wakeTime = picked);
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    border:
                                        Border.all(color: Colors.grey[300]!),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Row(
                                    children: [
                                      Icon(Icons.light_mode, color: themeColor),
                                      const SizedBox(width: 12),
                                      Text(
                                        _wakeTime.format(context),
                                        style: const TextStyle(fontSize: 16),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: themeColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.timer, color: themeColor, size: 28),
                          const SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Total Durasi Tidur',
                                style: TextStyle(fontSize: 14),
                              ),
                              Text(
                                '${_calculateSleepHours().toStringAsFixed(1)} jam',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: themeColor,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Kualitas Tidur',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Column(
              children: [
                for (int i = 1; i <= 5; i++)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: InkWell(
                      onTap: () => setState(() => _sleepQuality = i),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          vertical: 12,
                          horizontal: 16,
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: _sleepQuality == i
                                ? themeColor
                                : Colors.grey[300]!,
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(8),
                          color: _sleepQuality == i
                              ? themeColor.withOpacity(0.1)
                              : Colors.transparent,
                        ),
                        child: Row(
                          children: [
                            for (int j = 0; j < i; j++)
                              Padding(
                                padding: const EdgeInsets.only(right: 4),
                                child: Icon(Icons.star,
                                    color: themeColor, size: 20),
                              ),
                            const Spacer(),
                            Text(
                              i == 1
                                  ? 'Sangat Buruk'
                                  : i == 2
                                      ? 'Buruk'
                                      : i == 3
                                          ? 'Cukup'
                                          : i == 4
                                              ? 'Baik'
                                              : 'Sangat Baik',
                              style:
                                  const TextStyle(fontWeight: FontWeight.w500),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                icon: const Icon(Icons.save),
                label: const Text('Simpan Data Tidur'),
                onPressed: _sleepQuality == null
                    ? null
                    : () async {
                        final sleepHours = _calculateSleepHours();
                        final ai = AiService();
                        final response = await ai.sendMessage(
                            'Buatkan ringkasan singkat dan saran tidur berdasarkan durasi tidur ${sleepHours.toStringAsFixed(1)} jam dan kualitas tidur ${_sleepQuality!}.');

                        final metric = HealthMetric(
                          id: const Uuid().v4(),
                          userId: ref.read(authProvider)?.id ?? 'anonymous',
                          type: 'sleep',
                          value: sleepHours,
                          notes: 'Kualitas: ${[
                            '',
                            'Sangat Buruk',
                            'Buruk',
                            'Cukup',
                            'Baik',
                            'Sangat Baik'
                          ][_sleepQuality!]}',
                          recordedAt: DateTime.now(),
                        );
                        ref
                            .read(healthMetricsProvider.notifier)
                            .addMetric(metric);
                        setState(() {
                          _sleepQuality = null;
                          _aiResponse = response;
                        });
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text('Data tidur berhasil disimpan')),
                        );
                      },
              ),
            ),
            if (_aiResponse.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 24),
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  color: Colors.indigo.withOpacity(0.05),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '🤖 AI Insight',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.indigo,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _aiResponse,
                          style: const TextStyle(
                            fontSize: 13,
                            height: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 32),
            const Text(
              'Riwayat Hari Ini',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            if (todaySleep.isEmpty)
              Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 32),
                  child: Column(
                    children: [
                      Icon(Icons.nights_stay,
                          size: 60, color: Colors.grey[300]),
                      const SizedBox(height: 12),
                      Text(
                        'Belum ada data hari ini',
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                    ],
                  ),
                ),
              )
            else
              ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: todaySleep.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, index) {
                  final metric = todaySleep[index];
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        children: [
                          Icon(Icons.nights_stay, color: themeColor, size: 32),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${metric.value.toStringAsFixed(1)} jam tidur',
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  metric.notes ?? 'Tanpa catatan',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey[600],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}
