import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers.dart';
import 'package:insightmind_v2/src/features/insightmind/presentation/pages/ai_chat_page.dart';
import 'screening_page.dart';
import 'quiz_page.dart';
import 'sleep_tracker_page.dart';
import 'hydration_tracker_page.dart';
import 'exercise_tracker_page_smartwatch.dart';
import 'theme_customization_page.dart';
import 'mood_tracker_page.dart';

class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final themeColor = ref.watch(themeColorProvider);

    // Gunakan optimized providers
    final todayMoodCount = ref.watch(todayMoodCountProvider);
    final todayHydration = ref.watch(todayHydrationProvider);
    final todaySleep = ref.watch(todaySleepProvider);
    final todayExercise = ref.watch(todayExerciseProvider);

    if (user == null) {
      return const Center(
          child: Text('User not found - Silakan login terlebih dahulu'));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('InsightMind'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.palette_outlined),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const ThemeCustomizationPage()),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: themeColor.withOpacity(0.2),
                  child: Text(
                    user.name[0].toUpperCase(),
                    style: TextStyle(
                        color: themeColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 20),
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Halo, ${user.name}!',
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      'Semoga harimu menyenangkan',
                      style: TextStyle(color: Colors.grey[600], fontSize: 13),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 28),
            // Summary Stats Row
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _SummaryStatCard(
                    label: 'Mood',
                    value: '$todayMoodCount',
                    icon: Icons.sentiment_satisfied,
                    color: Colors.orange,
                  ),
                  _SummaryStatCard(
                    label: 'Air',
                    value: '${todayHydration.toStringAsFixed(1)}L',
                    icon: Icons.local_drink,
                    color: Colors.blue,
                  ),
                  _SummaryStatCard(
                    label: 'Tidur',
                    value: '${todaySleep.toStringAsFixed(1)}j',
                    icon: Icons.nights_stay,
                    color: Colors.indigo,
                  ),
                  _SummaryStatCard(
                    label: 'Olahraga',
                    value: '${todayExercise.toStringAsFixed(0)}m',
                    icon: Icons.fitness_center,
                    color: Colors.green,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),
            // Screening Banner
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [themeColor, themeColor.withOpacity(0.8)],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: themeColor.withOpacity(0.3),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Screening Mental Health',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Cek kondisi kesehatan mentalmu hari ini dengan kuis singkat.',
                    style: TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const QuizPage()),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: themeColor,
                    ),
                    child: const Text('Mulai Sekarang'),
                  ),
                ],
              ),
            ),

            // --- TARUH DI SINI (Setelah Screening Banner) ---

const SizedBox(height: 16), // Jarak dikit dari banner kuis

GestureDetector(
  onTap: () {
    // Navigasi ke halaman AI Chat
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AiChatPage()),
    );
  },
  child: Container(
    width: double.infinity,
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: themeColor.withOpacity(0.3), width: 1.5),
      boxShadow: [
        BoxShadow(
          color: Colors.purple.withOpacity(0.1),
          blurRadius: 10,
          offset: const Offset(0, 4),
        ),
      ],
    ),
    child: Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.purple.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.auto_awesome, color: Colors.purple, size: 30),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Tanya Gemini AI',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              Text(
                'Curhat atau tanya apa saja tentang kondisimu.',
                style: TextStyle(color: Colors.grey[600], fontSize: 12),
              ),
            ],
          ),
        ),
        const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
      ],
    ),
  ),
),

const SizedBox(height: 28), // Jarak ke Aktivitas Kesehatan



            const SizedBox(height: 32),
            const Text(
              'Aktivitas Kesehatan',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.8,
              ),
              itemCount: 4,
              itemBuilder: (context, index) {
                final features = [
                  _FeatureCard(
                    title: 'Mood Tracker',
                    subtitle: 'Catat Mood',
                    icon: Icons.sentiment_satisfied_alt_outlined,
                    color: Colors.orange,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const MoodTrackerPage()),
                      );
                    },
                  ),
                  _FeatureCard(
                    title: 'Sleep Tracker',
                    subtitle: 'Pola Tidur',
                    icon: Icons.bedtime_outlined,
                    color: Colors.indigo,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const SleepTrackerPage()),
                      );
                    },
                  ),
                  _FeatureCard(
                    title: 'Hidrasi',
                    subtitle: 'Catat Air',
                    icon: Icons.water_drop_outlined,
                    color: Colors.blue,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const HydrationTrackerPage()),
                      );
                    },
                  ),
                  _FeatureCard(
                    title: 'Olahraga',
                    subtitle: 'Aktivitas Fisik',
                    icon: Icons.fitness_center_outlined,
                    color: Colors.green,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) =>
                                const ExerciseTrackerPageSmartWatch()),
                      );
                    },
                  ),
                ];
                return features[index];
              },
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}

class _SummaryStatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _SummaryStatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 100,
      margin: const EdgeInsets.symmetric(horizontal: 4),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          Text(
            label,
            style: TextStyle(color: Colors.grey[600], fontSize: 11),
          ),
        ],
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _FeatureCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const Spacer(),
            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            Text(
              subtitle,
              style: TextStyle(color: Colors.grey[600], fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
