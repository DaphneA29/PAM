import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers.dart';
import '../questions.dart';
import 'quiz_page.dart';
import 'profile_page.dart';

class ScreeningPage extends ConsumerWidget {
  const ScreeningPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(profileProvider);
    final themeColor = ref.watch(themeColorProvider);

    // If no profile, prompt user to fill data before scanning
    if (profile == null) {
      // schedule to push profile page after frame
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.push(
            context, MaterialPageRoute(builder: (_) => const ProfilePage()));
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Screening InsightMind'),
        backgroundColor: themeColor,
        actions: [
          IconButton(
            icon: const Icon(Icons.person),
            tooltip: 'Edit Data Diri',
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const ProfilePage()));
            },
          )
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.psychology_alt, color: themeColor, size: 80),
              const SizedBox(height: 24),
              const Text(
                'Mulai Screening Mental Health',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Text(
                'Screening ini terdiri dari ${questions.length} pertanyaan yang dirancang untuk mengevaluasi kesehatan mental Anda secara umum.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey[600], height: 1.5),
              ),
              const SizedBox(height: 32),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: themeColor,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 32,
                    vertical: 16,
                  ),
                ),
                icon: const Icon(Icons.play_arrow),
                label: const Text('Mulai Sekarang'),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const QuizPage()),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
