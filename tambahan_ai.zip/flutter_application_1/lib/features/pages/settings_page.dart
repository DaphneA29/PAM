import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../features/providers.dart';
import 'theme_customization_page.dart';

class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(themeProvider);
    final themeColor = ref.watch(themeColorProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Pengaturan'),
        backgroundColor: themeColor,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SizedBox(height: 8),
          const Text(
            'Mode Tampilan',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                RadioListTile<ThemeMode>(
                  title: const Text('Ikuti Pengaturan Sistem'),
                  subtitle: const Text('Otomatis menyesuaikan dengan sistem'),
                  value: ThemeMode.system,
                  groupValue: mode,
                  onChanged: (v) => ref
                      .read(themeProvider.notifier)
                      .setMode(v ?? ThemeMode.system),
                ),
                const Divider(height: 0),
                RadioListTile<ThemeMode>(
                  title: const Text('Terang'),
                  subtitle: const Text('Tampilan mode terang'),
                  value: ThemeMode.light,
                  groupValue: mode,
                  onChanged: (v) => ref
                      .read(themeProvider.notifier)
                      .setMode(v ?? ThemeMode.light),
                ),
                const Divider(height: 0),
                RadioListTile<ThemeMode>(
                  title: const Text('Gelap'),
                  subtitle: const Text('Tampilan mode gelap'),
                  value: ThemeMode.dark,
                  groupValue: mode,
                  onChanged: (v) => ref
                      .read(themeProvider.notifier)
                      .setMode(v ?? ThemeMode.dark),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Tema',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          ListTile(
            leading: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: themeColor,
              ),
            ),
            title: const Text('Kustomisasi Warna Tema'),
            subtitle: const Text('Pilih warna favorit Anda'),
            trailing: const Icon(Icons.arrow_forward),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: Colors.grey[300]!),
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const ThemeCustomizationPage(),
                ),
              );
            },
          ),
          const SizedBox(height: 24),
          const Text(
            'Tentang Aplikasi',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: const [
                ListTile(
                  leading: Icon(Icons.info),
                  title: Text('Versi Aplikasi'),
                  subtitle: Text('1.0.0'),
                ),
                Divider(height: 0),
                ListTile(
                  leading: Icon(Icons.description),
                  title: Text('Tentang InsightMind'),
                  subtitle: Text('Aplikasi kesehatan mental Anda'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
