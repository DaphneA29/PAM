import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/profile.dart';
import '../models/user.dart';
import '../providers.dart';

class ProfilePage extends ConsumerStatefulWidget {
  const ProfilePage({super.key});

  @override
  ConsumerState<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends ConsumerState<ProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtl = TextEditingController();
  final _emailCtl = TextEditingController();
  final _ageCtl = TextEditingController();
  String? _gender;

  @override
  void dispose() {
    _nameCtl.dispose();
    _emailCtl.dispose();
    _ageCtl.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    final user = ref.read(authProvider);
    final p = ref.read(profileProvider);

    if (user != null) {
      _nameCtl.text = user.name;
      _emailCtl.text = user.email;
      _ageCtl.text = user.age?.toString() ?? '';
      _gender = user.gender;
    } else if (p != null) {
      _nameCtl.text = p.name;
      _ageCtl.text = p.age?.toString() ?? '';
      _gender = p.gender;
    }
  }

  void _save() async {
    if (!_formKey.currentState!.validate()) return;

    final user = ref.read(authProvider);
    if (user != null) {
      final age = int.tryParse(_ageCtl.text.trim());
      final updatedUser = user.copyWith(
        name: _nameCtl.text.trim(),
        age: age,
        gender: _gender,
      );
      await ref.read(authProvider.notifier).updateProfile(updatedUser);
    } else {
      final name = _nameCtl.text.trim();
      final age = int.tryParse(_ageCtl.text.trim());
      final profile = Profile(name: name, age: age, gender: _gender);
      await ref.read(profileProvider.notifier).save(profile);
    }

    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = ref.watch(themeColorProvider);
    final user = ref.watch(authProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil Saya'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              ref.read(authProvider.notifier).logout();
              Navigator.of(context).pushReplacementNamed('/login');
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Profile header
              if (user != null)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: themeColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: themeColor.withOpacity(0.3)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: themeColor,
                        ),
                        child: const Icon(
                          Icons.person,
                          color: Colors.white,
                          size: 40,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        user.name,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      Text(
                        user.email,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 24),
              const Text(
                'Informasi Pribadi',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _nameCtl,
                decoration: InputDecoration(
                  labelText: 'Nama Lengkap',
                  prefixIcon: const Icon(Icons.person),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                validator: (v) =>
                    (v?.trim().isEmpty ?? true) ? 'Masukkan nama' : null,
              ),
              const SizedBox(height: 12),
              if (user != null)
                TextFormField(
                  controller: _emailCtl,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    prefixIcon: const Icon(Icons.email),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  readOnly: true,
                  enabled: false,
                ),
              if (user != null) const SizedBox(height: 12),
              TextFormField(
                controller: _ageCtl,
                decoration: InputDecoration(
                  labelText: 'Umur (opsional)',
                  prefixIcon: const Icon(Icons.calendar_today),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _gender,
                items: const [
                  DropdownMenuItem(value: 'Male', child: Text('Laki-laki')),
                  DropdownMenuItem(value: 'Female', child: Text('Perempuan')),
                  DropdownMenuItem(value: 'Other', child: Text('Lainnya')),
                ],
                onChanged: (v) => setState(() => _gender = v),
                decoration: InputDecoration(
                  labelText: 'Jenis Kelamin (opsional)',
                  prefixIcon: const Icon(Icons.wc),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: themeColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  icon: const Icon(Icons.save),
                  label: const Text('Simpan Perubahan'),
                  onPressed: _save,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
