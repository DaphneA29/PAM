import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import '../providers.dart';

class ThemeCustomizationPage extends ConsumerStatefulWidget {
  const ThemeCustomizationPage({super.key});

  @override
  ConsumerState<ThemeCustomizationPage> createState() =>
      _ThemeCustomizationPageState();
}

class _ThemeCustomizationPageState
    extends ConsumerState<ThemeCustomizationPage> {
  @override
  Widget build(BuildContext context) {
    final themeColor = ref.watch(themeColorProvider);
    final themeMode = ref.watch(themeProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Kustomisasi Tema'),
        backgroundColor: themeColor,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SizedBox(height: 16),
          const Text(
            'Warna Tema Utama',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          _ColorDisplayCard(themeColor: themeColor),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: themeColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              icon: const Icon(Icons.color_lens),
              label: const Text('Pilih Warna'),
              onPressed: () {
                _showColorPicker(context, ref, themeColor);
              },
            ),
          ),
          const SizedBox(height: 32),
          const Text(
            'Mode Tampilan',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                RadioListTile<ThemeMode>(
                  title: const Text('Terang'),
                  subtitle: const Text('Gunakan tampilan terang'),
                  value: ThemeMode.light,
                  groupValue: themeMode,
                  onChanged: (mode) {
                    if (mode != null) {
                      ref.read(themeProvider.notifier).setMode(mode);
                    }
                  },
                ),
                const Divider(height: 0),
                RadioListTile<ThemeMode>(
                  title: const Text('Gelap'),
                  subtitle: const Text('Gunakan tampilan gelap'),
                  value: ThemeMode.dark,
                  groupValue: themeMode,
                  onChanged: (mode) {
                    if (mode != null) {
                      ref.read(themeProvider.notifier).setMode(mode);
                    }
                  },
                ),
                const Divider(height: 0),
                RadioListTile<ThemeMode>(
                  title: const Text('Otomatis'),
                  subtitle: const Text('Ikuti pengaturan sistem'),
                  value: ThemeMode.system,
                  groupValue: themeMode,
                  onChanged: (mode) {
                    if (mode != null) {
                      ref.read(themeProvider.notifier).setMode(mode);
                    }
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),
          const Text(
            'Warna Preset',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 4,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              Colors.indigo,
              Colors.blue,
              Colors.purple,
              Colors.pink,
              Colors.red,
              Colors.orange,
              Colors.green,
              Colors.teal,
            ]
                .map((color) => _PresetColorButton(
                      color: color,
                      isSelected: themeColor == color,
                      onTap: () {
                        ref.read(themeColorProvider.notifier).setColor(color);
                      },
                    ))
                .toList(),
          ),
        ],
      ),
    );
  }

  void _showColorPicker(
      BuildContext context, WidgetRef ref, Color currentColor) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Pilih Warna'),
          content: SingleChildScrollView(
            child: ColorPicker(
              pickerColor: currentColor,
              onColorChanged: (color) {
                ref.read(themeColorProvider.notifier).setColor(color);
              },
              enableAlpha: false,
              displayThumbColor: true,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Selesai'),
            ),
          ],
        );
      },
    );
  }
}

class _ColorDisplayCard extends StatelessWidget {
  final Color themeColor;

  const _ColorDisplayCard({required this.themeColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150,
      decoration: BoxDecoration(
        color: themeColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: themeColor.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.palette,
              size: 60,
              color: Colors.white.withOpacity(0.8),
            ),
            const SizedBox(height: 8),
            Text(
              '#${themeColor.value.toRadixString(16).substring(2).toUpperCase()}',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PresetColorButton extends StatelessWidget {
  final Color color;
  final bool isSelected;
  final VoidCallback onTap;

  const _PresetColorButton({
    required this.color,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: isSelected
              ? Border.all(color: Colors.black, width: 3)
              : Border.all(color: Colors.grey[300]!, width: 2),
          boxShadow: [
            if (isSelected)
              BoxShadow(
                color: color.withOpacity(0.4),
                blurRadius: 8,
              ),
          ],
        ),
        child: isSelected
            ? Center(
                child: Icon(
                  Icons.check,
                  color: _getContrastColor(color),
                  size: 24,
                ),
              )
            : null,
      ),
    );
  }

  Color _getContrastColor(Color color) {
    final luminance = color.computeLuminance();
    return luminance > 0.5 ? Colors.black : Colors.white;
  }
}
