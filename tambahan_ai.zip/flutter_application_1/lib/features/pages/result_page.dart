import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../providers.dart';
import '../models/history_entry.dart';
import '../models/profile.dart';

class ResultPage extends ConsumerWidget {
  const ResultPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final answers = ref.watch(answersProvider);
    final score = answers.values.fold(0, (p, e) => p + e);
    // Auto-save history entry once when the result page is shown
    Future.microtask(() async {
      final profile = ref.read(profileProvider);
      final date = DateTime.now();
      final id = date.millisecondsSinceEpoch.toString();
      final title = 'Hasil Screening ${DateFormat.yMd().format(date)}';
      final namePart = profile != null ? 'Nama: ${profile.name}. ' : '';
      final notes = StringBuffer();
      notes.writeln(namePart);
      notes.writeln('Skor: $score');
      answers.forEach((k, v) => notes.writeln('$k: $v'));
      final entry = HistoryEntry(
        id: id,
        date: date,
        title: title,
        notes: notes.toString(),
        score: score,
      );
      await ref.read(historyProvider.notifier).addEntry(entry);
    });
    String risk;
    String rec;
    if (score <= 4) {
      risk = 'Rendah';
      rec = 'Pertahankan kebiasaan baik. Jaga tidur, makan, dan olahraga.';
    } else if (score <= 9) {
      risk = 'Sedang';
      rec =
          'Kelola stres dengan aktivitas positif, meditasi, atau berbagi cerita.';
    } else {
      risk = 'Tinggi';
      rec =
          'Disarankan untuk berkonsultasi dengan profesional kesehatan mental.';
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Hasil Screening')),
      body: Center(
        child: Card(
          margin: const EdgeInsets.all(24),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.lightbulb_outline,
                    size: 48, color: Colors.indigo),
                const SizedBox(height: 16),
                Text('Skor Anda: $score',
                    style: const TextStyle(
                        fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Tingkat Risiko: $risk',
                    style: const TextStyle(color: Colors.green, fontSize: 18)),
                const SizedBox(height: 12),
                Text(rec, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  icon: const Icon(Icons.arrow_back),
                  label: const Text('Kembali'),
                  onPressed: () {
                    Navigator.popUntil(context, (route) => route.isFirst);
                  },
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
