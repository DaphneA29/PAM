import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../providers.dart';
import '../models/health_metric.dart';
import 'mental_health_history_page.dart';

class HealthInsightsPage extends ConsumerWidget {
  const HealthInsightsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeColor = ref.watch(themeColorProvider);
    final metrics = ref.watch(healthMetricsProvider);

    // Get mental health metrics from HealthMetric data
    final mentalHealthMetrics = metrics
        .where((metric) => metric.type == 'mental_health')
        .toList()
      ..sort((a, b) =>
          b.recordedAt.compareTo(a.recordedAt)); // Sort by newest first

    // Calculate score from latest mental health metric
    double scorePercentage = 0;
    String currentRiskLevel = 'Belum ada data';
    if (mentalHealthMetrics.isNotEmpty) {
      scorePercentage = mentalHealthMetrics.first.value;
      currentRiskLevel = mentalHealthMetrics.first.notes ?? 'Tidak diketahui';
    }

    // Get today's health metrics
    final today = DateTime.now();
    final todayMetrics = metrics
        .where((m) =>
            m.recordedAt.year == today.year &&
            m.recordedAt.month == today.month &&
            m.recordedAt.day == today.day)
        .toList();

    final todayMoods = todayMetrics.where((m) => m.type == 'mood').toList();
    final todaySleep = todayMetrics.where((m) => m.type == 'sleep').toList();

    // Mood trend data (last 7 days)
    final moodTrend = metrics.where((m) => m.type == 'mood').toList()
      ..sort((a, b) => a.recordedAt.compareTo(b.recordedAt));

    final recentMoods = moodTrend.length > 7
        ? moodTrend.sublist(moodTrend.length - 7)
        : moodTrend;

    // Generate AI recommendations based on data
    final recommendations = _generateRecommendations(
      scorePercentage,
      todayMoods,
      todaySleep,
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Health Insights'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Score Card
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [themeColor, themeColor.withOpacity(0.8)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: themeColor.withOpacity(0.3),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Skor Kesehatan Mental',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        scorePercentage.toStringAsFixed(0),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 48,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(bottom: 10, left: 4),
                        child: Text(
                          '%',
                          style: TextStyle(color: Colors.white70, fontSize: 20),
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          currentRiskLevel,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: LinearProgressIndicator(
                      value: scorePercentage / 100,
                      minHeight: 10,
                      backgroundColor: Colors.white.withOpacity(0.2),
                      valueColor:
                          const AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Mood Trend Chart
            if (recentMoods.isNotEmpty) ...[
              const Text(
                'Tren Mood Terakhir',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              Container(
                height: 200,
                padding: const EdgeInsets.only(right: 20, top: 10, bottom: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: LineChart(
                  LineChartData(
                    gridData: FlGridData(show: false),
                    titlesData: FlTitlesData(
                      show: true,
                      topTitles:
                          AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      rightTitles:
                          AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      bottomTitles:
                          AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          interval: 1,
                          getTitlesWidget: (value, meta) {
                            if (value == 1)
                              return const Text('😢',
                                  style: TextStyle(fontSize: 12));
                            if (value == 3)
                              return const Text('😐',
                                  style: TextStyle(fontSize: 12));
                            if (value == 5)
                              return const Text('😊',
                                  style: TextStyle(fontSize: 12));
                            return const SizedBox();
                          },
                          reservedSize: 30,
                        ),
                      ),
                    ),
                    borderData: FlBorderData(show: false),
                    minX: 0,
                    maxX: (recentMoods.length - 1).toDouble(),
                    minY: 0,
                    maxY: 6,
                    lineBarsData: [
                      LineChartBarData(
                        spots: recentMoods.asMap().entries.map((e) {
                          return FlSpot(e.key.toDouble(), e.value.value);
                        }).toList(),
                        isCurved: true,
                        color: themeColor,
                        barWidth: 4,
                        isStrokeCapRound: true,
                        dotData: FlDotData(show: true),
                        belowBarData: BarAreaData(
                          show: true,
                          color: themeColor.withOpacity(0.1),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 32),
            ],

            const Text(
              'Ringkasan Hari Ini',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _MetricCard(
                  icon: Icons.sentiment_satisfied,
                  label: 'Mood Check-ins',
                  value: '${todayMoods.length}x',
                  color: Colors.orange,
                ),
                _MetricCard(
                  icon: Icons.nights_stay,
                  label: 'Rata-rata Tidur',
                  value: todaySleep.isEmpty
                      ? '-'
                      : '${(todaySleep.fold<double>(0, (sum, m) => sum + m.value) / todaySleep.length).toStringAsFixed(1)}h',
                  color: Colors.indigo,
                ),
              ],
            ),
            const SizedBox(height: 24),
            // AI Recommendations
            const Text(
              'Rekomendasi AI untuk Anda',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: recommendations.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final rec = recommendations[index];
                return Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border.all(color: rec['color'].withOpacity(0.3)),
                    borderRadius: BorderRadius.circular(12),
                    color: rec['color'].withOpacity(0.05),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: rec['color'].withOpacity(0.2),
                            ),
                            child: Icon(
                              rec['icon'],
                              color: rec['color'],
                              size: 24,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              rec['title'],
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        rec['description'],
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[700],
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(height: 24),
            // Mental Health History
            if (mentalHealthMetrics.isEmpty) ...[
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Icon(
                        Icons.info_outline,
                        color: Colors.orange,
                        size: 24,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Belum ada data kesehatan mental',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Selesaikan quiz kesehatan mental untuk melihat skor Anda di sini',
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ] else ...[
              const Text(
                'Riwayat Kesehatan Mental',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: mentalHealthMetrics.length > 5
                    ? 5
                    : mentalHealthMetrics.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, index) {
                  final metric = mentalHealthMetrics[index];
                  return InkWell(
                    onTap: () {
                      _showMentalHealthDetail(context, metric);
                    },
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade300),
                        borderRadius: BorderRadius.circular(12),
                        color: Colors.white,
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: themeColor.withOpacity(0.1),
                            ),
                            child: Icon(
                              Icons.psychology,
                              color: themeColor,
                              size: 24,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Skor: ${metric.value.toStringAsFixed(0)}%',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                                Text(
                                  metric.notes ?? 'Tidak ada keterangan',
                                  style: TextStyle(
                                    color: Colors.grey[600],
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                DateFormat('dd MMM yyyy')
                                    .format(metric.recordedAt),
                                style: TextStyle(
                                  color: Colors.grey[600],
                                  fontSize: 12,
                                ),
                              ),
                              Text(
                                DateFormat('HH:mm').format(metric.recordedAt),
                                style: TextStyle(
                                  color: Colors.grey[600],
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(width: 8),
                          const Icon(
                            Icons.chevron_right,
                            color: Colors.grey,
                            size: 20,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              if (mentalHealthMetrics.length > 5)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: TextButton(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => const MentalHealthHistoryPage(),
                        ),
                      );
                    },
                    child: Text(
                      'Lihat semua riwayat',
                      style: TextStyle(color: themeColor),
                    ),
                  ),
                ),
              const SizedBox(height: 24),
            ],
            // Tips Section
            const Text(
              'Tips Sehat',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: _getHealthTips().map((tip) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 24,
                            height: 24,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: themeColor,
                            ),
                            child: const Icon(
                              Icons.check,
                              color: Colors.white,
                              size: 16,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(tip),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showMentalHealthDetail(BuildContext context, dynamic metric) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Row(
            children: [
              Icon(Icons.psychology, color: Theme.of(context).primaryColor),
              const SizedBox(width: 8),
              const Text('Detail Kesehatan Mental'),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Skor Kesehatan Mental',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          Text(
                            '${metric.value.toStringAsFixed(0)}%',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 24,
                              color: Theme.of(context).primaryColor,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Tingkat Risiko: ${metric.notes ?? 'Tidak diketahui'}',
                        style: TextStyle(
                          color: Colors.grey[700],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Tanggal & Waktu',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  DateFormat('EEEE, dd MMMM yyyy', 'id_ID')
                      .format(metric.recordedAt),
                  style: TextStyle(
                    color: Colors.grey[700],
                    fontSize: 14,
                  ),
                ),
                Text(
                  DateFormat('HH:mm', 'id_ID').format(metric.recordedAt),
                  style: TextStyle(
                    color: Colors.grey[700],
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Rekomendasi',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 8),
                _getMentalHealthRecommendation(metric.value, metric.notes),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Tutup'),
            ),
          ],
        );
      },
    );
  }

  Widget _getMentalHealthRecommendation(double score, String? riskLevel) {
    String recommendation;

    if (score >= 80) {
      recommendation =
          'Kesehatan mental Anda dalam kondisi yang sangat baik. Pertahankan gaya hidup sehat dan rutinitas positif yang telah Anda jalani.';
    } else if (score >= 60) {
      recommendation =
          'Kesehatan mental Anda cukup baik, namun ada ruang untuk peningkatan. Pertimbangkan untuk melakukan aktivitas relaksasi dan menjaga keseimbangan hidup.';
    } else if (score >= 40) {
      recommendation =
          'Perhatian khusus diperlukan untuk kesehatan mental Anda. Disarankan untuk berbicara dengan orang terdekat atau mempertimbangkan konsultasi dengan profesional.';
    } else {
      recommendation =
          'Sangat disarankan untuk segera berkonsultasi dengan profesional kesehatan mental untuk mendapatkan dukungan yang tepat.';
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        recommendation,
        style: TextStyle(
          color: Colors.grey[700],
          fontSize: 14,
          height: 1.5,
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _generateRecommendations(
    double score,
    List<HealthMetric> moods,
    List<HealthMetric> sleepData,
  ) {
    final recommendations = <Map<String, dynamic>>[];

    // Based on score
    if (score > 70) {
      recommendations.add({
        'title': 'Kesehatan Mental Baik',
        'description':
            'Skor Anda menunjukkan kesehatan mental yang baik. Teruskan aktivitas positif dan jaga keseimbangan hidup Anda.',
        'icon': Icons.thumb_up,
        'color': Colors.green,
      });
    } else if (score > 50) {
      recommendations.add({
        'title': 'Perhatian Diperlukan',
        'description':
            'Ada beberapa area yang perlu perhatian. Pertimbangkan untuk berbicara dengan profesional kesehatan mental.',
        'icon': Icons.warning,
        'color': Colors.orange,
      });
    } else {
      recommendations.add({
        'title': 'Hubungi Profesional',
        'description':
            'Kami merekomendasikan untuk berbicara dengan profesional kesehatan mental segera untuk dukungan yang tepat.',
        'icon': Icons.local_hospital,
        'color': Colors.red,
      });
    }

    // Mood-based recommendation
    if (moods.isEmpty) {
      recommendations.add({
        'title': 'Mulai Tracking Mood',
        'description':
            'Catat suasana hati Anda setiap hari untuk pemantauan kesejahteraan yang lebih baik.',
        'icon': Icons.sentiment_satisfied,
        'color': Colors.blue,
      });
    }

    // Sleep-based recommendation
    if (sleepData.isEmpty) {
      recommendations.add({
        'title': 'Monitor Pola Tidur',
        'description':
            'Tidur berkualitas adalah kunci kesehatan mental. Mulai catat pola tidur Anda.',
        'icon': Icons.nights_stay,
        'color': Colors.indigo,
      });
    } else {
      double totalSleep = 0;
      for (var metric in sleepData) {
        totalSleep += metric.value;
      }
      final avgSleep = totalSleep / sleepData.length;
      if (avgSleep < 6) {
        recommendations.add({
          'title': 'Tingkatkan Durasi Tidur',
          'description':
              'Rata-rata tidur Anda kurang dari 6 jam. Tingkatkan menjadi 7-8 jam untuk kesehatan optimal.',
          'icon': Icons.bedtime,
          'color': Colors.purple,
        });
      }
    }

    return recommendations;
  }

  List<String> _getHealthTips() {
    return [
      'Luangkan 10-15 menit setiap hari untuk meditasi atau relaksasi',
      'Batasi penggunaan media sosial dan layar sebelum tidur',
      'Lakukan aktivitas fisik minimal 30 menit setiap hari',
      'Minum air putih yang cukup (8 gelas per hari)',
      'Berbicara dengan teman atau keluarga tentang perasaan Anda',
      'Hindari kafein berlebihan, terutama di malam hari',
    ];
  }
}

class _MetricCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _MetricCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: color.withOpacity(0.3)),
          borderRadius: BorderRadius.circular(12),
          color: color.withOpacity(0.05),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(height: 8),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
