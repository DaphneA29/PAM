import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../models/health_metric.dart';
import '../providers.dart';
import '../../services/emotion_detection_service.dart';
import '../../services/ai_service.dart';

class MoodTrackerPage extends ConsumerStatefulWidget {
  const MoodTrackerPage({super.key});

  @override
  ConsumerState<MoodTrackerPage> createState() => _MoodTrackerPageState();
}

class _MoodTrackerPageState extends ConsumerState<MoodTrackerPage> {
  late EmotionDetectionService _emotionService;
  String? _detectedEmotion;
  int? _moodScore;
  EmotionRecommendation? _recommendation;

  final List<MoodOption> moodOptions = [
    MoodOption(
      emoji: '😊',
      label: 'Bahagia',
      value: 5,
      color: const Color(0xFFFFD700),
    ),
    MoodOption(
      emoji: '😄',
      label: 'Senang',
      value: 4,
      color: const Color(0xFF90EE90),
    ),
    MoodOption(
      emoji: '😌',
      label: 'Santai',
      value: 3,
      color: const Color(0xFF87CEEB),
    ),
    MoodOption(
      emoji: '😐',
      label: 'Netral',
      value: 2,
      color: const Color(0xFFC0C0C0),
    ),
    MoodOption(
      emoji: '😕',
      label: 'Ragu',
      value: 2,
      color: const Color(0xFFFFB6C1),
    ),
    MoodOption(
      emoji: '😢',
      label: 'Sedih',
      value: 1,
      color: const Color(0xFF6495ED),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _emotionService = EmotionDetectionService();
  }

  // Camera feature disabled

  Future<void> _saveMood() async {
    if (_moodScore == null) {
      _showErrorDialog('Pilih mood terlebih dahulu');
      return;
    }

    final user = ref.read(authProvider);
    if (user == null) return;

    final ai = AiService();
    final aiResponse = await ai.sendMessage('Buatkan ringkasan singkat dan saran berdasarkan mood score ${_moodScore!} dan emosi terdeteksi ${_detectedEmotion ?? 'tidak diketahui'}');

    final metric = HealthMetric(
      id: const Uuid().v4(),
      userId: user.id,
      type: 'mood',
      value: _moodScore!.toDouble(),
      notes: aiResponse,
      recordedAt: DateTime.now(),
    );

    await ref.read(healthMetricsProvider.notifier).addMetric(metric);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Mood berhasil dicatat!')),
      );
      Navigator.pop(context);
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    try {
      _emotionService.dispose();
    } catch (e) {
      debugPrint('Error disposing emotion service: $e');
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = ref.watch(themeColorProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('😊 Mood Tracker'),
        backgroundColor: themeColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Camera/photo feature disabled

            // Manual Mood Selection
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Pilih Mood Kamu Hari Ini',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                GridView.count(
                  crossAxisCount: 3,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: moodOptions
                      .map((mood) => _MoodCard(
                            mood: mood,
                            isSelected: _moodScore == mood.value,
                            onTap: () {
                              setState(() {
                                _moodScore = mood.value;
                                _detectedEmotion = mood.label;
                                final rec = _emotionService
                                    .getEmotionRecommendation(mood.label);
                                _recommendation = rec;
                              });
                            },
                          ))
                      .toList(),
                ),
              ],
            ),

            if (_recommendation != null) ...[
              const SizedBox(height: 24),
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                color: Color(_recommendation!.color).withOpacity(0.1),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            _recommendation!.emoji,
                            style: const TextStyle(fontSize: 32),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              _recommendation!.title,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _recommendation!.description,
                        style: const TextStyle(fontSize: 13),
                      ),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Color(_recommendation!.color),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '💡 ${_recommendation!.recommendation}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.white,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: themeColor,
                  ),
                  icon: const Icon(Icons.save),
                  label: const Text('Simpan Mood'),
                  onPressed: _saveMood,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class MoodOption {
  final String emoji;
  final String label;
  final int value;
  final Color color;

  MoodOption({
    required this.emoji,
    required this.label,
    required this.value,
    required this.color,
  });
}

class _MoodCard extends StatelessWidget {
  final MoodOption mood;
  final bool isSelected;
  final VoidCallback onTap;

  const _MoodCard({
    required this.mood,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: mood.color.withOpacity(0.1),
          border: Border.all(
            color: isSelected ? mood.color : mood.color.withOpacity(0.3),
            width: isSelected ? 2 : 1,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: mood.color.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(mood.emoji, style: const TextStyle(fontSize: 40)),
            const SizedBox(height: 8),
            Text(
              mood.label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                color: Colors.black87,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
