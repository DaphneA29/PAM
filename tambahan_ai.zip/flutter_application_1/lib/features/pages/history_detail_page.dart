import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';

import '../models/history_entry.dart';
import '../providers.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class HistoryDetailPage extends ConsumerWidget {
  final HistoryEntry entry;
  final Future<void> Function()? onDelete;

  const HistoryDetailPage({super.key, required this.entry, this.onDelete});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: Hero(tag: 'history-title-${entry.id}', child: Text(entry.title)),
        actions: [
          IconButton(
            icon: const Icon(Icons.copy),
            tooltip: 'Salin CSV',
            onPressed: () async {
              final messenger = ScaffoldMessenger.of(context);
              final csv = '${HistoryEntry.csvHeader()}\n${entry.toCsvRow()}';
              await Clipboard.setData(ClipboardData(text: csv));
              messenger.showSnackBar(
                  const SnackBar(content: Text('Entri disalin sebagai CSV')));
            },
          ),
          IconButton(
            icon: const Icon(Icons.share),
            tooltip: 'Ekspor & Bagikan',
            onPressed: () async {
              final messenger = ScaffoldMessenger.of(context);
              final csv = '${HistoryEntry.csvHeader()}\n${entry.toCsvRow()}';
              try {
                final tmp = await getTemporaryDirectory();
                final file = File(
                    '${tmp.path}${Platform.pathSeparator}insightmind_entry_${entry.id}.csv');
                await file.writeAsString(csv);
                await Share.shareXFiles([XFile(file.path)],
                    text: 'Entri Riwayat InsightMind (CSV)');
                messenger.showSnackBar(
                    const SnackBar(content: Text('Entri dibagikan')));
              } catch (err) {
                await Clipboard.setData(ClipboardData(text: csv));
                messenger.showSnackBar(const SnackBar(
                    content: Text(
                        'Gagal buat file, CSV disalin ke clipboard sebagai gantinya')));
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            tooltip: 'Hapus',
            onPressed: () async {
              final navigator = Navigator.of(context);
              final messenger = ScaffoldMessenger.of(context);
              final ok = await showDialog<bool>(
                  context: context,
                  builder: (c) => AlertDialog(
                        title: const Text('Hapus'),
                        content: const Text('Hapus entri ini?'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(c, false),
                            child: const Text('Batal'),
                          ),
                          TextButton(
                            onPressed: () => Navigator.pop(c, true),
                            child: const Text('Hapus'),
                          ),
                        ],
                      ));
              if (ok == true) {
                if (onDelete != null) {
                  await onDelete!();
                } else {
                  await ref
                      .read(historyProvider.notifier)
                      .deleteEntry(entry.id);
                }
                if (context.mounted) {
                  messenger.showSnackBar(
                      const SnackBar(content: Text('Entri dihapus')));
                }
                navigator.pop();
              }
            },
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Tanggal: ${entry.date.toLocal()}'),
            const SizedBox(height: 12),
            Text('Skor: ${entry.score}'),
            const SizedBox(height: 12),
            Text(entry.notes),
          ],
        ),
      ),
    );
  }
}
