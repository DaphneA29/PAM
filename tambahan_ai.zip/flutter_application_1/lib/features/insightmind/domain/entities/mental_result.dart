class MentalResult {
  final int score;
  final String riskLevel;
  final String recommendation;

  MentalResult({
    required this.score,
    required this.riskLevel,
    required this.recommendation,
  });
}