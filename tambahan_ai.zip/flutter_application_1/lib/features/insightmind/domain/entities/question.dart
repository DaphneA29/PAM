class AnswerOption {
  final String label;
  final int score;
  AnswerOption({required this.label, required this.score});
}

class Question {
  final String id;
  final String text;
  final List<AnswerOption> options;

  Question({required this.id, required this.text, required this.options});
}

List<Question> defaultQuestions() {
  return [
    Question(
      id: 'q1',
      text: 'Apakah Anda merasa cemas dalam dua minggu terakhir?',
      options: [
        AnswerOption(label: 'Tidak sama sekali', score: 0),
        AnswerOption(label: 'Beberapa hari', score: 1),
        AnswerOption(label: 'Hampir setiap hari', score: 2),
        AnswerOption(label: 'Hampir setiap hari dan mengganggu', score: 3),
      ],
    ),
    // Tambahkan q2..q9 sesuai kebutuhan
  ];
}