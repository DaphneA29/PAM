import 'package:uuid/uuid.dart';

class HealthMetric {
  final String id;
  final String userId;
  final String
      type; // 'mood', 'hydration', 'sleep', 'exercise', 'mental_screening'
  final double value;
  final String notes;
  final DateTime recordedAt;

  HealthMetric({
    String? id,
    required this.userId,
    required this.type,
    required this.value,
    required this.notes,
    required this.recordedAt,
  }) : id = id ?? const Uuid().v4();

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'type': type,
      'value': value,
      'notes': notes,
      'recordedAt': recordedAt.toIso8601String(),
    };
  }

  factory HealthMetric.fromJson(Map<String, dynamic> json) {
    return HealthMetric(
      id: json['id'],
      userId: json['userId'],
      type: json['type'],
      value: json['value'].toDouble(),
      notes: json['notes'],
      recordedAt: DateTime.parse(json['recordedAt']),
    );
  }
}
