import '../entities/mental_result.dart';

class CalculateRiskLevel {
  MentalResult execute(int score) {
    String level;
    String rec;
    if (score <= 4) {
      level = 'Rendah';
      rec = 'Pertahankan kebiasaan sehat';
    } else if (score <= 9) {
      level = 'Sedang';
      rec = 'Perhatikan stres dan coba intervensi ringan';
    } else {
      level = 'Tinggi';
      rec = 'Pertimbangkan konsultasi profesional';
    }
    return MentalResult(score: score, riskLevel: level, recommendation: rec);
  }
}
