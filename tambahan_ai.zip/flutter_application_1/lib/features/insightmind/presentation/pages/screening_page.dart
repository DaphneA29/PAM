import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/questionnaire_provider.dart';
import '../../domain/entities/question.dart';

class ScreeningPage extends ConsumerWidget {
  const ScreeningPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final qNotifier = ref.read(questionnaireStateProvider.notifier);
    final qState = ref.watch(questionnaireStateProvider);
    final questions = defaultQuestions();
    return Scaffold(
      appBar: AppBar(title: const Text('Screening')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: questions.length,
        itemBuilder: (context, index) {
          final q = questions[index];
          final selected = qState[q.id];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(q.text, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: q.options.map((opt) {
                      final sel = selected == opt.score;
                      return ChoiceChip(
                        selected: sel,
                        label: Text(opt.label),
                        onSelected: (_) {
                          qNotifier.selectAnswer(q.id, opt.score);
                        },
                      );
                    }).toList(),
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}