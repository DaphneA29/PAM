import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:state_notifier/state_notifier.dart';

final questionnaireStateProvider = StateNotifierProvider<QuestionnaireNotifier, Map<String,int>>(
  (ref) => QuestionnaireNotifier(),
);

class QuestionnaireNotifier extends StateNotifier<Map<String,int>> {
  QuestionnaireNotifier(): super({});

  void selectAnswer(String questionId, int score) {
    final next = Map<String,int>.from(state);
    next[questionId] = score;
    state = next;
  }

  void reset() {
    state = {};
  }

  bool get isComplete {
    // assume 1 question for skeleton; in real app check against number of questions
    return state.isNotEmpty;
  }

  int get totalScore {
    return state.values.fold(0, (p, e) => p + e);
  }
}