import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../services/ai_service.dart'; // sesuaikan path ke ai_service.dart lu

// 1. provider untuk service ai
final aiServiceProvider = Provider((ref) => AiService());

// 2. provider untuk status loading (buat nampilin indikator titik-titik)
final aiLoadingProvider = StateProvider<bool>((ref) => false);

// 3. provider untuk nyimpen list pesan chat
final chatMessagesProvider = StateNotifierProvider<ChatMessagesNotifier, List<Map<String, String>>>((ref) {
  return ChatMessagesNotifier();
});

class ChatMessagesNotifier extends StateNotifier<List<Map<String, String>>> {
  ChatMessagesNotifier() : super([]);

  void addMessage(String role, String text) {
    state = [...state, {'role': role, 'text': text}];
  }
}