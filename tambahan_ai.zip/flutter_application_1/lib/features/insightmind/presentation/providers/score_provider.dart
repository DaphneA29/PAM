import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:state_notifier/state_notifier.dart';
import '../../domain/entities/mental_result.dart';
import '../../domain/usecases/calculate_risk_level.dart';
import '../../data/repositories/score_repository.dart';

final answersProvider = StateProvider<List<int>>((ref) => []);

final scoreRepositoryProvider = Provider((ref) => ScoreRepository());

final calculateRiskProvider = Provider((ref) => CalculateRiskLevel());

final scoreProvider = Provider<int>((ref) {
  final answers = ref.watch(answersProvider);
  final repo = ref.watch(scoreRepositoryProvider);
  return repo.calculateScore(answers);
});

final resultProvider = Provider<MentalResult>((ref) {
  final score = ref.watch(scoreProvider);
  final calc = ref.watch(calculateRiskProvider);
  return calc.execute(score);
});