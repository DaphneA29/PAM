import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:state_notifier/state_notifier.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:developer' as developer;

import 'models/history_entry.dart';
import 'models/profile.dart';
import 'models/user.dart';
import 'models/health_metric.dart';

final answersProvider = StateProvider<Map<String, int>>((ref) => {});

final progressProvider = Provider<int>((ref) {
  return ref.watch(answersProvider).length;
});

final totalQuestionsProvider = Provider<int>((ref) => 9);

// Theme provider persisted with SharedPreferences
class ThemeNotifier extends StateNotifier<ThemeMode> {
  ThemeNotifier() : super(ThemeMode.system) {
    _load();
  }

  static const _key = 'insightmind_theme_mode';

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final v = prefs.getString(_key);
    if (v == 'light') {
      state = ThemeMode.light;
    } else if (v == 'dark') {
      state = ThemeMode.dark;
    } else {
      state = ThemeMode.system;
    }
  }

  Future<void> setMode(ThemeMode mode) async {
    state = mode;
    final prefs = await SharedPreferences.getInstance();
    final s = mode == ThemeMode.light
        ? 'light'
        : mode == ThemeMode.dark
            ? 'dark'
            : 'system';
    await prefs.setString(_key, s);
  }
}

final themeProvider =
    StateNotifierProvider<ThemeNotifier, ThemeMode>((ref) => ThemeNotifier());

// History management persisted with Hive (each entry stored as JSON string per id)
class HistoryNotifier extends StateNotifier<List<HistoryEntry>> {
  static const _boxName = 'historyBox';

  HistoryNotifier() : super([]) {
    _load();
  }

  Box<String> get _box => Hive.box<String>(_boxName);

  Future<void> _load() async {
    try {
      // read all values, which are stored as JSON strings
      final vals = _box.values.toList();
      state = vals.map((v) => HistoryEntry.fromJson(jsonDecode(v))).toList();
    } catch (_) {
      state = [];
    }
  }

  Future<void> addEntry(HistoryEntry e) async {
    // store at key = id
    await _box.put(e.id, jsonEncode(e.toJson()));
    state = [e, ...state];
  }

  Future<void> deleteEntry(String id) async {
    await _box.delete(id);
    state = state.where((e) => e.id != id).toList();
  }

  Future<void> clearAll() async {
    await _box.clear();
    state = [];
  }

  String toCsv() {
    final rows = [HistoryEntry.csvHeader(), ...state.map((e) => e.toCsvRow())];
    return rows.join('\n');
  }
}

final historyProvider =
    StateNotifierProvider<HistoryNotifier, List<HistoryEntry>>(
        (ref) => HistoryNotifier());

// Profile persisted via SharedPreferences
class ProfileNotifier extends StateNotifier<Profile?> {
  static const _key = 'insightmind_profile';

  ProfileNotifier() : super(null) {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(_key);
    if (s == null) return;
    try {
      final m = jsonDecode(s) as Map<String, dynamic>;
      state = Profile.fromJson(m);
    } catch (_) {}
  }

  Future<void> save(Profile p) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(p.toJson()));
    state = p;
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
    state = null;
  }
}

final profileProvider = StateNotifierProvider<ProfileNotifier, Profile?>(
    (ref) => ProfileNotifier());

// ===== Authentication Provider =====
class AuthNotifier extends StateNotifier<User?> {
  static const _usersKey = 'insightmind_users';
  static const _currentUserKey = 'insightmind_current_user';

  AuthNotifier() : super(null) {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(_currentUserKey);
    if (s == null) return;
    try {
      final m = jsonDecode(s) as Map<String, dynamic>;
      state = User.fromJson(m);
    } catch (_) {}
  }

  Future<bool> register(String name, String email, String password) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final usersJson = prefs.getString(_usersKey) ?? '{}';
      final users = jsonDecode(usersJson) as Map<String, dynamic>;

      if (users.containsKey(email)) {
        return false; // User already exists
      }

      final newUser = User(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: name,
        email: email,
        createdAt: DateTime.now(),
      );

      users[email] = {
        'user': newUser.toJson(),
        'password': password, // In production, hash this!
      };

      await prefs.setString(_usersKey, jsonEncode(users));

      // Auto-login after successful registration
      final loginSuccess = await login(email, password);
      return loginSuccess;
    } catch (e) {
      debugPrint('Register error: $e');
      return false;
    }
  }

  Future<bool> login(String email, String password) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final usersJson = prefs.getString(_usersKey) ?? '{}';
      final users = jsonDecode(usersJson) as Map<String, dynamic>;

      if (!users.containsKey(email)) {
        return false; // User not found
      }

      final userData = users[email] as Map<String, dynamic>;
      if (userData['password'] != password) {
        return false; // Wrong password
      }

      final user = User.fromJson(userData['user'] as Map<String, dynamic>);
      await prefs.setString(_currentUserKey, jsonEncode(user.toJson()));
      state = user; // Update the state immediately
      return true;
    } catch (e) {
      debugPrint('Login error: $e');
      return false;
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_currentUserKey);
    state = null;
  }

  Future<void> updateProfile(User user) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final usersJson = prefs.getString(_usersKey) ?? '{}';
      final users = jsonDecode(usersJson) as Map<String, dynamic>;

      if (state != null) {
        if (users.containsKey(state!.email)) {
          final userData = users[state!.email] as Map<String, dynamic>;
          userData['user'] = user.toJson();
          await prefs.setString(_usersKey, jsonEncode(users));
          await prefs.setString(_currentUserKey, jsonEncode(user.toJson()));
          state = user;
        }
      }
    } catch (_) {}
  }
}

final authProvider =
    StateNotifierProvider<AuthNotifier, User?>((ref) => AuthNotifier());

// Provider untuk mendapatkan user yang sedang login
final currentUserProvider = Provider<User?>((ref) {
  return ref.watch(authProvider);
});

// Provider untuk mendapatkan nama user
final userNameProvider = Provider<String>((ref) {
  final user = ref.watch(authProvider);
  return user?.name ?? 'User';
});

// ===== Theme Color Customization =====
class ThemeColorNotifier extends StateNotifier<Color> {
  ThemeColorNotifier() : super(Colors.indigo) {
    _load();
  }

  static const _key = 'insightmind_theme_color';

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final v = prefs.getInt(_key);
    if (v != null) {
      state = Color(v);
    }
  }

  Future<void> setColor(Color color) async {
    state = color;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_key, color.value);
  }
}

final themeColorProvider = StateNotifierProvider<ThemeColorNotifier, Color>(
    (ref) => ThemeColorNotifier());

// ===== Health Metrics =====
class HealthMetricsNotifier extends StateNotifier<List<HealthMetric>> {
  static const _boxName = 'healthMetricsBox';
  List<HealthMetric>? _cachedMetrics;
  DateTime? _lastLoadTime;

  HealthMetricsNotifier() : super([]) {
    _load();
  }

  Box<String> get _box => Hive.box<String>(_boxName);

  Future<void> _load() async {
    try {
      // Use cache if available and less than 5 minutes old
      if (_cachedMetrics != null && _lastLoadTime != null) {
        final cacheAge = DateTime.now().difference(_lastLoadTime!);
        if (cacheAge.inMinutes < 5) {
          state = _cachedMetrics!;
          return;
        }
      }

      final vals = _box.values.toList();
      _cachedMetrics =
          vals.map((v) => HealthMetric.fromJson(jsonDecode(v))).toList();
      _lastLoadTime = DateTime.now();
      state = _cachedMetrics!;
    } catch (_) {
      state = [];
    }
  }

  Future<void> addMetric(HealthMetric metric) async {
    await _box.put(metric.id, jsonEncode(metric.toJson()));
    state = [metric, ...state];
  }

  Future<void> deleteMetric(String id) async {
    await _box.delete(id);
    state = state.where((m) => m.id != id).toList();
  }

  List<HealthMetric> getMetricsByType(String type) {
    return state.where((m) => m.type == type).toList();
  }

  List<HealthMetric> getMetricsForToday() {
    final today = DateTime.now();
    return state
        .where((m) =>
            m.recordedAt.year == today.year &&
            m.recordedAt.month == today.month &&
            m.recordedAt.day == today.day)
        .toList();
  }
}

final healthMetricsProvider =
    StateNotifierProvider<HealthMetricsNotifier, List<HealthMetric>>(
        (ref) => HealthMetricsNotifier());

// Optimized providers for today's data
final todayMetricsProvider = Provider<List<HealthMetric>>((ref) {
  final metrics = ref.watch(healthMetricsProvider);
  final today = DateTime.now();
  return metrics.where((m) {
    final date = m.recordedAt;
    return date.year == today.year &&
        date.month == today.month &&
        date.day == today.day;
  }).toList();
});

final todayMoodCountProvider = Provider<int>((ref) {
  final todayMetrics = ref.watch(todayMetricsProvider);
  return todayMetrics.where((m) => m.type == 'mood').length;
});

final todayHydrationProvider = Provider<double>((ref) {
  final todayMetrics = ref.watch(todayMetricsProvider);
  return todayMetrics
      .where((m) => m.type == 'hydration')
      .fold<double>(0, (sum, m) => sum + m.value);
});

final todaySleepProvider = Provider<double>((ref) {
  final todayMetrics = ref.watch(todayMetricsProvider);
  return todayMetrics
      .where((m) => m.type == 'sleep')
      .fold<double>(0, (sum, m) => sum + m.value);
});

final todayExerciseProvider = Provider<double>((ref) {
  final todayMetrics = ref.watch(todayMetricsProvider);
  return todayMetrics
      .where((m) => m.type == 'exercise')
      .fold<double>(0, (sum, m) => sum + m.value);
});
