
class Question {
  final String id;
  final String text;
  final List<String> options;
  Question({required this.id, required this.text, required this.options});
}

final List<Question> questions = [
  Question(
    id: 'q1',
    text: 'Dalam 2 minggu terakhir, seberapa sering Anda merasa sedih atau murung?',
    options: ['Tidak Pernah', 'Beberapa Hari', 'Lebih dari Separuh Hari', 'Hampir Setiap Hari'],
  ),
  Question(
    id: 'q2',
    text: 'Kesulitan menikmati hal-hal yang biasanya menyenangkan?',
    options: ['Tidak Pernah', 'Beberapa Hari', 'Lebih dari Separuh Hari', 'Hampir Setiap Hari'],
  ),
  Question(
    id: 'q3',
    text: 'Merasa sangat lelah atau kurang energi dalam aktivitas sehari-hari?',
    options: ['Tidak Pernah', 'Beberapa Hari', 'Lebih dari Separuh Hari', 'Hampir Setiap Hari'],
  ),
  Question(
    id: 'q4',
    text: 'Kesulitan tidur (baik sulit tidur atau terlalu banyak tidur)?',
    options: ['Tidak Pernah', 'Beberapa Hari', 'Lebih dari Separuh Hari', 'Hampir Setiap Hari'],
  ),
  Question(
    id: 'q5',
    text: 'Merasa kurang percaya diri atau merasa gagal?',
    options: ['Tidak Pernah', 'Beberapa Hari', 'Lebih dari Separuh Hari', 'Hampir Setiap Hari'],
  ),
  Question(
    id: 'q6',
    text: 'Kesulitan berkonsentrasi pada hal-hal seperti membaca atau menonton?',
    options: ['Tidak Pernah', 'Beberapa Hari', 'Lebih dari Separuh Hari', 'Hampir Setiap Hari'],
  ),
  Question(
    id: 'q7',
    text: 'Gerakan atau berbicara lebih lambat dari biasanya, atau terlalu gelisah?',
    options: ['Tidak Pernah', 'Beberapa Hari', 'Lebih dari Separuh Hari', 'Hampir Setiap Hari'],
  ),
  Question(
    id: 'q8',
    text: 'Merasa cemas, khawatir berlebihan, atau sulit mengendalikan rasa khawatir?',
    options: ['Tidak Pernah', 'Beberapa Hari', 'Lebih dari Separuh Hari', 'Hampir Setiap Hari'],
  ),
  Question(
    id: 'q9',
    text: 'Merasa tidak berharga atau berpikir lebih baik tidak hidup?',
    options: ['Tidak Pernah', 'Beberapa Hari', 'Lebih dari Separuh Hari', 'Hampir Setiap Hari'],
  ),
];
