import 'dart:convert';

class HistoryEntry {
  final String id;
  final DateTime date;
  final String title;
  final String notes;
  final int score;

  HistoryEntry({
    required this.id,
    required this.date,
    required this.title,
    required this.notes,
    required this.score,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'title': title,
        'notes': notes,
        'score': score,
      };

  factory HistoryEntry.fromJson(Map<String, dynamic> m) => HistoryEntry(
        id: m['id'] as String,
        date: DateTime.parse(m['date'] as String),
        title: m['title'] as String,
        notes: m['notes'] as String,
        score: (m['score'] as num).toInt(),
      );

  String toCsvRow() {
    final escapedTitle = title.replaceAll('"', '""');
    final escapedNotes = notes.replaceAll('"', '""');
    return '"$id","${date.toIso8601String()}","$escapedTitle","$escapedNotes",$score';
  }

  static String csvHeader() => 'id,date,title,notes,score';

  static String encodeList(List<HistoryEntry> list) =>
      jsonEncode(list.map((e) => e.toJson()).toList());

  static List<HistoryEntry> decodeList(String jsonStr) {
    final arr = jsonDecode(jsonStr) as List<dynamic>;
    return arr
        .map((e) => HistoryEntry.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}
