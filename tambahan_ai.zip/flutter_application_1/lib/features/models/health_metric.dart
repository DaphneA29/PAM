class HealthMetric {
  final String id;
  final String userId;
  final String type; // 'mood', 'sleep', 'water', 'exercise', 'anxiety'
  final double value;
  final String? notes;
  final DateTime recordedAt;

  HealthMetric({
    required this.id,
    required this.userId,
    required this.type,
    required this.value,
    this.notes,
    required this.recordedAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'userId': userId,
        'type': type,
        'value': value,
        'notes': notes,
        'recordedAt': recordedAt.toIso8601String(),
      };

  factory HealthMetric.fromJson(Map<String, dynamic> m) => HealthMetric(
        id: m['id'] as String,
        userId: m['userId'] as String,
        type: m['type'] as String,
        value: (m['value'] as num).toDouble(),
        notes: m['notes'] as String?,
        recordedAt: DateTime.parse(m['recordedAt'] as String),
      );
}
