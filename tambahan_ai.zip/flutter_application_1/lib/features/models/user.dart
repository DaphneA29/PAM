class User {
  final String id;
  final String name;
  final String email;
  final int? age;
  final String? gender;
  final DateTime createdAt;

  User({
    required this.id,
    required this.name,
    required this.email,
    this.age,
    this.gender,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'email': email,
        'age': age,
        'gender': gender,
        'createdAt': createdAt.toIso8601String(),
      };

  factory User.fromJson(Map<String, dynamic> m) => User(
        id: m['id'] as String,
        name: m['name'] as String,
        email: m['email'] as String,
        age: m['age'] == null ? null : (m['age'] as num).toInt(),
        gender: m['gender'] as String?,
        createdAt: DateTime.parse(m['createdAt'] as String),
      );

  User copyWith({
    String? id,
    String? name,
    String? email,
    int? age,
    String? gender,
    DateTime? createdAt,
  }) =>
      User(
        id: id ?? this.id,
        name: name ?? this.name,
        email: email ?? this.email,
        age: age ?? this.age,
        gender: gender ?? this.gender,
        createdAt: createdAt ?? this.createdAt,
      );
}
