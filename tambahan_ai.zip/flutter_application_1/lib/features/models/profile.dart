class Profile {
  final String name;
  final int? age;
  final String? gender;

  Profile({required this.name, this.age, this.gender});

  Map<String, dynamic> toJson() => {
        'name': name,
        'age': age,
        'gender': gender,
      };

  factory Profile.fromJson(Map<String, dynamic> m) => Profile(
        name: m['name'] as String,
        age: m['age'] == null ? null : (m['age'] as num).toInt(),
        gender: m['gender'] as String?,
      );
}
