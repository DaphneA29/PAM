import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'src/app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  // Open boxes for history and health metrics
  await Hive.openBox<String>('historyBox');
  await Hive.openBox<String>('healthMetricsBox');
  runApp(const ProviderScope(child: InsightMindApp()));
}

