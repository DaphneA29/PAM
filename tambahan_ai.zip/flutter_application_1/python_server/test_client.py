import base64
import requests

SERVER = 'http://127.0.0.1:5000'
IMAGE_PATH = 'example.jpg'  # replace with a real image path

def detect(image_path):
    with open(image_path, 'rb') as f:
        b = base64.b64encode(f.read()).decode('utf-8')
    payload = {'image': b}
    r = requests.post(f'{SERVER}/detect-emotion', json=payload, timeout=60)
    print(r.status_code)
    print(r.json())

if __name__ == '__main__':
    detect(IMAGE_PATH)
