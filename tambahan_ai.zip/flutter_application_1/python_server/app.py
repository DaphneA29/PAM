import base64
import io
import logging
from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import cv2
from deepface import DeepFace
from PIL import Image

app = Flask(__name__)
CORS(app)
logging.basicConfig(level=logging.INFO)

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok'})

@app.route('/detect-emotion', methods=['POST'])
def detect_emotion():
    try:
        data = request.get_json(force=True)
        if not data or 'image' not in data:
            return jsonify({'error': 'Missing "image" field (base64).'}), 400

        img_b64 = data['image']
        # If data URL provided like 'data:image/jpeg;base64,...', strip prefix
        if ',' in img_b64:
            img_b64 = img_b64.split(',', 1)[1]

        img_bytes = base64.b64decode(img_b64)
        pil_img = Image.open(io.BytesIO(img_bytes)).convert('RGB')
        img = np.array(pil_img)
        # Convert RGB to BGR for OpenCV
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

        # DeepFace analyze (may download models on first run)
        # Using actions=['emotion'] returns emotions dict
        result = DeepFace.analyze(img_path = img, actions=['emotion'], enforce_detection=False)

        # DeepFace returns a dict or list depending on version
        if isinstance(result, list) and len(result) > 0:
            result = result[0]

        emotions = result.get('emotion', {})
        dominant = result.get('dominant_emotion') or max(emotions, key=emotions.get) if emotions else None

        response = {
            'dominant_emotion': dominant,
            'emotions': emotions,
            'region': result.get('region'),
        }
        return jsonify(response)

    except Exception as e:
        logging.exception('Error in detect_emotion')
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # For development only
    app.run(host='0.0.0.0', port=5000, debug=False)
