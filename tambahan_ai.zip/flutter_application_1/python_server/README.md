DeepFace Emotion Detection Server

This small Flask server accepts a base64-encoded image and returns emotion analysis using DeepFace.

Requirements

- Python 3.10+ recommended
- GPU optional; CPU mode works but can be slow

Quickstart (local)

1. Create and activate a virtualenv

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate
```

2. Install requirements

```bash
pip install -r requirements.txt
```

3. Run the server (development)

```bash
python app.py
```

The server listens on port 5000 by default.

API

- GET /health -> {"status":"ok"}
- POST /detect-emotion -> {"image":"<base64>"}
  - Response: {"dominant_emotion": "happy", "emotions": {...}, "region": {...}}

Notes

- On first run DeepFace will download model weights; this may take time and network bandwidth.
- For production, consider running behind Gunicorn and containerizing.

Example curl

```bash
curl -X POST http://127.0.0.1:5000/detect-emotion \
  -H "Content-Type: application/json" \
  -d '{"image":"<base64-data>"}'
```

Python test client

```bash
python test_client.py
```

Docker (optional)

A basic Dockerfile is provided for easy deployment. Build and run with:

```bash
docker build -t emotion-server .
docker run -p 5000:5000 emotion-server
```

Caveats

- DeepFace depends on TensorFlow; installing TensorFlow in some environments (Windows) may require additional steps.
- For mobile integration, ensure the Flutter client sends base64-encoded JPEG/PNG bytes.
