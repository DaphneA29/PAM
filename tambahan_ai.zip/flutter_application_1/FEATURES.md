# InsightMind v2 - Fitur-Fitur Baru

Dokumentasi lengkap tentang fitur-fitur yang telah ditambahkan ke aplikasi InsightMind.

## 🔐 Sistem Login & Autentikasi

### Fitur

- **Register**: Pengguna dapat membuat akun baru dengan nama, email, dan password
- **Login**: Login dengan email dan password yang sudah terdaftar
- **Session Management**: Session otomatis disimpan dengan SharedPreferences
- **Logout**: User dapat logout dari akun mereka

### File yang Terlibat

- `lib/features/pages/login_page.dart` - Halaman login dan registrasi
- `lib/features/models/user.dart` - Model data User
- `lib/features/providers.dart` - AuthNotifier untuk manage state login

### Cara Menggunakan

1. Aplikasi akan mengarahkan ke LoginPage jika user belum login
2. User dapat memilih tab "Daftar" untuk membuat akun baru
3. Setelah login berhasil, user akan diarahkan ke HomePage

---

## 🎨 Kustomisasi Tema (Theme Customization)

### Fitur

- **Color Picker**: Pilih warna tema secara custom menggunakan color picker
- **Preset Colors**: 8 warna preset (Indigo, Blue, Purple, Pink, Red, Orange, Green, Teal)
- **Theme Mode**: Pilih antara Light, Dark, atau Otomatis (mengikuti sistem)
- **Persistent Storage**: Pilihan warna disimpan dan dimuat otomatis

### File yang Terlibat

- `lib/features/pages/theme_customization_page.dart` - Halaman kustomisasi tema
- `lib/features/providers.dart` - ThemeColorNotifier untuk manage state warna

### Cara Menggunakan

1. Buka Settings → "Kustomisasi Warna Tema"
2. Pilih warna dari preset atau gunakan color picker
3. Perubahan akan langsung diterapkan ke seluruh aplikasi

---

## 📝 Quiz dengan Full-Screen View

### Fitur

- **One Question Per Screen**: Setiap pertanyaan ditampilkan dalam layar penuh
- **Navigation**: Tombol Next/Previous untuk navigasi antar pertanyaan
- **Progress Bar**: Menampilkan progress screening di AppBar
- **Answer Validation**: User harus menjawab pertanyaan sebelum bisa lanjut
- **Navigasi Fleksibel**: User dapat kembali ke pertanyaan sebelumnya

### File yang Terlibat

- `lib/features/pages/quiz_page.dart` - Implementasi quiz full-screen dengan PageView

### Cara Menggunakan

1. Dari HomePage, klik "Mulai Screening"
2. Pilih satu jawaban dari 4 pilihan
3. Tekan "Lanjut" untuk ke pertanyaan berikutnya
4. Tekan "Sebelumnya" untuk kembali ke pertanyaan sebelumnya
5. Setelah semua pertanyaan dijawab, tekan "Selesai"

---

## 💊 Health Features

### 1. Mood Tracker

**Deskripsi**: Catat suasana hati Anda dengan emoji dan skala 1-5

**Fitur**:

- 5 level mood (Sangat Sedih hingga Sangat Senang) dengan emoji unik
- Catatan opsional untuk menjelaskan mood
- Riwayat mood hari ini
- Penyimpanan otomatis dengan Hive

**File**: `lib/features/pages/mood_tracker_page.dart`

### 2. Sleep Tracker

**Deskripsi**: Monitor pola tidur dan kualitas tidur Anda

**Fitur**:

- Input waktu tidur dan bangun dengan time picker
- Kalkulasi otomatis durasi tidur dalam jam
- Rating kualitas tidur (1-5 bintang)
- Riwayat tidur hari ini
- Penyimpanan otomatis dengan Hive

**File**: `lib/features/pages/sleep_tracker_page.dart`

### Cara Menggunakan

1. Dari HomePage, klik pada fitur yang diinginkan (Mood Tracker atau Sleep Tracker)
2. Isi data yang diminta
3. Klik "Simpan" untuk menyimpan data
4. Data akan muncul di riwayat hari ini

---

## 🤖 AI Health Insights

### Fitur

- **Health Score**: Skor kesehatan mental berdasarkan hasil screening (0-100%)
- **Status Indicator**: Indikator kesehatan (Sangat Baik, Cukup, Perlu Perhatian, dll)
- **AI Recommendations**: Rekomendasi personal berdasarkan:
  - Skor screening
  - Data mood tracking
  - Data sleep tracking
- **Daily Overview**: Ringkasan aktivitas kesehatan hari ini
- **Health Tips**: Tips kesehatan mental yang berguna

### File yang Terlibat

- `lib/features/pages/health_insights_page.dart` - Halaman AI insights
- Menggunakan data dari `healthMetricsProvider` dan `answersProvider`

### Cara Menggunakan

1. Selesaikan screening mental health
2. Di halaman ringkasan, klik "Lihat AI Insights"
3. Lihat skor kesehatan dan rekomendasi personal Anda
4. Review tips kesehatan yang tersedia

---

## 📊 Data Models

### User Model

```dart
class User {
  final String id;
  final String name;
  final String email;
  final int? age;
  final String? gender;
  final DateTime createdAt;
}
```

### HealthMetric Model

```dart
class HealthMetric {
  final String id;
  final String userId;
  final String type; // 'mood', 'sleep', 'water', 'exercise'
  final double value;
  final String? notes;
  final DateTime recordedAt;
}
```

---

## 🔧 State Management dengan Riverpod

### Providers Baru

1. **authProvider**: Manage state user login

   ```dart
   ref.watch(authProvider) // Get current user
   ref.read(authProvider.notifier).login(email, password)
   ref.read(authProvider.notifier).register(name, email, password)
   ref.read(authProvider.notifier).logout()
   ```

2. **themeColorProvider**: Manage warna tema aplikasi

   ```dart
   ref.watch(themeColorProvider) // Get current color
   ref.read(themeColorProvider.notifier).setColor(color)
   ```

3. **healthMetricsProvider**: Manage data health metrics
   ```dart
   ref.watch(healthMetricsProvider) // Get all metrics
   ref.read(healthMetricsProvider.notifier).addMetric(metric)
   ```

---

## 🗂️ Struktur File Baru

```
lib/features/
├── models/
│   ├── user.dart (NEW)
│   ├── health_metric.dart (NEW)
│   ├── profile.dart
│   └── history_entry.dart
├── pages/
│   ├── login_page.dart (NEW)
│   ├── quiz_page.dart (NEW)
│   ├── theme_customization_page.dart (NEW)
│   ├── mood_tracker_page.dart (NEW)
│   ├── sleep_tracker_page.dart (NEW)
│   ├── health_insights_page.dart (NEW)
│   ├── home_page.dart (UPDATED)
│   ├── profile_page.dart (UPDATED)
│   ├── summary_page.dart (UPDATED)
│   ├── settings_page.dart (UPDATED)
│   └── ...
└── providers.dart (UPDATED)
```

---

## 📦 Dependencies Baru

```yaml
flutter_colorpicker: ^1.0.0 # Color picker widget
google_fonts: ^5.1.0 # Google Fonts support
cached_network_image: ^3.3.0 # Network image caching
http: ^1.1.0 # HTTP client
uuid: ^4.0.0 # UUID generation
```

---

## 🚀 Fitur yang Dapat Dikembangkan di Masa Depan

1. **Hydration Tracker**: Catat konsumsi air harian
2. **Exercise Tracker**: Monitor aktivitas olahraga
3. **Anxiety Tracker**: Tracking tingkat kecemasan
4. **Integration dengan API**: Connect ke backend server untuk sync data
5. **Push Notifications**: Reminder untuk tracking kesehatan
6. **Social Features**: Share progress dengan teman
7. **Advanced Analytics**: Chart dan analisis trending
8. **Professional Consultation**: Integration dengan psikolog/dokter
9. **Multiple Languages**: Support lebih banyak bahasa
10. **Export Data**: Export data dalam format PDF atau CSV

---

## 💡 Tips Pengembangan Lebih Lanjut

### Menambah Health Feature Baru

1. Buat model di `lib/features/models/`
2. Buat page di `lib/features/pages/`
3. Update provider di `lib/features/providers.dart`
4. Tambahkan navigasi di `lib/src/app.dart`
5. Integrasikan ke `home_page.dart`

### Customization Theme

Theme color sudah disimpan dengan persistence. Untuk menambah opsi theme:

1. Update `ThemeColorNotifier` di providers.dart
2. Update `MaterialApp` theme di app.dart

### Data Persistence

- SharedPreferences: Untuk data user dan settings
- Hive: Untuk data metrics dan history (lebih cepat untuk data banyak)
- Integrasi API: Untuk sync ke server (dikembangkan kemudian)

---

Generated: January 2026
