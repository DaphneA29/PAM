# 🧠 InsightMind v2.0 - Mental Health Screening App

Aplikasi Flutter untuk screening kesehatan mental dengan fitur tracking kesehatan dan AI-powered recommendations.

## ✨ Fitur Utama

### 🔐 **Autentikasi & User Management**

- Login & Register dengan email dan password
- Session management otomatis
- User profile dengan personalisasi
- Logout functionality

### 📋 **Screening Kesehatan Mental**

- 9 pertanyaan screening yang komprehensif
- Full-screen quiz view (satu pertanyaan per layar)
- Navigation sebelum/sesudah pertanyaan
- Progress tracking real-time

### 💊 **Health Tracking Features**

- **Mood Tracker**: Catat suasana hati dengan 5 level + notes
- **Sleep Tracker**: Monitor durasi dan kualitas tidur
- Riwayat harian untuk setiap metric
- Data persistence lokal

### 🤖 **AI-Powered Insights**

- Health score calculation (0-100%)
- Personalized recommendations berdasarkan data
- Daily health overview
- Helpful mental health tips

### 🎨 **Customization**

- Custom color theme picker
- 8 preset colors
- Light/Dark/System theme modes
- Persistent theme preferences

### 📊 **Data Management**

- Screening history
- Health metrics history
- Persistent local storage (Hive + SharedPreferences)
- Offline-first architecture

---

## 🚀 Quick Start

### Prerequisites

- Flutter SDK ≥ 2.18.0
- Dart SDK ≥ 2.18.0
- Android Studio atau VS Code dengan Flutter extension

### Installation

```bash
# 1. Clone atau extract project
cd flutter_application_1

# 2. Install dependencies
flutter pub get

# 3. Run app
flutter run

# 4. Build APK (untuk testing di device)
flutter build apk --release
```

---

## 📱 User Guide

### First Time Users

1. **Launch App** → Login Page muncul
2. **Create Account** → Tab "Daftar" → Isi data → Daftar
3. **Home Page** → Lihat berbagai fitur
4. **Start Screening** → Jawab 9 pertanyaan → Lihat hasil

### Main Features

- **Home**: Dashboard dengan quick access ke semua fitur
- **Screening**: Full-screen mental health questionnaire
- **Mood Tracker**: Log daily mood dengan emoji
- **Sleep Tracker**: Track sleep duration dan quality
- **Health Insights**: AI recommendations based on data
- **Settings**: Theme customization dan preferences
- **Profile**: Edit user information

### Navigation

- Drawer menu untuk navigasi utama
- AppBar buttons untuk quick actions
- Bottom navigation untuk context-specific options
- Back buttons untuk navigasi kembali

---

## 🏗️ Architecture

### Technology Stack

- **Framework**: Flutter 3.x
- **State Management**: Riverpod 2.x
- **Local Database**: Hive 2.x (structured data) + SharedPreferences (key-value)
- **UI Framework**: Material 3
- **Additional**: google_fonts, flutter_colorpicker, uuid, http

### Project Structure

```
lib/
├── main.dart                    # App entry point
├── src/app.dart                 # App configuration
└── features/
    ├── models/                  # Data models
    ├── pages/                   # UI screens
    ├── providers.dart           # State management
    └── questions.dart           # Quiz questions
```

Lihat [ARCHITECTURE.md](ARCHITECTURE.md) untuk dokumentasi teknis lengkap.

---

## 📚 Documentation

- [**QUICKSTART.md**](QUICKSTART.md) - Panduan pengguna cepat
- [**FEATURES.md**](FEATURES.md) - Dokumentasi lengkap semua fitur
- [**ARCHITECTURE.md**](ARCHITECTURE.md) - Dokumentasi teknis & arsitektur
- [**UPDATE_SUMMARY.md**](UPDATE_SUMMARY.md) - Summary update v2.0

---

## 🔄 State Management (Riverpod)

### Key Providers

```dart
// Authentication
authProvider              → User login/logout state
profileProvider          → User profile data

// Theme
themeProvider           → Light/Dark/System mode
themeColorProvider      → Custom theme color

// Features
answersProvider         → Quiz answers
healthMetricsProvider   → Health tracking data
progressProvider        → Quiz progress
```

---

## 💾 Data Storage

### SharedPreferences (Settings & Auth)

- User login session
- Theme preferences
- User profile basics

### Hive (Health Data)

- Screening history
- Health metrics (mood, sleep, etc.)
- Optimized untuk queries dan offline use

---

## 🎯 Roadmap & Future Features

### Completed ✅

- Authentication system
- Full-screen quiz
- Mood & sleep tracking
- AI insights
- Theme customization

### Coming Soon 🔜

- Hydration tracker
- Exercise tracker
- Push notifications
- Advanced analytics
- Backend integration
- Cloud sync

### Planned 🗓️

- Wearable integration
- Social features
- Professional consultations
- Gamification
- Community features

---

## 🔧 Development

### Setup Development Environment

```bash
# Ensure Flutter is installed
flutter --version

# Get dependencies
flutter pub get

# Run in debug mode
flutter run -d <device_id>

# Run tests
flutter test

# Analyze code
flutter analyze

# Format code
flutter format lib/
```

### Building for Production

```bash
# iOS
flutter build ios --release

# Android
flutter build apk --release
flutter build appbundle --release

# Web
flutter build web --release
```

---

## 🐛 Known Issues

- No password reset functionality (coming soon)
- Email change not yet supported
- No multi-device sync (requires backend)

---

## 📞 Support & Feedback

Untuk pertanyaan, bug reports, atau feature requests:

1. Check dokumentasi di folder ini
2. Review code comments untuk clarification
3. Test semua fitur thoroughly sebelum reporting bugs
4. Provide detailed steps to reproduce bugs

---

## 📄 License

Developed for personal/educational use. Modify and distribute as needed.

---

## 👨‍💻 Development Info

**Current Version**: 2.0.0  
**Last Updated**: January 7, 2026  
**Status**: ✅ Development Complete - Ready for Testing  
**Target Platform**: Android, iOS, Web (future)

---

## 🎉 Credits

- Built with Flutter & Dart
- State management by Riverpod
- Data persistence by Hive
- UI inspired by modern Material Design

---

## 📊 Statistics

- 15+ screens/pages
- 6+ health tracking features
- 100+ lines of documentation
- Zero external dependencies for core logic
- Fully offline-capable

---

**Happy coding! 🚀**

Untuk dokumentasi lebih lengkap, lihat file lain di directory ini.
