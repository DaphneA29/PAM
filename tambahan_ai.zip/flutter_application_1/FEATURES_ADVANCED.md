# Advanced Features Implementation

## 1. Mood Tracker dengan Facial Recognition 😊

### Fitur Utama:

- **Deteksi Emosi Otomatis**: Menggunakan Google ML Kit untuk mendeteksi ekspresi wajah
- **Kamera Real-time**: Ambil foto dan analisis emosi secara instant
- **Manual Selection**: Pilih mood secara manual jika kamera tidak tersedia
- **AI Recommendations**: Setiap mood mendapat rekomendasi personal dari AI

### Cara Kerja:

1. User membuka Mood Tracker
2. Pilih opsi "Ambil Foto" untuk mengaktifkan kamera
3. Ambil foto wajah yang jelas
4. Sistem mendeteksi:
   - Smilingnya (kebahagiaan)
   - Mata terbuka/tertutup (kewaspadaan)
   - Kemiringan kepala (kebingungan)
5. Hasil ditampilkan dengan rekomendasi khusus
6. Simpan hasil untuk tracking mood harian

### Emotions Detected:

- **😊 Bahagia** (Smile > 70%) - MoodScore 5
- **😄 Senang** (Smile 50-70%) - MoodScore 4
- **😌 Santai** (Relaxed) - MoodScore 3
- **😐 Netral** (No expression) - MoodScore 2
- **😕 Ragu** (Head tilt > 25°) - MoodScore 2
- **😢 Sedih** (No smile + eyes closed) - MoodScore 1

---

## 2. Exercise Tracker - Smartwatch Mode 🏃

### Fitur Utama:

- **Real-time Step Counting**: Menggunakan sensor accelerometer & Pedometer
- **Live Activity Status**: Deteksi Berjalan vs Berlari vs Berhenti
- **Smartwatch UI**: Interface mirip jam tangan pintar
- **Auto Calorie Calculation**: Hitung kalori otomatis (0.04 kcal/step)
- **Session Tracking**: Durasi, pace, dan progres real-time

### Cara Kerja:

1. User membuka Exercise Tracker
2. Klik tombol "Mulai" untuk memulai tracking
3. Layar tetap menyala (Wakelock enabled)
4. Sistem mencatat:
   - Jumlah langkah (real-time)
   - Status aktivitas (berjalan/berlari/berhenti)
   - Durasi sesi
   - Kalori yang terbakar
   - Pace/kecepatan rata-rata
5. AI Coaching memberikan motivasi real-time
6. Klik "Simpan" untuk menyimpan sesi

### Display Stats:

- **Langkah**: Main counter dengan emoji status
- **Progress Circle**: Visualisasi progres ke target 8000 langkah
- **Stat Grid**:
  - Kalori (kcal) - merah
  - Durasi (jam:menit:detik) - biru
  - Avg Pace (langkah/menit) - hijau
  - Target (total goal) - ungu

### Permissions Required:

- `ACCESS_FINE_LOCATION` (untuk sensors)
- `ACTIVITY_RECOGNITION` (untuk step detection)

---

## Technical Implementation

### Dependencies Added:

```yaml
camera: ^0.10.5 # Kamera untuk mood detection
image: ^4.0.0 # Image processing
google_ml_kit: ^0.7.0 # Face detection & analysis
permission_handler: ^11.4.2 # Request permissions
pedometer: ^3.0.0 # Step counting
wakelock: ^0.6.0 # Keep screen on
```

### Architecture:

```
lib/
  services/
    emotion_detection_service.dart  # Face detection logic
  pages/
    mood_tracker_page_new.dart      # Mood UI with camera
    exercise_tracker_page_smartwatch.dart  # Smartwatch-style exercise
```

---

## Android Permissions (AndroidManifest.xml)

Add these permissions:

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACTIVITY_RECOGNITION" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-permission android:name="android.permission.INTERNET" />
```

---

## Data Storage

Semua hasil deteksi disimpan di `healthMetricsProvider` dengan struktur:

```dart
HealthMetric(
  id: uuid,
  userId: user.id,
  type: 'mood' atau 'exercise',
  value: moodScore atau stepCount,
  notes: detailedInfo,
  recordedAt: DateTime.now(),
)
```

---

## Future Enhancements

1. **Mood Tracker**:

   - Multi-face detection untuk grup
   - Emotion history chart
   - Python backend untuk deep learning emotion recognition
   - Instagram-like filter dengan emotion recommendations

2. **Exercise Tracker**:
   - GPS tracking untuk jogging routes
   - Heart rate integration (jika ada sensor)
   - Leaderboard dengan teman
   - Achievement badges untuk milestone

---

## Troubleshooting

### Camera Not Working:

- Check permissions di Settings > Apps > InsightMind
- Restart app
- Pastikan ada cahaya yang cukup untuk deteksi

### Steps Not Counting:

- Enable "Activity Recognition" di permissions
- Jam tangan/phone harus di pocket/tangan
- Activity Recognition memerlukan Google Play Services

### Screen Brightness:

- Wakelock akan membuat layar tetap menyala
- Battery akan habis lebih cepat - hanya gunakan saat tracking
