# 🏗️ Arsitektur InsightMind v2

## Overview

InsightMind menggunakan **Clean Architecture** dengan **Riverpod** untuk state management dan **Hive** + **SharedPreferences** untuk local persistence.

```
┌─────────────────────────────────────────────┐
│           UI Layer (Pages/Widgets)          │
│  (login_page, home_page, quiz_page, etc.)  │
└──────────────────┬──────────────────────────┘
                   │
┌──────────────────▼──────────────────────────┐
│      State Management (Riverpod)            │
│    (authProvider, themeProvider, etc.)      │
└──────────────────┬──────────────────────────┘
                   │
┌──────────────────▼──────────────────────────┐
│        Data Layer (Models & Storage)        │
│  (Hive, SharedPreferences, local database)  │
└─────────────────────────────────────────────┘
```

---

## 📂 Folder Structure

```
lib/
├── main.dart                           # Entry point & app initialization
├── src/
│   └── app.dart                        # MaterialApp configuration
└── features/
    ├── models/                         # Data models
    │   ├── user.dart                   # User authentication data
    │   ├── profile.dart                # User profile (legacy)
    │   ├── health_metric.dart          # Health tracking data
    │   └── history_entry.dart          # Screening history
    │
    ├── pages/                          # UI screens
    │   ├── login_page.dart             # Authentication
    │   ├── home_page.dart              # Main dashboard
    │   ├── quiz_page.dart              # Full-screen screening quiz
    │   ├── summary_page.dart           # Quiz summary & review
    │   ├── health_insights_page.dart   # AI insights & recommendations
    │   ├── profile_page.dart           # User profile editing
    │   ├── mood_tracker_page.dart      # Mood logging
    │   ├── sleep_tracker_page.dart     # Sleep logging
    │   ├── theme_customization_page.dart # Theme settings
    │   ├── settings_page.dart          # App settings
    │   ├── history_page.dart           # Screening history
    │   ├── screening_page.dart         # Quiz launcher (intro page)
    │   ├── result_page.dart            # Legacy results page
    │   └── history_detail_page.dart    # History details
    │
    ├── providers.dart                  # All Riverpod state providers
    └── questions.dart                  # Quiz questions data
```

---

## 🔄 State Management Architecture

### Providers Overview

```dart
// Authentication
authProvider: StateNotifierProvider<AuthNotifier, User?>
├─ Methods: login(), register(), logout(), updateProfile()
└─ Storage: SharedPreferences (users list + current user)

// Theme Management
themeProvider: StateNotifierProvider<ThemeNotifier, ThemeMode>
├─ Storage: SharedPreferences
└─ Values: system, light, dark

themeColorProvider: StateNotifierProvider<ThemeColorNotifier, Color>
├─ Storage: SharedPreferences (color value)
└─ Default: Colors.indigo

// Health Data
healthMetricsProvider: StateNotifierProvider<HealthMetricsNotifier, List<HealthMetric>>
├─ Methods: addMetric(), deleteMetric(), getMetricsByType()
├─ Storage: Hive (healthMetricsBox)
└─ Types: mood, sleep, water, exercise, anxiety

// Quiz Data
answersProvider: StateProvider<Map<String, int>>
├─ Storage: In-memory (cleared after screening)
└─ Format: {questionId: selectedOptionIndex}

progressProvider: Provider<int>
├─ Derived from: answersProvider.length
└─ Returns: number of answered questions

totalQuestionsProvider: Provider<int>
├─ Returns: 9 (hardcoded)
└─ Usage: Progress calculation

// User Profile (Legacy)
profileProvider: StateNotifierProvider<ProfileNotifier, Profile?>
├─ Storage: SharedPreferences
└─ Backward compatible

// History
historyProvider: StateNotifierProvider<HistoryNotifier, List<HistoryEntry>>
├─ Storage: Hive (historyBox)
└─ Methods: addEntry(), deleteEntry(), clearAll()
```

---

## 💾 Data Persistence Strategy

### SharedPreferences (For Key-Value Data)

```
insightmind_theme_mode: String        # 'light', 'dark', 'system'
insightmind_theme_color: int          # Color value (e.g., 4283215696)
insightmind_current_user: String      # User JSON
insightmind_users: String             # All users JSON {email: {user, password}}
insightmind_profile: String           # Legacy profile JSON
```

**Best For**: Settings, theme preferences, small user data

### Hive (For Complex Data)

**Box: `historyBox`**

- Key: Entry ID
- Value: HistoryEntry JSON string
- Use: Screening history with fast retrieval

**Box: `healthMetricsBox`**

- Key: Metric ID
- Value: HealthMetric JSON string
- Use: Mood, sleep, exercise tracking data

**Best For**: Large datasets, frequent reads/writes, offline persistence

---

## 🔐 Authentication Flow

```
┌─────────────────┐
│   Login Page    │
└────────┬────────┘
         │
    ┌────▼────┐
    │ Register │ ──────────────────────────────────┐
    └────┬────┘                                    │
         │                                        │
    ┌────▼────────────────────────────────────────▼────────┐
    │ AuthNotifier.register(name, email, password)         │
    │ • Check if email exists                              │
    │ • Create new User object                             │
    │ • Store in SharedPreferences                         │
    │ • Auto-login user                                    │
    └────┬───────────────────────────────────────────────┘
         │
    ┌────▼─────────┐
    │  Home Page   │◄──── App initializes with auth state
    └──────────────┘
         │
    ┌────▼──────────────┐
    │  User Actions     │
    │ • View profile    │
    │ • Edit settings   │
    │ • Logout          │
    └───────────────────┘
```

---

## 🎨 Theme System Architecture

### How Theme Works

```
┌──────────────────────────┐
│  App.build()             │
│  Watch themeProvider     │◄──── Triggers rebuild
│  Watch themeColorProvider│
└─────────────┬────────────┘
              │
              ▼
    ┌─────────────────────┐
    │  MaterialApp        │
    │  • theme:           │──────► Light Theme
    │  • darkTheme:       │──────► Dark Theme
    │  • themeMode:       │──────► system/light/dark
    │  • colorScheme:     │──────► Uses themeColor
    └─────────────────────┘
              │
              ▼
    All child widgets respect
    the MaterialApp theme
```

### Theme Color Application

```
themeColorProvider (Color)
    │
    ├─→ AppBar backgroundColor
    ├─→ ElevatedButton backgroundColor
    ├─→ FloatingActionButton color
    ├─→ Progress bar color
    ├─→ Selected option highlighting
    └─→ Custom accent colors throughout app
```

---

## 🎯 Quiz Flow Architecture

```
Home Page (Screening Intro)
    │
    ▼
Quiz Page (Full Screen, PageView)
    │
    ├─→ Question 1
    ├─→ Question 2
    ├─→ Question 3
    ├─→ ...
    ├─→ Question 9
    │
    ▼
Summary Page (Review Answers)
    │
    ▼
Health Insights Page (AI Analysis)
    │
    ▼
Save to History & Done
```

### Quiz State Management

```
User selects answer
    │
    ▼
Update answersProvider: {questionId: optionIndex}
    │
    ▼
progressProvider automatically updates (derived)
    │
    ▼
UI reflects new progress
```

---

## 💊 Health Metrics Architecture

### Data Model

```dart
HealthMetric {
  id: String (UUID)
  userId: String (from authProvider)
  type: String (mood, sleep, water, exercise)
  value: double (1-5 for mood, hours for sleep, etc.)
  notes: String? (optional)
  recordedAt: DateTime
}
```

### Health Tracking Flow

```
User opens Mood/Sleep Tracker
    │
    ▼
Input data (select mood, set time, rate quality)
    │
    ▼
Click "Simpan"
    │
    ▼
Create HealthMetric with current timestamp
    │
    ▼
healthMetricsProvider.addMetric(metric)
    │
    ├─→ Save to Hive
    └─→ Update state
         │
         ▼
    Riwayat section updates automatically
```

---

## 🤖 AI Insights Algorithm

### Health Score Calculation

```
Mental Health Score = (totalScore / maxScore) * 100

Where:
  totalScore = sum of all answers (0-27)
  maxScore = 9 questions × 3 points = 27
  Range: 0% to 100%
```

### Recommendation Generation

```
Based on:
├─ Mental Health Score
│  ├─ > 70%: "Kesehatan Mental Baik"
│  ├─ 50-70%: "Perhatian Diperlukan"
│  └─ < 50%: "Hubungi Profesional"
│
├─ Mood Tracking History
│  └─ If empty: "Mulai Tracking Mood"
│
└─ Sleep Tracking History
   ├─ If empty: "Monitor Pola Tidur"
   └─ If < 6h avg: "Tingkatkan Durasi Tidur"
```

---

## 🔄 Data Flow Example: User Login

```
1. User enters email & password
   └─► TextField controlled by TextEditingController

2. User taps "Masuk" button
   └─► Calls authNotifier.login(email, password)

3. AuthNotifier.login():
   └─► Reads users from SharedPreferences
   └─► Checks if user exists
   └─► Validates password
   └─► Updates state: state = user (if valid)
   └─► Saves to SharedPreferences

4. App watches authProvider
   └─► Detects state change
   └─► app.dart updates initialRoute
   └─► Navigates to home_page

5. Home Page renders
   └─► Accesses user data via authProvider
   └─► Displays user name in drawer header
```

---

## 🛡️ Error Handling Strategy

### Try-Catch Pattern

```dart
// In providers
try {
  // Perform operation
  state = newState;
} catch (e) {
  // Log error
  // Optionally: revert state
  // Return false/null to indicate failure
}
```

### UI Feedback

```dart
// In pages
if (success) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text('Sukses'))
  );
} else {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text('Error'))
  );
}
```

---

## 🚀 Performance Considerations

### Optimization Strategies

1. **Selective Rebuilds**

   ```dart
   // Only rebuild when needed
   ref.watch(authProvider.select((user) => user?.name))
   ```

2. **Lazy Loading**

   ```dart
   // Don't load all data immediately
   ListView(itemCount: largelist.length, itemBuilder: ...)
   ```

3. **Provider Caching**

   ```dart
   // Riverpod automatically caches provider results
   ```

4. **Hive Indexing**
   ```dart
   // Hive queries are fast for local data
   ```

---

## 🔮 Future Architecture Improvements

### Proposed: Backend Integration

```
                Local Storage
                (Hive, SharedPrefs)
                      △
                      │
                      ▼
        ┌─────────────────────────┐
        │   Local Cache Layer     │
        │ (Handle offline mode)   │
        └──────────┬──────────────┘
                   │
                   ▼
        ┌─────────────────────────┐
        │   API Service Layer     │
        │ (HTTP requests)         │
        └──────────┬──────────────┘
                   │
                   ▼
        ┌─────────────────────────┐
        │   Backend Server        │
        │ (Firebase / Custom API) │
        └─────────────────────────┘
```

### Proposed: Advanced State Management

```dart
// Potential: Use redux_dev_tools for debugging
// Potential: Add action middleware for logging
// Potential: Use freezed for immutable models
```

---

## 📊 Database Schema

### SharedPreferences

```
{
  'insightmind_theme_mode': 'light',
  'insightmind_theme_color': 4283215696,
  'insightmind_current_user': '{json}',
  'insightmind_users': '{json: {users...}}',
  'insightmind_profile': '{json}'
}
```

### Hive - historyBox

```
'entry-uuid-1': {
  'id': 'entry-uuid-1',
  'score': 18,
  'timestamp': '2026-01-07T10:30:00',
  'responses': {...}
}
```

### Hive - healthMetricsBox

```
'metric-uuid-1': {
  'id': 'metric-uuid-1',
  'userId': 'user-123',
  'type': 'mood',
  'value': 4,
  'notes': 'Had a great day!',
  'recordedAt': '2026-01-07T10:30:00'
}
```

---

## 🔗 Service Locator Pattern (Future)

```dart
// Recommended for future dependency injection
// Using GetIt or Riverpod family providers

// Example:
final userRepositoryProvider = Provider((ref) {
  return UserRepository(
    prefs: ref.watch(sharedPreferencesProvider),
    hive: ref.watch(hiveProvider),
  );
});
```

---

**Architecture Document v1.0**  
**Last Updated**: January 2026
